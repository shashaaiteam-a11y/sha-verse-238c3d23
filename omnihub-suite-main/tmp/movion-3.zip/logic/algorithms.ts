
import { Video, VideoType, Channel, Subscription } from '../types';

/**
 * SEARCH CONTENT ALGORITHM
 * Searches across videos and channels based on a query string and filter type.
 */
// Added searchContent export to fix the module export error in SearchResults.tsx
export const searchContent = (
  query: string,
  videos: Video[],
  channels: Channel[],
  filterType: 'ALL' | 'VIDEOS' | 'SHORTS' | 'CHANNELS'
): (Video | Channel)[] => {
  const q = query.toLowerCase().trim();
  if (!q) return [];

  let matchedChannels: Channel[] = [];
  if (filterType === 'ALL' || filterType === 'CHANNELS') {
    matchedChannels = channels.filter(c => 
      c.name.toLowerCase().includes(q) || 
      c.handle.toLowerCase().includes(q) ||
      c.description.toLowerCase().includes(q)
    );
  }

  let matchedVideos: Video[] = [];
  if (filterType === 'ALL' || filterType === 'VIDEOS' || filterType === 'SHORTS') {
    matchedVideos = videos.filter(v => 
      v.title.toLowerCase().includes(q) || 
      v.description.toLowerCase().includes(q) ||
      (v.tags && v.tags.some(t => t.toLowerCase().includes(q))) ||
      v.channelName.toLowerCase().includes(q)
    );

    if (filterType === 'VIDEOS') {
      matchedVideos = matchedVideos.filter(v => v.type === VideoType.LONG);
    } else if (filterType === 'SHORTS') {
      matchedVideos = matchedVideos.filter(v => v.type === VideoType.SHORT);
    }
  }

  const results: (Video | Channel)[] = [...matchedChannels, ...matchedVideos];

  // Simple relevance scoring: exact matches first, then prefix matches, then popularity
  return results.sort((a, b) => {
    const aTitle = 'name' in a ? a.name : a.title;
    const bTitle = 'name' in b ? b.name : b.title;
    
    const aLower = aTitle.toLowerCase();
    const bLower = bTitle.toLowerCase();

    // Exact title match gets highest priority
    if (aLower === q && bLower !== q) return -1;
    if (bLower === q && aLower !== q) return 1;

    // Starts with query gets second priority
    if (aLower.startsWith(q) && !bLower.startsWith(q)) return -1;
    if (bLower.startsWith(q) && !aLower.startsWith(q)) return 1;

    // Tie-break by popularity (views for videos, subscribers for channels)
    const aPopularity = 'subscribers' in a ? a.subscribers : a.views;
    const bPopularity = 'subscribers' in b ? b.subscribers : b.views;
    
    return bPopularity - aPopularity;
  });
};

/**
 * HOME FEED ALGORITHM
 * Weight-based scoring for long-form video discovery.
 */
export const prioritizeVideos = (
  videos: Video[], 
  subscriptions: string[], 
  history: Video[], 
  searchQuery?: string,
  category?: string
): Video[] => {
  const userTopCategories = Array.from(new Set(history.map(v => v.category)));
  const now = Date.now();

  let results = [...videos].filter(v => v.type === VideoType.LONG);
  
  if (category && category !== 'All' && category !== 'New to you') {
    results = results.filter(v => v.category === category);
  }

  return results.sort((a, b) => {
    const calculateScore = (v: Video) => {
      const analytics = v.analytics || { 
        watchTimeSeconds: 0, likes: 0, dislikes: 0, commentsCount: 0, 
        uploadTimestampMs: now - 86400000 
      };

      const watchTimeScore = Math.min(analytics.watchTimeSeconds / 10000, 1) * 0.4;
      const likesScore = Math.min(analytics.likes / 5000, 1) * 0.2;
      const commentsScore = Math.min(analytics.commentsCount / 500, 1) * 0.1;
      
      const hoursOld = (now - analytics.uploadTimestampMs) / (1000 * 60 * 60);
      const freshnessScore = Math.max(1 - (hoursOld / 72), 0) * 0.15; 
      const categoryMatchScore = userTopCategories.includes(v.category) ? 0.15 : 0;

      const subBoost = subscriptions.includes(v.channelId) ? 1.2 : 1;
      return (watchTimeScore + likesScore + commentsScore + freshnessScore + categoryMatchScore) * subBoost;
    };

    return calculateScore(b) - calculateScore(a);
  });
};

/**
 * PULSE (SHORTS) ALGORITHM
 * Prioritizes fast engagement and high completion rates.
 */
export const prioritizePulse = (videos: Video[]): Video[] => {
  const shorts = videos.filter(v => v.type === VideoType.SHORT);
  
  return shorts.sort((a, b) => {
    const calculatePulseScore = (v: Video) => {
      const analytics = v.analytics || { averageRetention: 0.5, replays: 0, engagementSpeed: 0.5, likes: 0 };
      const retentionScore = analytics.averageRetention * 0.5;
      const replayScore = Math.min(analytics.replays / 10, 1) * 0.3; 
      const speedScore = analytics.engagementSpeed * 0.2;
      return retentionScore + replayScore + speedScore;
    };
    return calculatePulseScore(b) - calculatePulseScore(a);
  });
};

/**
 * SUBSCRIPTION FEED ALGORITHM
 */
export const prioritizeSubscriptions = (
  videos: Video[],
  subscriptionsMap: Record<string, Subscription>,
  history: Video[],
  channelId?: string,
  sortMode: 'smart' | 'recent' = 'recent'
): Video[] => {
  let filtered = videos.filter(v => v.type === VideoType.LONG);
  if (channelId) filtered = filtered.filter(v => v.channelId === channelId);
  else filtered = filtered.filter(v => subscriptionsMap[v.channelId]);

  if (sortMode === 'recent') {
    return filtered.sort((a, b) => (b.analytics?.uploadTimestampMs || 0) - (a.analytics?.uploadTimestampMs || 0));
  }

  const now = Date.now();
  const channelAffinity: Record<string, number> = {};
  history.forEach(v => { channelAffinity[v.channelId] = (channelAffinity[v.channelId] || 0) + 1; });

  return filtered.sort((a, b) => {
    const getScore = (v: Video) => {
      const msAgo = Math.max(0, now - (v.analytics?.uploadTimestampMs || now));
      const hoursAgo = msAgo / (1000 * 60 * 60);
      const recencyScore = 100 / (Math.max(hoursAgo, 0.1) + 1); 
      const sub = subscriptionsMap[v.channelId];
      let notifScore = sub?.notificationLevel === 'ALL' ? 40 : 10;
      const interactionScore = Math.min((channelAffinity[v.channelId] || 0) * 5, 30); 
      return recencyScore + notifScore + interactionScore;
    };
    return getScore(b) - getScore(a);
  });
};

export const getRelatedVideos = (currentVideo: Video, allVideos: Video[]): Video[] => {
  return prioritizeVideos(
    allVideos.filter(v => v.id !== currentVideo.id && v.type === VideoType.LONG),
    [currentVideo.channelId],
    [], undefined, 'All'
  );
};
