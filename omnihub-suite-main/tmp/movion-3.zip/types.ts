
export enum VideoType {
  LONG = 'LONG',
  SHORT = 'SHORT'
}

export type NotificationLevel = 'ALL' | 'PERSONALIZED' | 'NONE';

export interface UserPermissions {
  canUpload: boolean;
  canComment: boolean;
  isCreator: boolean;
  monetizationEnabled: boolean;
}

export interface Channel {
  id: string;
  name: string;
  handle: string;
  avatar: string;
  subscribers: number;
  description: string;
  banner?: string;
  watchTimeHours: number;
  shortsViews: number;
  joinedDate: string;
}

export interface Subscription {
  channelId: string;
  subscribedAt: number;
  notificationLevel: NotificationLevel;
}

export interface ToastMessage {
  id: string;
  message: string;
  type: 'success' | 'info' | 'error';
}

export interface Notification {
  id: string;
  type: 'upload' | 'live' | 'comment' | 'community' | 'alert';
  channelId?: string;
  channelName?: string;
  channelAvatar?: string;
  text: string;
  time: string;
  read: boolean;
  videoId?: string;
  thumbnail?: string;
  link?: string;
}

export interface VideoAnalytics {
  views: number;
  likes: number;
  dislikes: number;
  shares: number;
  commentsCount: number;
  watchTimeSeconds: number;
  averageRetention: number; // 0 to 1
  replays: number; // Specific to Shorts
  engagementSpeed: number; // Score based on speed of likes/comments
  subscribersGained: number;
  uploadTimestampMs: number;
  dailyViews: number[]; // Last 7 days
}

export interface Video {
  id: string;
  title: string;
  description: string;
  thumbnail: string;
  videoUrl: string;
  type: VideoType;
  views: number;
  likes: number;
  dislikes: number;
  timestamp: string;
  duration: string;
  channelId: string;
  channelName: string;
  channelAvatar: string;
  category: string;
  tags?: string[];
  visibility?: 'public' | 'private' | 'unlisted';
  analytics?: VideoAnalytics;
}

export type AnalyticsEventType = 
  | 'watch_started' 
  | 'retention_hit' 
  | 'video_liked' 
  | 'video_disliked'
  | 'channel_followed' 
  | 'content_shared'
  | 'video_replay';

export interface AnalyticsEvent {
  type: AnalyticsEventType;
  videoId?: string;
  channelId?: string;
  payload?: any;
}

export interface Comment {
  id: string;
  videoId: string;
  userId: string;
  userName: string;
  userHandle: string;
  userAvatar: string;
  text: string;
  createdAt: number; // Timestamp
  likeCount: number;
  dislikeCount: number;
  isLiked: boolean;
  isDisliked: boolean;
  parentId?: string; // If nested
  pinned: boolean;
  isOwner: boolean; // Is video creator
  replies?: Comment[]; // For UI grouping
}

export interface UserEngagement {
  watchTime: Record<string, number>;
  progress: Record<string, number>;
  skips: Record<string, number>;
  likes: Set<string>;
  shares: Record<string, number>;
  topCategories: string[];
}

// Added LiveChatMessage interface to fix store.ts import error
export interface LiveChatMessage {
  id: string;
  userId: string;
  userName: string;
  userAvatar: string;
  text: string;
  timestamp: number;
  isSuperChat: boolean;
  amount: string;
  color: string;
}
