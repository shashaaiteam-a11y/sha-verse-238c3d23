
import React, { useState, useMemo, useEffect } from 'react';
import { useSearchParams } from 'react-router-dom';
import { useUserStore } from '../store';
import { MOCK_VIDEOS, MOCK_CHANNELS } from '../constants';
import { searchContent } from '../logic/algorithms';
import VideoCard from '../components/VideoCard';
import ChannelCard from '../components/ChannelCard';
import ShortsCard from '../components/ShortsCard';
import { SlidersHorizontal, Search as SearchIcon, Ghost, X, Check, Calendar, Clock } from 'lucide-react';
import { Video } from '../types';

// Helper to parse relative timestamps into hours for filtering
const parseTimeAgo = (timestamp: string): number => {
  if (!timestamp) return 999999;
  const str = timestamp.toLowerCase();
  if (str.includes('just now')) return 0;
  
  // Extract number
  const match = str.match(/(\d+)/);
  const value = match ? parseInt(match[0]) : 0;
  
  if (str.includes('second')) return value / 3600;
  if (str.includes('minute')) return value / 60;
  if (str.includes('hour')) return value;
  if (str.includes('day')) return value * 24;
  if (str.includes('week')) return value * 24 * 7;
  if (str.includes('month')) return value * 24 * 30;
  if (str.includes('year')) return value * 24 * 365;
  
  return 999999;
};

const SearchResults: React.FC = () => {
  const [searchParams] = useSearchParams();
  const query = searchParams.get('search_query') || '';
  const [filterType, setFilterType] = useState<'ALL' | 'VIDEOS' | 'SHORTS' | 'CHANNELS'>('ALL');
  const [dateFilter, setDateFilter] = useState<'ALL' | 'HOUR' | 'TODAY' | 'WEEK' | 'MONTH' | 'YEAR'>('ALL');
  const [showFilters, setShowFilters] = useState(false);
  const { searchQuery: globalSearchQuery, setSearchQuery, userVideos } = useUserStore();

  useEffect(() => {
    if (query !== globalSearchQuery) {
      setSearchQuery(query);
    }
  }, [query, globalSearchQuery, setSearchQuery]);

  // Merge mock and user videos for search to ensure uploaded content is findable
  const allVideos = useMemo(() => [...MOCK_VIDEOS, ...(userVideos || [])], [userVideos]);

  const rawResults = useMemo(() => 
    searchContent(query, allVideos, MOCK_CHANNELS, filterType),
    [query, allVideos, filterType]
  );

  const results = useMemo(() => {
    if (dateFilter === 'ALL') return rawResults;

    return rawResults.filter(item => {
      // Logic: If filtering by date, typically channels are excluded from results on major platforms
      if ('handle' in item) return false;

      const v = item as Video;
      const hoursAgo = parseTimeAgo(v.timestamp);
      
      switch (dateFilter) {
        case 'HOUR': return hoursAgo <= 1;
        case 'TODAY': return hoursAgo <= 24;
        case 'WEEK': return hoursAgo <= 168; // 7 days
        case 'MONTH': return hoursAgo <= 720; // 30 days
        case 'YEAR': return hoursAgo <= 8760; // 365 days
        default: return true;
      }
    });
  }, [rawResults, dateFilter]);

  const typeFilters = [
    { id: 'ALL', label: 'All' },
    { id: 'VIDEOS', label: 'Videos' },
    { id: 'SHORTS', label: 'Shorts' },
    { id: 'CHANNELS', label: 'Channels' },
  ];

  const dateFilters = [
    { id: 'ALL', label: 'Any time' },
    { id: 'HOUR', label: 'Last hour' },
    { id: 'TODAY', label: 'Today' },
    { id: 'WEEK', label: 'This week' },
    { id: 'MONTH', label: 'This month' },
    { id: 'YEAR', label: 'This year' },
  ];

  return (
    <div className="flex flex-col min-h-full bg-[#0f0f0f]">
      {/* Search Filter Header */}
      <div className="sticky top-0 bg-[#0f0f0f]/95 backdrop-blur-md z-40 border-b border-white/5 flex flex-col">
        <div className="px-4 sm:px-8 py-3 flex flex-col sm:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-3 overflow-x-auto no-scrollbar pb-1 w-full sm:w-auto">
            {typeFilters.map(f => (
              <button
                key={f.id}
                onClick={() => setFilterType(f.id as any)}
                className={`px-5 py-2 rounded-full text-xs font-black uppercase tracking-widest transition-all whitespace-nowrap ${
                  filterType === f.id 
                  ? 'bg-white text-black shadow-lg shadow-white/10' 
                  : 'bg-white/5 text-[#aaa] hover:bg-white/10 border border-white/5'
                }`}
              >
                {f.label}
              </button>
            ))}
            {!showFilters && dateFilter !== 'ALL' && (
              <div className="flex items-center gap-2 px-5 py-2 bg-blue-600/10 border border-blue-600/30 rounded-full text-blue-500 text-xs font-black uppercase tracking-widest whitespace-nowrap animate-in fade-in">
                <Calendar size={12} />
                {dateFilters.find(d => d.id === dateFilter)?.label}
                <button onClick={(e) => { e.stopPropagation(); setDateFilter('ALL'); }} className="hover:text-white transition-colors ml-1"><X size={12}/></button>
              </div>
            )}
          </div>
          
          <button 
            onClick={() => setShowFilters(!showFilters)}
            className={`flex items-center gap-2 px-5 py-2 rounded-full text-[10px] font-black uppercase tracking-widest border transition-all active:scale-95 ${showFilters ? 'bg-white text-black border-white' : 'bg-[#272727] hover:bg-[#3f3f3f] text-[#aaa] border-white/5'}`}
          >
            <SlidersHorizontal size={14} /> Filters
          </button>
        </div>

        {showFilters && (
          <div className="px-4 sm:px-8 py-6 bg-[#181818] border-t border-white/5 grid grid-cols-1 sm:grid-cols-2 gap-12 animate-in slide-in-from-top-2 shadow-2xl">
            <div>
              <h3 className="text-xs font-black uppercase tracking-[0.2em] text-[#666] mb-4 border-b border-white/5 pb-2">Upload Date</h3>
              <div className="flex flex-col gap-1">
                {dateFilters.map(f => (
                  <button
                    key={f.id}
                    onClick={() => setDateFilter(f.id as any)}
                    className={`flex items-center justify-between text-sm py-2 px-3 rounded-lg transition-all text-left ${dateFilter === f.id ? 'bg-white/10 text-white font-bold' : 'text-[#aaa] hover:bg-white/5 font-medium'}`}
                  >
                    {f.label}
                    {dateFilter === f.id && <Check size={16} />}
                  </button>
                ))}
              </div>
            </div>
            
            <div>
              <h3 className="text-xs font-black uppercase tracking-[0.2em] text-[#666] mb-4 border-b border-white/5 pb-2">Type</h3>
              <div className="flex flex-col gap-1">
                {typeFilters.map(f => (
                  <button
                    key={f.id}
                    onClick={() => setFilterType(f.id as any)}
                    className={`flex items-center justify-between text-sm py-2 px-3 rounded-lg transition-all text-left ${filterType === f.id ? 'bg-white/10 text-white font-bold' : 'text-[#aaa] hover:bg-white/5 font-medium'}`}
                  >
                    {f.label}
                    {filterType === f.id && <Check size={16} />}
                  </button>
                ))}
              </div>
            </div>
          </div>
        )}
      </div>

      <div className="p-4 sm:p-8 max-w-[1200px] mx-auto w-full">
        <div className="flex items-center gap-4 mb-8">
          <div className="p-3 bg-red-600/10 rounded-2xl text-red-600">
             <SearchIcon size={24} />
          </div>
          <div>
            <h1 className="text-xl sm:text-2xl font-black italic tracking-tighter uppercase leading-none text-white">
              Results for: <span className="text-[#3ea6ff]">{query}</span>
            </h1>
            <div className="flex items-center gap-2 mt-2">
               <span className="text-[10px] text-[#555] font-black uppercase tracking-[0.3em]">
                 {results.length} Matches Found
               </span>
               {dateFilter !== 'ALL' && (
                 <span className="text-[10px] text-[#aaa] font-bold bg-white/10 px-2 py-0.5 rounded flex items-center gap-1">
                   <Clock size={10} /> Filtered by Date
                 </span>
               )}
            </div>
          </div>
        </div>

        {results.length > 0 ? (
          <div className="flex flex-col gap-6">
            {results.map((item: any, idx) => {
              if ('handle' in item) {
                return (
                  <div key={item.id} className="animate-in fade-in slide-in-from-bottom-2 duration-300" style={{ animationDelay: `${idx * 50}ms` }}>
                    <ChannelCard channel={item} />
                  </div>
                );
              } else if (item.type === 'SHORT') {
                return (
                  <div key={item.id} className="w-full sm:w-48 animate-in fade-in slide-in-from-bottom-2 duration-300" style={{ animationDelay: `${idx * 50}ms` }}>
                    <ShortsCard video={item} />
                  </div>
                );
              } else {
                return (
                  <div key={item.id} className="animate-in fade-in slide-in-from-bottom-2 duration-300" style={{ animationDelay: `${idx * 50}ms` }}>
                    <VideoCard video={item} layout="list-large" />
                  </div>
                );
              }
            })}
          </div>
        ) : (
          <div className="flex flex-col items-center justify-center py-40 text-center animate-in zoom-in duration-500">
            <div className="relative mb-10">
              <Ghost size={120} className="text-white/5 animate-pulse" />
              <div className="absolute inset-0 flex items-center justify-center">
                 <SearchIcon size={40} className="text-red-600/20" />
              </div>
            </div>
            <h2 className="text-3xl font-black italic text-white uppercase tracking-tighter leading-none mb-4">No Matches Found</h2>
            <p className="text-[#666] text-sm font-bold max-w-sm mx-auto leading-relaxed mb-10">
              {dateFilter !== 'ALL' 
                ? "Try adjusting your date filters or search terms."
                : "No results matched your query. Try using different keywords."}
            </p>
            <button 
              onClick={() => { setFilterType('ALL'); setDateFilter('ALL'); }}
              className="px-12 py-3 bg-white text-black font-black rounded-full hover:bg-gray-200 transition-all active:scale-95 shadow-2xl text-xs uppercase tracking-widest"
            >
              Clear Filters
            </button>
          </div>
        )}
      </div>
    </div>
  );
};

export default SearchResults;
