
import React from 'react';
import { useUserStore } from '../store';
import VideoCard from '../components/VideoCard';
import { Play, Shuffle, MoreVertical, Share2, Download, ListVideo, Trash2, Clock, ThumbsUp } from 'lucide-react';
import { Link, useNavigate } from 'react-router-dom';

interface PlaylistPageProps {
  type: 'Watch Later' | 'Liked Videos';
}

const PlaylistPage: React.FC<PlaylistPageProps> = ({ type }) => {
  const { watchLater, likedVideos, toggleWatchLater, toggleLike } = useUserStore();
  const navigate = useNavigate();
  
  const videos = type === 'Watch Later' ? watchLater : likedVideos;
  const firstVideo = videos[0];

  const handleRemove = (e: React.MouseEvent, video: any) => {
    e.preventDefault();
    e.stopPropagation();
    if (type === 'Watch Later') toggleWatchLater(video);
    else toggleLike(video);
  };

  return (
    <div className="flex flex-col lg:flex-row min-h-full bg-white">
      {/* Sidebar Info Section */}
      <div className="lg:w-[380px] lg:fixed lg:h-[calc(100vh-56px)] p-6 lg:p-10 z-10 bg-gradient-to-b from-gray-100 to-white lg:border-r border-gray-100">
        <div className="relative aspect-video rounded-2xl overflow-hidden shadow-2xl mb-8 border border-gray-200">
          {firstVideo ? (
            <img src={firstVideo.thumbnail} className="w-full h-full object-cover" alt="Playlist cover" />
          ) : (
            <div className="w-full h-full bg-gray-200 flex items-center justify-center text-gray-400">
              <ListVideo size={64} />
            </div>
          )}
        </div>

        <h1 className="text-3xl font-black italic uppercase tracking-tighter mb-4 text-[#030303]">{type}</h1>
        
        <div className="space-y-1 mb-8">
          <p className="text-sm font-bold text-[#030303] flex items-center gap-2">
            {type === 'Watch Later' ? <Clock size={16} /> : <ThumbsUp size={16} />}
            Your Account
          </p>
          <p className="text-[11px] text-gray-500 font-bold uppercase tracking-widest">
            {videos.length} videos • Updated today
          </p>
        </div>

        <div className="flex gap-3 mb-8">
          <button 
            onClick={() => videos.length > 0 && navigate(`/watch/${videos[0].id}`)}
            className="flex-1 flex items-center justify-center gap-2 bg-[#030303] text-white py-3 rounded-full font-black text-xs uppercase tracking-widest hover:bg-[#272727] transition-all shadow-xl"
          >
            <Play size={16} fill="white" /> Play all
          </button>
          <button className="flex-1 flex items-center justify-center gap-2 bg-gray-200 text-black py-3 rounded-full font-black text-xs uppercase tracking-widest hover:bg-gray-300 transition-all">
            <Shuffle size={16} /> Shuffle
          </button>
        </div>

        <div className="flex items-center gap-4 pt-6 border-t border-gray-200">
          <button className="p-2 hover:bg-gray-100 rounded-full text-gray-600"><Download size={20} /></button>
          <button className="p-2 hover:bg-gray-100 rounded-full text-gray-600"><Share2 size={20} /></button>
          <button className="p-2 hover:bg-gray-100 rounded-full text-gray-600 ml-auto"><MoreVertical size={20} /></button>
        </div>
      </div>

      {/* Video List Section */}
      <div className="flex-1 lg:ml-[380px] p-4 lg:p-8">
        {videos.length > 0 ? (
          <div className="flex flex-col gap-2">
            {videos.map((video: any, idx: number) => (
              <div key={video.id} className="flex items-center gap-4 group hover:bg-gray-50 p-2 rounded-xl transition-colors">
                <span className="text-xs font-bold text-gray-400 w-6 text-center">{idx + 1}</span>
                <div className="flex-1">
                  <VideoCard video={video} layout="list" />
                </div>
                <button 
                  onClick={(e) => handleRemove(e, video)}
                  className="p-2 text-gray-400 hover:text-red-500 opacity-0 group-hover:opacity-100 transition-all"
                  title="Remove from list"
                >
                  <Trash2 size={18} />
                </button>
              </div>
            ))}
          </div>
        ) : (
          <div className="h-[60vh] flex flex-col items-center justify-center text-center gap-4">
            <div className="w-24 h-24 bg-gray-100 rounded-full flex items-center justify-center text-gray-300">
              <ListVideo size={48} />
            </div>
            <h3 className="text-xl font-bold">Your list is empty</h3>
            <p className="text-gray-500 text-sm">Videos you save will appear here.</p>
          </div>
        )}
      </div>
    </div>
  );
};

export default PlaylistPage;
