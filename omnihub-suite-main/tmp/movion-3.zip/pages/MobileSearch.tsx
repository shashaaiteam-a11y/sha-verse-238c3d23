
import React, { useState, useEffect, useRef } from 'react';
import { useNavigate } from 'react-router-dom';
import { Search, ArrowLeft, X, History as HistoryIcon, TrendingUp } from 'lucide-react';
import { useUserStore } from '../store';

const MobileSearch: React.FC = () => {
  const navigate = useNavigate();
  const { searchQuery, setSearchQuery, searchHistory, addToSearchHistory, removeFromSearchHistory } = useUserStore();
  const [localQuery, setLocalQuery] = useState(searchQuery || '');
  const inputRef = useRef<HTMLInputElement>(null);

  // Defensive check for search history array
  const safeHistory = Array.isArray(searchHistory) ? searchHistory : [];

  useEffect(() => {
    inputRef.current?.focus();
  }, []);

  const handleSearch = (term: string) => {
    if (term && term.trim()) {
      addToSearchHistory(term);
      setSearchQuery(term);
      navigate('/');
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    handleSearch(localQuery);
  };

  return (
    <div className="fixed inset-0 z-[100] bg-[#0f0f0f] flex flex-col animate-in fade-in slide-in-from-bottom-2 duration-300">
      {/* Search Bar Container */}
      <header className="flex items-center gap-3 px-3 py-3 border-b border-white/5">
        <button 
          onClick={() => navigate(-1)}
          className="p-2.5 hover:bg-white/5 rounded-full transition-colors"
        >
          <ArrowLeft size={22} />
        </button>
        
        <form onSubmit={handleSubmit} className="flex-1 flex items-center bg-white/5 rounded-2xl px-5 py-2.5 focus-within:bg-white/10 transition-all border border-transparent focus-within:border-white/10">
          <input 
            ref={inputRef}
            type="text"
            value={localQuery}
            onChange={(e) => setLocalQuery(e.target.value)}
            placeholder="Search MOVION Pulse..."
            className="flex-1 bg-transparent border-none outline-none text-white text-base font-medium"
          />
          {localQuery && (
            <button 
              type="button"
              onClick={() => setLocalQuery('')}
              className="p-1.5 hover:bg-white/10 rounded-full transition-colors"
            >
              <X size={18} />
            </button>
          )}
        </form>
      </header>

      {/* History and Trends Scrollable Area */}
      <div className="flex-1 overflow-y-auto no-scrollbar">
        <div className="flex flex-col py-4">
          {safeHistory.length > 0 && safeHistory.map((term, index) => (
            <div 
              key={`history-${index}`}
              className="flex items-center hover:bg-white/5 active:bg-white/10 transition-colors px-4"
            >
              <button 
                onClick={() => handleSearch(term)}
                className="flex-1 flex items-center gap-5 py-4 text-left group"
              >
                <HistoryIcon size={18} className="text-[#555] group-hover:text-white transition-colors" />
                <span className="text-[15px] font-bold text-[#aaa] group-hover:text-white transition-colors truncate">{term}</span>
              </button>
              <button 
                onClick={() => removeFromSearchHistory(term)}
                className="p-4 text-[#444] hover:text-red-500 transition-colors"
              >
                <X size={16} />
              </button>
            </div>
          ))}

          {/* Clean Trending Section */}
          <div className="mt-6">
            <div className="px-6 py-3 text-[10px] font-black text-[#444] uppercase tracking-[0.3em]">Trending Now</div>
            {['Quantum Computing 2025', 'SpaceX Starship Mars', 'Next-Gen React Features', 'Ambient Lo-Fi Beats'].map((trend, idx) => (
              <button 
                key={`trend-${idx}`}
                onClick={() => handleSearch(trend)}
                className="w-full flex items-center gap-5 px-6 py-4 hover:bg-white/5 active:bg-white/10 text-left transition-all group"
              >
                <TrendingUp size={18} className="text-[#555] group-hover:text-[#3ea6ff] transition-colors" />
                <span className="text-[15px] font-bold text-[#aaa] group-hover:text-white transition-colors">{trend}</span>
              </button>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};

export default MobileSearch;
