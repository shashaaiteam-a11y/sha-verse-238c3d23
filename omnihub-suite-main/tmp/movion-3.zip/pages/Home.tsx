
import React, { useState, useMemo, useEffect, useRef } from 'react';
import { MOCK_VIDEOS } from '../constants';
import { VideoType, Video } from '../types';
import VideoCard from '../components/VideoCard';
import ShortVideoHorizontalList from '../components/ShortVideoHorizontalList';
import { ChevronRight, ChevronLeft, Search, Sparkles } from 'lucide-react';
import { useUserStore } from '../store';

const generateCategories = () => {
  const baseTopics = [
    'Tech', 'Gaming', 'Music', 'Live', 'Cooking', 'Travel', 'Comedy', 'Programming', 'Nature', 
    'Lifestyle', 'News', 'Science', 'History', 'Fitness', 'Art', 'Design', 'Cars', 'Bikes', 
    'Finance', 'Crypto', 'Stocks', 'Marketing', 'Sales', 'DIY', 'Craft', 'Gardening', 'Pets', 
    'Docs', 'Cats', 'Physics', 'Biology', 'Math', 'Chess', 'Poker', 'Anime', 'Manga', 'Movies', 
    'Cinema', 'Horror', 'Sci-Fi', 'Fantasy', 'Poetry', 'Writing', 'Podcast', 'Hardware', 
    'Software', 'VR', 'AR', 'Web3', 'Blockchain', 'Python', 'React', 'DevOps', 'Docker', 
    'Cloud', 'Security', 'IoT', 'Energy', 'Sustainability', 'Minimalism', 'Van Life', 'Camping', 
    'Hiking', 'Fishing', 'Archery', 'MMA', 'Boxing', 'Yoga', 'CrossFit', 'Soccer', 'Basketball', 
    'F1', 'Skateboarding', 'Surfing', 'Dance', 'Techno', 'House', 'Lo-Fi', 'Jazz', 'Rock', 
    'Metal', 'Pop', 'Country', 'Classical', 'Theatre', 'VFX', 'Typography', 'Logo Design', 
    'Illustration', 'Painting', 'Photoshop', 'Blender', 'After Effects', 'Ableton', 'Synth', 
    'Vinyl', 'Mixing', 'Mastering', 'Books', 'E-books', 'Libraries', 'Ancient', 'Medieval', 
    'Modern', 'Philosophy', 'Psychology', 'Politics', 'Economics', 'Ethics', 'Theology', 
    'Astrology', 'Tarot', 'Mythology', 'Folklore', 'Superheroes', 'Comics', 'Collecting', 
    'Real Estate', 'Investing', 'Taxes', 'Retirement', 'Habits', 'Sleep', 'Biohacking', 
    'Skincare', 'Fashion', 'Sneakers', 'Watches', 'Fragrance', 'Interior Design', 'Organization', 
    'Aviation', 'Spaceflight', 'Rockets', 'Stars', 'Genetics', 'Biotech', 'Surgery', 'Therapy', 
    'Relationships', 'Dating', 'Parenting', 'Study', 'Memory', 'Polyglot', 'Spanish', 'French', 
    'German', 'Chinese', 'Japanese', 'Arabic', 'Russian'
  ];

  const modifiers = [
    'All', 'New to you', 'Latest', 'Advanced', 'Fundamentals of', 'The Best of', 'Trending', 
    'Deep Dive into', 'Masterclass:', 'History of', 'Future of', 'Experimental', 'Unboxing', 
    'Reviews of', 'Tutorials for', 'Tips and Tricks:', 'Live Stream:', 'Podcasts on', 
    'Essential', 'Hidden Gems of', 'Relaxing', 'Extreme', 'Minimal', 'Vintage', 'Modern', 
    'Underground', 'Popular', 'Competitive', 'Cozy', 'Aesthetic'
  ];

  const set = new Set<string>(['All', 'New to you', 'Live', 'Music']);
  
  for (const mod of modifiers) {
    for (const topic of baseTopics) {
      if (set.size >= 2600) break;
      set.add(`${mod} ${topic}`);
    }
  }

  return Array.from(set);
};

const Home: React.FC = () => {
  const [activeCategory, setActiveCategory] = useState('All');
  const { searchQuery, getFeed } = useUserStore();
  const [displayedVideos, setDisplayedVideos] = useState<Video[]>([]);
  const [isLoadingMore, setIsLoadingMore] = useState(false);
  const loadMoreRef = useRef<HTMLDivElement>(null);
  
  const categories = useMemo(() => generateCategories(), []);
  
  const shorts = useMemo(() => MOCK_VIDEOS.filter(v => v.type === VideoType.SHORT), []);
  const filteredVideos = useMemo(() => getFeed(activeCategory), [activeCategory, getFeed, searchQuery]);

  useEffect(() => {
    setDisplayedVideos(filteredVideos.slice(0, 12));
  }, [filteredVideos]);

  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        if (entries[0].isIntersecting && !isLoadingMore && displayedVideos.length < 100) {
          loadMore();
        }
      },
      { threshold: 0.1 }
    );

    if (loadMoreRef.current) observer.observe(loadMoreRef.current);
    return () => observer.disconnect();
  }, [displayedVideos, isLoadingMore]);

  const loadMore = () => {
    setIsLoadingMore(true);
    setTimeout(() => {
      setDisplayedVideos(prev => [
        ...prev, 
        ...filteredVideos.map(v => ({ ...v, id: `${v.id}-ext-${Math.random()}` })).slice(0, 8)
      ]);
      setIsLoadingMore(false);
    }, 600);
  };

  const scrollCategories = (direction: 'left' | 'right') => {
    const container = document.getElementById('category-scroll');
    if (container) {
      container.scrollBy({ left: direction === 'left' ? -400 : 400, behavior: 'smooth' });
    }
  };

  return (
    <div className="flex flex-col min-h-full bg-white">
      {/* Category Navigation - White Background */}
      <div className="sticky top-0 bg-white/95 backdrop-blur-2xl z-[55] px-4 py-3 flex items-center group/nav border-b border-[#f2f2f2]">
        <button 
          onClick={() => scrollCategories('left')} 
          className="absolute left-2 z-40 bg-white/90 p-2.5 rounded-full border border-[#e5e5e5] opacity-0 group-hover/nav:opacity-100 transition-all hover:bg-[#f2f2f2] shadow-md active:scale-90"
        >
          <ChevronLeft size={18} className="text-[#030303]" />
        </button>
        
        <div id="category-scroll" className="flex gap-3 overflow-x-auto no-scrollbar scroll-smooth w-full px-2 items-center">
          {categories.map((cat) => (
            <button 
              key={cat} 
              onClick={() => setActiveCategory(cat)} 
              className={`px-4 py-1.5 rounded-lg text-[10px] font-black transition-all whitespace-nowrap border uppercase tracking-widest ${
                activeCategory === cat 
                ? 'bg-[#030303] text-white border-[#030303] shadow-md' 
                : 'bg-[#f2f2f2] text-[#030303] hover:bg-[#e5e5e5] border-transparent'
              }`}
            >
              {cat}
            </button>
          ))}
        </div>
        
        <button 
          onClick={() => scrollCategories('right')} 
          className="absolute right-2 z-40 bg-white/90 p-2.5 rounded-full border border-[#e5e5e5] opacity-0 group-hover/nav:opacity-100 transition-all hover:bg-[#f2f2f2] shadow-md active:scale-90"
        >
          <ChevronRight size={18} className="text-[#030303]" />
        </button>
      </div>

      {!searchQuery && activeCategory === 'All' && (
        <ShortVideoHorizontalList videos={shorts} />
      )}

      <div className="px-4 sm:px-6 lg:px-8 py-6 space-y-8 bg-white">
        {searchQuery && (
          <div className="text-[#606060] text-sm font-bold flex items-center gap-4 mb-6 border-l-4 border-blue-600 pl-6 py-2">
            <Search size={18} className="text-blue-600" /> 
            <span>Showing results for <span className="text-[#030303] font-black italic">"{searchQuery}"</span></span>
          </div>
        )}

        {displayedVideos.length > 0 ? (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 2xl:grid-cols-5 gap-x-6 gap-y-10">
            {displayedVideos.map((video) => (
              <VideoCard key={video.id} video={video} />
            ))}
          </div>
        ) : (
          <div className="flex flex-col items-center justify-center py-56 text-[#606060]">
            <Sparkles size={80} className="opacity-10 mb-10 animate-pulse text-gray-400" />
            <h3 className="text-3xl font-black text-[#606060]/20 italic tracking-tighter uppercase">Feed Refreshing</h3>
          </div>
        )}

        <div ref={loadMoreRef} className="h-32 flex items-center justify-center">
          {isLoadingMore && (
            <div className="flex flex-col items-center gap-4">
              <div className="w-6 h-6 border-2 border-blue-600 border-t-transparent rounded-full animate-spin" />
              <span className="text-[9px] font-black uppercase tracking-[0.3em] text-[#606060] animate-pulse">Syncing Global Feed</span>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default Home;
