
import React, { useState, useRef, useMemo } from 'react';
import { useParams, Link } from 'react-router-dom';
import { MOCK_VIDEOS } from '../constants';
import VideoCard from '../components/VideoCard';
import ShortsCard from '../components/ShortsCard';
import SubscribeButton from '../components/SubscribeButton';
import { 
  Camera, Settings, Edit3, Check, X as CloseIcon, 
  PlayCircle, Clock, Info, Globe, Calendar, 
  TrendingUp, Play, ListVideo, ThumbsUp, ChevronRight
} from 'lucide-react';
import { VideoType, Video } from '../types';
import { useUserStore } from '../store';

const Channel: React.FC = () => {
  const { channelId } = useParams();
  const { 
    userChannel, updateChannelProfile, 
    getChannelBanner, updateChannelBanner, 
    userVideos, watchLater, likedVideos,
    getChannel // Use the getter from store to ensure real-time updates
  } = useUserStore();
  const bannerInputRef = useRef<HTMLInputElement>(null);
  const avatarInputRef = useRef<HTMLInputElement>(null);
  
  // Real-time channel data fetch: This ensures when we subscribe, the 'subscribers' count updates instantly.
  const channel = channelId === 'my-channel' || channelId === userChannel.id 
    ? userChannel 
    : getChannel(channelId || '');
  
  const isOwnChannel = channel.id === userChannel.id;
  
  // Combine mock videos with user-uploaded videos for the own channel
  const allAvailableVideos = useMemo(() => [...MOCK_VIDEOS, ...userVideos], [userVideos]);
  const channelVideos = useMemo(() => allAvailableVideos.filter(v => v.channelId === channel.id), [allAvailableVideos, channel.id]);
  
  const [activeTab, setActiveTab] = useState('Home');
  const [isEditing, setIsEditing] = useState(false);
  const [editName, setEditName] = useState(channel.name);
  const [editHandle, setEditHandle] = useState(channel.handle);

  const customBanner = getChannelBanner(channel.id);
  // Display the live subscriber count from the store
  const displaySubs = channel.subscribers;

  const handleBannerFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => updateChannelBanner(channel.id, reader.result as string);
      reader.readAsDataURL(file);
    }
  };

  const handleAvatarFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => updateChannelProfile({ avatar: reader.result as string });
      reader.readAsDataURL(file);
    }
  };

  const saveProfile = () => {
    updateChannelProfile({ name: editName, handle: editHandle });
    setIsEditing(false);
  };

  const totalViews = useMemo(() => channelVideos.reduce((acc, v) => acc + v.views, 0), [channelVideos]);

  // Tab Rendering Components
  const HomeTab = () => {
    const featuredVideo = channelVideos.find(v => v.type === VideoType.LONG);
    const recentVideos = channelVideos.filter(v => v.type === VideoType.LONG).slice(1, 5);
    const shorts = channelVideos.filter(v => v.type === VideoType.SHORT).slice(0, 6);

    return (
      <div className="space-y-12 animate-in fade-in duration-500">
        {featuredVideo ? (
          <div className="flex flex-col lg:flex-row gap-8 bg-white/5 p-6 rounded-3xl border border-white/5 group hover:bg-white/[0.08] transition-all">
            <Link to={`/watch/${featuredVideo.id}`} className="lg:w-[440px] aspect-video relative rounded-2xl overflow-hidden shadow-2xl shrink-0">
              <img src={featuredVideo.thumbnail} className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700" alt="" />
              <div className="absolute inset-0 flex items-center justify-center bg-black/20 group-hover:bg-black/0 transition-all">
                <div className="w-16 h-16 bg-white/10 backdrop-blur-md rounded-full flex items-center justify-center border border-white/20 opacity-0 group-hover:opacity-100 scale-90 group-hover:scale-100 transition-all">
                   <Play size={28} fill="white" className="text-white ml-1" />
                </div>
              </div>
              <span className="absolute bottom-3 right-3 bg-black/80 px-1.5 py-0.5 rounded text-xs font-bold">{featuredVideo.duration}</span>
            </Link>
            <div className="flex flex-col justify-center">
              <Link to={`/watch/${featuredVideo.id}`} className="text-xl sm:text-2xl font-black mb-3 group-hover:text-blue-400 transition-colors leading-tight">
                {featuredVideo.title}
              </Link>
              <div className="flex items-center gap-2 text-xs text-[#aaa] font-bold mb-4 uppercase tracking-widest">
                <span>{Intl.NumberFormat('en', { notation: 'compact' }).format(featuredVideo.views)} views</span>
                <span className="w-1 h-1 bg-[#aaa] rounded-full"></span>
                <span>{featuredVideo.timestamp}</span>
              </div>
              <p className="text-sm text-[#aaa] line-clamp-3 leading-relaxed max-w-2xl font-medium">
                {featuredVideo.description}
              </p>
            </div>
          </div>
        ) : (
          <div className="py-20 text-center bg-white/5 rounded-3xl border border-dashed border-white/10">
            <PlayCircle size={48} className="mx-auto mb-4 text-[#333]" />
            <p className="text-[#aaa] font-bold uppercase tracking-widest text-xs">No featured video available</p>
          </div>
        )}

        {recentVideos.length > 0 && (
          <section>
            <h3 className="text-lg font-black mb-6 uppercase tracking-widest text-white/90">Recent Uploads</h3>
            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
              {recentVideos.map(v => <VideoCard key={v.id} video={v} />)}
            </div>
          </section>
        )}

        {shorts.length > 0 && (
          <section>
            <div className="flex items-center justify-between mb-6">
              <h3 className="text-lg font-black uppercase tracking-widest flex items-center gap-2">
                <TrendingUp size={20} className="text-red-500" /> Pulse (Shorts)
              </h3>
            </div>
            <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-4">
              {shorts.map(s => <ShortsCard key={s.id} video={s} />)}
            </div>
          </section>
        )}
      </div>
    );
  };

  const PlaylistsTab = () => {
    const playlists = isOwnChannel ? [
      { id: 'liked', name: 'Liked videos', count: likedVideos.length, icon: <ThumbsUp size={32} /> },
      { id: 'watch-later', name: 'Watch later', count: watchLater.length, icon: <Clock size={32} /> },
    ] : [
      { id: 'm1', name: 'Best of ' + channel.name, count: 12, icon: <ListVideo size={32} /> },
      { id: 'm2', name: 'Tutorials', count: 5, icon: <ListVideo size={32} /> }
    ];

    return (
      <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 gap-8 animate-in fade-in duration-500">
        {playlists.map(p => (
          <Link key={p.id} to={isOwnChannel ? `/${p.id}` : '#'} className="group">
            <div className="aspect-video bg-white/5 rounded-2xl mb-4 flex flex-col items-center justify-center relative overflow-hidden border border-white/5 group-hover:border-white/20 transition-all shadow-xl">
               <div className="text-white/20 group-hover:text-white/40 transition-colors">{p.icon}</div>
               <div className="absolute bottom-0 left-0 right-0 bg-black/60 backdrop-blur-md p-2 flex items-center justify-between">
                  <ListVideo size={16} className="text-[#aaa]" />
                  <span className="text-[10px] font-black uppercase tracking-widest">{p.count} Videos</span>
               </div>
            </div>
            <h4 className="font-black text-sm group-hover:text-blue-400 transition-colors uppercase tracking-tight">{p.name}</h4>
            <p className="text-[10px] text-[#aaa] font-bold mt-1 uppercase tracking-widest">View Full Playlist</p>
          </Link>
        ))}
      </div>
    );
  };

  const AboutTab = () => (
    <div className="flex flex-col lg:flex-row gap-16 animate-in fade-in duration-500">
      <div className="flex-1 space-y-12">
        <section>
          <h3 className="text-xs font-black uppercase tracking-[0.3em] text-[#aaa] mb-4">Description</h3>
          <p className="text-base text-gray-200 leading-relaxed font-medium whitespace-pre-wrap">
            {channel.description}
          </p>
        </section>
        
        <section>
          <h3 className="text-xs font-black uppercase tracking-[0.3em] text-[#aaa] mb-4">Channel Details</h3>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div className="flex items-center gap-4 bg-white/5 p-4 rounded-2xl border border-white/5">
              <Globe size={20} className="text-blue-500" />
              <div>
                <p className="text-[10px] font-black uppercase tracking-widest text-[#aaa]">Location</p>
                <p className="text-sm font-bold">United States</p>
              </div>
            </div>
            <div className="flex items-center gap-4 bg-white/5 p-4 rounded-2xl border border-white/5">
              <Calendar size={20} className="text-indigo-500" />
              <div>
                <p className="text-[10px] font-black uppercase tracking-widest text-[#aaa]">Joined</p>
                <p className="text-sm font-bold">{channel.joinedDate}</p>
              </div>
            </div>
          </div>
        </section>
      </div>

      <div className="lg:w-80 space-y-10">
        <section>
          <h3 className="text-xs font-black uppercase tracking-[0.3em] text-[#aaa] mb-6">Stats</h3>
          <div className="space-y-6">
             <div className="flex items-center justify-between py-3 border-b border-white/5">
                <span className="text-sm font-bold text-[#aaa]">Total Views</span>
                <span className="text-sm font-black">{Intl.NumberFormat('en').format(totalViews)}</span>
             </div>
             <div className="flex items-center justify-between py-3 border-b border-white/5">
                <span className="text-sm font-bold text-[#aaa]">Subscribers</span>
                <span className="text-sm font-black">{Intl.NumberFormat('en').format(displaySubs)}</span>
             </div>
             <div className="flex items-center justify-between py-3 border-b border-white/5">
                <span className="text-sm font-bold text-[#aaa]">Videos</span>
                <span className="text-sm font-black">{channelVideos.length}</span>
             </div>
          </div>
        </section>

        <button className="w-full flex items-center justify-between p-4 bg-white/5 hover:bg-white/10 rounded-2xl border border-white/10 transition-all active:scale-95 group">
           <span className="text-xs font-black uppercase tracking-widest">Share Channel</span>
           <ChevronRight size={18} className="text-[#aaa] group-hover:translate-x-1 transition-transform" />
        </button>
      </div>
    </div>
  );

  return (
    <div className="flex flex-col bg-[#0f0f0f] min-h-full">
      {/* Dynamic Banner */}
      <div className="w-full relative group">
        <div 
          className="w-full aspect-[4/1] md:aspect-[6.25/1] bg-[#1e1e1e] relative transition-all duration-700"
          style={{ 
            background: customBanner ? `url(${customBanner}) center/cover no-repeat` : 'linear-gradient(to right, #1e3a8a, #312e81, #581c87)',
            boxShadow: 'inset 0 -120px 80px -40px #0f0f0f' 
          }}
        >
          {isOwnChannel && (
            <div className="absolute top-4 right-4 z-20">
              <input type="file" ref={bannerInputRef} className="hidden" accept="image/*" onChange={handleBannerFileChange} />
              <button onClick={() => bannerInputRef.current?.click()} className="px-4 py-2 bg-black/60 hover:bg-black/80 backdrop-blur-md rounded-full text-white opacity-0 group-hover:opacity-100 transition-all flex items-center gap-2 text-[10px] font-black uppercase tracking-widest border border-white/10">
                <Camera size={16} /> Update banner
              </button>
            </div>
          )}
        </div>
      </div>

      <div className="max-w-[1284px] mx-auto px-4 lg:px-6 py-6 w-full -mt-8 sm:-mt-12 lg:-mt-16 z-10">
        <div className="flex flex-col sm:flex-row gap-6 items-start sm:items-center">
          <div className="relative group/avatar">
            <div className="w-24 h-24 sm:w-40 sm:h-40 rounded-full border-[6px] border-[#0f0f0f] bg-[#272727] overflow-hidden shadow-2xl">
              <img src={channel.avatar} className="w-full h-full object-cover transition-transform group-hover/avatar:scale-110 duration-500" alt="" />
            </div>
            {isOwnChannel && (
              <button 
                onClick={() => avatarInputRef.current?.click()}
                className="absolute inset-[6px] bg-black/40 rounded-full flex items-center justify-center opacity-0 group-hover/avatar:opacity-100 transition-opacity backdrop-blur-sm"
              >
                <Camera size={32} className="text-white" />
                <input type="file" ref={avatarInputRef} className="hidden" accept="image/*" onChange={handleAvatarFileChange} />
              </button>
            )}
          </div>

          <div className="flex-1">
            {isEditing ? (
              <div className="space-y-4 mb-4 animate-in fade-in slide-in-from-left-4">
                <input value={editName} onChange={e => setEditName(e.target.value)} className="bg-transparent border-b-2 border-blue-500 text-2xl sm:text-4xl font-black outline-none w-full pb-2" autoFocus />
                <input value={editHandle} onChange={e => setEditHandle(e.target.value)} className="bg-transparent border-b border-[#3e3e3e] text-[#aaa] text-sm outline-none w-full pb-1" />
                <div className="flex gap-3">
                  <button onClick={saveProfile} className="px-6 py-2 bg-white text-black rounded-full text-xs font-black uppercase tracking-widest flex items-center gap-2 shadow-xl hover:bg-gray-200 active:scale-95 transition-all"><Check size={16} /> Save</button>
                  <button onClick={() => setIsEditing(false)} className="px-6 py-2 bg-white/5 text-white rounded-full text-xs font-black uppercase tracking-widest flex items-center gap-2 border border-white/10 hover:bg-white/10 active:scale-95 transition-all"><CloseIcon size={16} /> Cancel</button>
                </div>
              </div>
            ) : (
              <>
                <h1 className="text-2xl sm:text-4xl font-black text-white flex items-center gap-4 tracking-tighter italic uppercase">
                  {channel.name}
                  {isOwnChannel && <button onClick={() => setIsEditing(true)} className="p-2 hover:bg-white/10 rounded-full transition-colors"><Edit3 size={18} className="text-[#aaa]" /></button>}
                </h1>
                <div className="flex flex-wrap items-center gap-2.5 text-[#aaa] text-sm mb-6 mt-2 font-bold uppercase tracking-wider">
                  <span className="text-[#3ea6ff]">{channel.handle}</span>
                  <span className="w-1 h-1 bg-white/20 rounded-full"></span>
                  <span className="text-white">{Intl.NumberFormat('en', { notation: 'compact' }).format(displaySubs)} subscribers</span>
                  <span className="w-1 h-1 bg-white/20 rounded-full"></span>
                  <span>{channelVideos.length} videos</span>
                </div>
              </>
            )}
            
            <div className="flex gap-4 items-center">
              {isOwnChannel ? (
                <div className="flex gap-3">
                  <Link to="/studio" className="px-8 py-2.5 bg-[#272727] text-white rounded-full font-black uppercase tracking-widest hover:bg-[#3f3f3f] text-xs flex items-center gap-2 transition-all active:scale-95 border border-white/5"><Settings size={18} /> Customize</Link>
                  <Link to="/studio" className="px-8 py-2.5 bg-white text-black rounded-full font-black uppercase tracking-widest hover:bg-gray-200 text-xs flex items-center gap-2 transition-all active:scale-95 shadow-xl">Manage Content</Link>
                </div>
              ) : (
                <div className="flex gap-3">
                  <SubscribeButton channelId={channel.id} />
                  <button className="px-8 py-2.5 bg-white/5 text-white rounded-full font-black uppercase tracking-widest text-xs hover:bg-white/10 transition-all border border-white/10 active:scale-95">Join Pulse</button>
                </div>
              )}
            </div>
          </div>
        </div>

        {/* Tab Navigation */}
        <div className="flex items-center gap-2 sm:gap-6 mt-12 border-b border-white/5 overflow-x-auto no-scrollbar scroll-smooth">
          {['Home', 'Videos', 'Shorts', 'Playlists', 'About'].map((tab) => (
            <button 
              key={tab} 
              onClick={() => setActiveTab(tab)} 
              className={`pb-4 text-xs font-black uppercase tracking-[0.2em] transition-all whitespace-nowrap px-4 border-b-2 relative ${activeTab === tab ? 'border-white text-white' : 'border-transparent text-[#666] hover:text-white hover:border-white/20'}`}
            >
              {tab}
              {activeTab === tab && <div className="absolute inset-0 bg-white/5 rounded-t-xl -z-10 animate-in fade-in duration-300" />}
            </button>
          ))}
        </div>
        
        {/* Tab Content */}
        <div className="py-10">
          {activeTab === 'Home' && <HomeTab />}
          {activeTab === 'Videos' && (
            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 gap-x-6 gap-y-12 animate-in fade-in duration-500">
              {channelVideos.filter(v => v.type === VideoType.LONG).map(video => <VideoCard key={video.id} video={video} />)}
            </div>
          )}
          {activeTab === 'Shorts' && (
            <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6 gap-4 animate-in fade-in duration-500">
              {channelVideos.filter(v => v.type === VideoType.SHORT).map(video => <ShortsCard key={video.id} video={video} />)}
            </div>
          )}
          {activeTab === 'Playlists' && <PlaylistsTab />}
          {activeTab === 'About' && <AboutTab />}
        </div>
      </div>
      
      <style>{`
        .no-scrollbar::-webkit-scrollbar { display: none; }
        .no-scrollbar { -ms-overflow-style: none; scrollbar-width: none; }
      `}</style>
    </div>
  );
};

export default Channel;
