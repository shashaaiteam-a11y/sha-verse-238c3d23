
import React, { useState, useRef, useEffect } from 'react';
import { 
  Upload as UploadIcon, X, CheckCircle, Info, FileVideo, 
  Music, Image as ImageIcon, Globe, Lock, EyeOff, 
  ArrowRight, ArrowLeft, Play, AlertCircle, Settings, 
  ShieldCheck, Loader2, Tag, Layout, Smartphone, 
  RefreshCcw, Clock, AlertTriangle, Camera
} from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { useUserStore } from '../store';
import { VideoType, Video } from '../types';

const CATEGORIES = [
  'Tech', 'Gaming', 'Music', 'Cooking', 'Travel', 
  'Education', 'Comedy', 'Entertainment', 'News', 'Lifestyle'
];

const Upload: React.FC = () => {
  const [step, setStep] = useState(1);
  const [videoType, setVideoType] = useState<'long' | 'short'>('long');
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [category, setCategory] = useState('Entertainment');
  const [tags, setTags] = useState('');
  const [visibility, setVisibility] = useState<'public' | 'private' | 'unlisted'>('public');
  
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [previewUrl, setPreviewUrl] = useState<string | null>(null);
  const [thumbnailUrl, setThumbnailUrl] = useState<string | null>(null);
  
  const [error, setError] = useState<string | null>(null);
  const [processingProgress, setProcessingProgress] = useState(0);
  const [processingStatus, setProcessingStatus] = useState('');
  
  const { uploadVideo, userChannel } = useUserStore();
  const fileInputRef = useRef<HTMLInputElement>(null);
  const thumbInputRef = useRef<HTMLInputElement>(null);
  const videoPreviewRef = useRef<HTMLVideoElement>(null);
  const stepHeaderRef = useRef<HTMLHeadingElement>(null);
  const navigate = useNavigate();

  useEffect(() => {
    return () => {
      if (previewUrl) URL.revokeObjectURL(previewUrl);
      if (thumbnailUrl && thumbnailUrl.startsWith('blob:')) URL.revokeObjectURL(thumbnailUrl);
    };
  }, [previewUrl, thumbnailUrl]);

  useEffect(() => {
    stepHeaderRef.current?.focus();
  }, [step]);

  // Logic to capture current frame as thumbnail
  const captureThumbnail = () => {
    const video = videoPreviewRef.current;
    if (video) {
      const canvas = document.createElement('canvas');
      canvas.width = video.videoWidth;
      canvas.height = video.videoHeight;
      const ctx = canvas.getContext('2d');
      if (ctx) {
        ctx.drawImage(video, 0, 0, canvas.width, canvas.height);
        canvas.toBlob((blob) => {
          if (blob) {
            if (thumbnailUrl && thumbnailUrl.startsWith('blob:')) URL.revokeObjectURL(thumbnailUrl);
            setThumbnailUrl(URL.createObjectURL(blob));
          }
        }, 'image/jpeg', 0.8);
      }
    }
  };

  // Validation Logic for Shorts
  const validateShort = (videoEl: HTMLVideoElement) => {
    if (videoType === 'short') {
      if (videoEl.duration > 60) {
        setError("Shorts must be less than 60 seconds.");
        return false;
      }
      if (videoEl.videoWidth > videoEl.videoHeight) {
        setError("Shorts must be in a vertical or square aspect ratio.");
        return false;
      }
    }
    setError(null);
    return true;
  };

  useEffect(() => {
    let interval: number;
    if (step === 4) {
      setProcessingStatus(videoType === 'short' ? 'Optimizing for Pulse Feed...' : 'Compressing video for 4K HDR...');
      interval = window.setInterval(() => {
        setProcessingProgress(prev => {
          const next = prev + Math.random() * 5;
          
          if (next >= 100) {
            clearInterval(interval);
            
            const newVideo: Video = {
              id: `uv-${Math.random().toString(36).substr(2, 9)}`,
              title: title || 'Untitled Video',
              description: description || 'No description provided.',
              thumbnail: thumbnailUrl || (videoType === 'long' ? 'https://picsum.photos/seed/thumb/640/360' : 'https://picsum.photos/seed/short/360/640'),
              videoUrl: previewUrl || 'https://www.w3schools.com/html/mov_bbb.mp4',
              type: videoType === 'long' ? VideoType.LONG : VideoType.SHORT,
              views: 0,
              likes: 0,
              dislikes: 0,
              timestamp: 'Just now',
              duration: videoType === 'long' ? '04:20' : '0:15',
              channelId: userChannel.id,
              channelName: userChannel.name,
              channelAvatar: userChannel.avatar,
              category: category,
              tags: tags.split(',').map(t => t.trim()).filter(Boolean),
              visibility: visibility
            };
            
            uploadVideo(newVideo);
            setTimeout(() => navigate('/studio'), 1000);
            return 100;
          }

          if (videoType === 'short') {
            if (next > 90) setProcessingStatus('Adding loop points...');
            else if (next > 70) setProcessingStatus('Syncing audio tracks...');
            else if (next > 40) setProcessingStatus('Vertical framing check...');
            else if (next > 15) setProcessingStatus('Pulse algorithm indexing...');
          } else {
            if (next > 90) setProcessingStatus('Generating feed eligibility tags...');
            else if (next > 75) setProcessingStatus('Applying color grading profiles...');
            else if (next > 55) setProcessingStatus('Processing thumbnail transparency...');
            else if (next > 35) setProcessingStatus('Analyzing for content safety...');
            else if (next > 15) setProcessingStatus('Encoding multi-bitrate streams...');
          }
          
          return next;
        });
      }, 250);
    }
    return () => clearInterval(interval);
  }, [step, navigate, title, description, videoType, previewUrl, thumbnailUrl, category, tags, visibility, uploadVideo, userChannel]);

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      const file = e.target.files[0];
      setSelectedFile(file);
      const lastDot = file.name.lastIndexOf('.');
      setTitle(lastDot !== -1 ? file.name.substring(0, lastDot) : file.name);
      setPreviewUrl(URL.createObjectURL(file));
      setStep(2);
      setError(null);
    }
  };

  const handleThumbChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      setThumbnailUrl(URL.createObjectURL(e.target.files[0]));
    }
  };

  const triggerFileSelect = (type: 'long' | 'short') => {
    setVideoType(type);
    fileInputRef.current?.click();
  };

  const ProgressStep = ({ num, label, current }: { num: number; label: string; current: number }) => (
    <div className="flex items-center gap-2">
      <div className={`w-6 h-6 rounded-full flex items-center justify-center text-xs font-bold transition-colors ${num <= current ? (videoType === 'short' ? 'bg-red-500 text-white' : 'bg-[#3ea6ff] text-black') : 'bg-[#3e3e3e] text-[#aaa]'}`}>
        {num < current ? <CheckCircle size={14} /> : num}
      </div>
      <span className={`text-xs font-medium hidden sm:inline ${num <= current ? 'text-white' : 'text-[#aaa]'}`}>{label}</span>
      {num < 3 && <div className={`w-8 h-[1px] ${num < current ? (videoType === 'short' ? 'bg-red-500' : 'bg-[#3ea6ff]') : 'bg-[#3e3e3e]'}`} />}
    </div>
  );

  return (
    <div className="min-h-[calc(100vh-56px)] bg-[#0f0f0f] flex items-center justify-center p-4">
      <div className="bg-[#1e1e1e] w-full max-w-[1100px] min-h-[700px] rounded-3xl shadow-2xl overflow-hidden flex flex-col border border-white/5">
        
        {/* Header */}
        <div className="flex flex-col sm:flex-row items-center justify-between px-6 py-4 border-b border-white/5 gap-4">
          <div className="flex items-center gap-3">
             {videoType === 'short' && selectedFile && <Smartphone size={20} className="text-red-500" />}
             <h2 ref={stepHeaderRef} tabIndex={-1} className={`text-lg font-black italic uppercase tracking-tighter outline-none ${videoType === 'short' && selectedFile ? 'text-red-500' : 'text-[#3ea6ff]'}`}>
              {selectedFile ? (videoType === 'short' ? 'Upload Short Pulse' : 'Upload Video Details') : 'MOVION Creator Hub'}
            </h2>
          </div>
          
          <nav className="flex items-center gap-2 sm:gap-6">
            <ProgressStep num={1} label="Upload" current={step} />
            <ProgressStep num={2} label="Metadata" current={step} />
            <ProgressStep num={3} label="Visibility" current={step} />
          </nav>

          <button onClick={() => navigate('/studio')} className="p-2 hover:bg-white/5 rounded-full text-[#aaa] transition-colors">
            <X size={24} />
          </button>
        </div>

        {/* Content */}
        <div className="flex-1 overflow-y-auto no-scrollbar">
          {step === 1 && (
            <div className="flex flex-col items-center justify-center h-full p-8 sm:p-20 text-center gap-10">
              <input type="file" ref={fileInputRef} onChange={handleFileChange} className="hidden" accept="video/*" />
              <div className="relative group">
                <div className={`absolute inset-0 blur-[60px] rounded-full scale-150 transition-all ${videoType === 'short' ? 'bg-red-500/10 group-hover:bg-red-500/20' : 'bg-[#3ea6ff]/10 group-hover:bg-[#3ea6ff]/20'}`}></div>
                <button 
                  onClick={() => triggerFileSelect('long')}
                  className="relative w-32 h-32 bg-white/5 rounded-[40px] flex items-center justify-center text-[#909090] cursor-pointer hover:bg-white/10 transition-all group border-2 border-dashed border-white/10 hover:border-[#3ea6ff]"
                >
                  <UploadIcon size={48} className="group-hover:text-[#3ea6ff] transition-colors" />
                </button>
              </div>
              <div className="space-y-8 w-full max-w-lg">
                <div className="flex flex-col sm:flex-row gap-4">
                  <button onClick={() => triggerFileSelect('long')} className="flex-1 bg-white text-black py-5 rounded-2xl font-black uppercase tracking-widest text-xs hover:bg-gray-200 transition-all flex flex-col items-center gap-2 shadow-xl shadow-white/5">
                    <FileVideo size={20} />
                    <span>Long Video</span>
                  </button>
                  <button onClick={() => triggerFileSelect('short')} className="flex-1 bg-red-600 text-white py-5 rounded-2xl font-black uppercase tracking-widest text-xs hover:bg-red-500 transition-all flex flex-col items-center gap-2 shadow-xl shadow-red-600/20">
                    <Smartphone size={20} />
                    <span>Short Pulse</span>
                  </button>
                </div>
                <div className="flex flex-col gap-2">
                   <p className="text-xs text-[#555] font-black uppercase tracking-[0.2em]">Select your format and start the journey</p>
                   <div className="flex items-center justify-center gap-4 text-[10px] text-[#444] font-bold">
                      <span className="flex items-center gap-1"><Clock size={12}/> Max 60s for Shorts</span>
                      <span className="flex items-center gap-1"><Smartphone size={12}/> Vertical Aspect only</span>
                   </div>
                </div>
              </div>
            </div>
          )}

          {step === 2 && (
            <div className="flex flex-col lg:flex-row h-full">
              <div className="flex-1 p-8 space-y-8 lg:border-r border-white/5">
                {error && (
                  <div className="bg-red-500/10 border border-red-500/20 p-4 rounded-xl flex items-center gap-3 text-red-500 animate-in fade-in slide-in-from-top-2">
                    <AlertTriangle size={20} />
                    <p className="text-sm font-bold">{error}</p>
                  </div>
                )}

                <div className="space-y-6">
                  <div className="space-y-2">
                    <label className="text-[10px] font-black uppercase tracking-widest text-[#555]">Title (required)</label>
                    <input autoFocus value={title} onChange={(e) => setTitle(e.target.value)} className={`w-full bg-white/5 border border-white/5 rounded-xl p-4 outline-none transition-all text-sm font-bold ${videoType === 'short' ? 'focus:border-red-500' : 'focus:border-[#3ea6ff]'}`} placeholder={videoType === 'short' ? "Something catchy for the pulse feed..." : "Give your video a name..."} />
                  </div>
                  <div className="space-y-2">
                    <label className="text-[10px] font-black uppercase tracking-widest text-[#555]">Description</label>
                    <textarea rows={3} value={description} onChange={(e) => setDescription(e.target.value)} className={`w-full bg-white/5 border border-white/5 rounded-xl p-4 outline-none transition-all resize-none text-sm font-medium ${videoType === 'short' ? 'focus:border-red-500' : 'focus:border-[#3ea6ff]'}`} placeholder="Tell viewers about your creation..." />
                  </div>
                  
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div className="space-y-2">
                      <label className="text-[10px] font-black uppercase tracking-widest text-[#555]">Category</label>
                      <select value={category} onChange={e => setCategory(e.target.value)} className={`w-full bg-white/5 border border-white/5 rounded-xl p-4 outline-none transition-all text-sm font-bold appearance-none ${videoType === 'short' ? 'focus:border-red-500' : 'focus:border-[#3ea6ff]'}`}>
                        {CATEGORIES.map(c => <option key={c} value={c}>{c}</option>)}
                      </select>
                    </div>
                    <div className="space-y-2">
                      <label className="text-[10px] font-black uppercase tracking-widest text-[#555]">Tags (comma separated)</label>
                      <div className="relative">
                        <Tag size={16} className="absolute left-4 top-1/2 -translate-y-1/2 text-[#555]" />
                        <input value={tags} onChange={e => setTags(e.target.value)} className={`w-full bg-white/5 border border-white/5 rounded-xl pl-12 pr-4 py-4 outline-none transition-all text-sm font-bold ${videoType === 'short' ? 'focus:border-red-500' : 'focus:border-[#3ea6ff]'}`} placeholder="vibe, shorts, viral..." />
                      </div>
                    </div>
                  </div>

                  <div className="space-y-4">
                    <label className="text-[10px] font-black uppercase tracking-widest text-[#555]">Thumbnail Generation</label>
                    <div className="flex flex-wrap gap-4">
                      <input type="file" ref={thumbInputRef} onChange={handleThumbChange} className="hidden" accept="image/*" />
                      <button 
                        onClick={() => thumbInputRef.current?.click()}
                        className={`w-40 h-24 bg-white/5 border-2 border-dashed border-white/10 rounded-xl flex flex-col items-center justify-center gap-2 hover:bg-white/10 transition-all text-[#aaa] group ${videoType === 'short' ? 'hover:border-red-500' : 'hover:border-blue-500'}`}
                      >
                        <ImageIcon size={20} className={`transition-colors ${videoType === 'short' ? 'group-hover:text-red-500' : 'group-hover:text-blue-500'}`} />
                        <span className="text-[10px] font-black uppercase">Custom Image</span>
                      </button>
                      
                      <button 
                        onClick={captureThumbnail}
                        className={`w-40 h-24 bg-white/5 border-2 border-dashed border-white/10 rounded-xl flex flex-col items-center justify-center gap-2 hover:bg-white/10 transition-all text-[#aaa] group ${videoType === 'short' ? 'hover:border-red-500' : 'hover:border-blue-500'}`}
                      >
                        <Camera size={20} className={`transition-colors ${videoType === 'short' ? 'group-hover:text-red-500' : 'group-hover:text-blue-500'}`} />
                        <span className="text-[10px] font-black uppercase">Capture Frame</span>
                      </button>

                      {thumbnailUrl && (
                        <div className="w-40 h-24 rounded-xl overflow-hidden border border-white/10 relative group">
                          <img src={thumbnailUrl} className="w-full h-full object-cover" alt="Thumbnail" />
                          <button onClick={() => {
                            if (thumbnailUrl.startsWith('blob:')) URL.revokeObjectURL(thumbnailUrl);
                            setThumbnailUrl(null);
                          }} className="absolute top-1 right-1 p-1 bg-black/60 rounded-full hover:bg-red-600 opacity-0 group-hover:opacity-100 transition-opacity"><X size={12}/></button>
                        </div>
                      )}
                    </div>
                    <p className="text-[9px] text-[#444] font-bold uppercase">Pro tip: Play the video preview and click "Capture Frame" at your favorite moment.</p>
                  </div>
                </div>

                <div className="flex justify-between items-center pt-8 border-t border-white/5">
                  <button onClick={() => setStep(1)} className="flex items-center gap-2 text-xs font-black uppercase tracking-widest text-[#555] hover:text-white transition-colors">
                    <ArrowLeft size={16} /> Back
                  </button>
                  <button 
                    onClick={() => {
                      if (videoPreviewRef.current && validateShort(videoPreviewRef.current)) {
                        setStep(3);
                      }
                    }} 
                    disabled={!title || !!error} 
                    className={`px-10 py-3 rounded-full text-xs font-black uppercase tracking-widest disabled:opacity-30 transition-all shadow-xl ${videoType === 'short' ? 'bg-red-600 text-white hover:bg-red-500' : 'bg-white text-black hover:bg-gray-200'}`}
                  >
                    Next: Visibility
                  </button>
                </div>
              </div>

              {/* Preview Sidebar */}
              <div className="lg:w-80 bg-black/40 p-8 flex flex-col gap-6">
                <p className="text-[10px] font-black uppercase tracking-[0.3em] text-[#555] mb-2">Immersive Preview</p>
                <div className={`rounded-2xl overflow-hidden border border-white/5 relative shadow-2xl group bg-black ${videoType === 'short' ? 'aspect-[9/16]' : 'aspect-video'}`}>
                  {previewUrl && (
                    <video 
                      ref={videoPreviewRef}
                      src={previewUrl} 
                      className="w-full h-full object-contain" 
                      controls
                      loop={videoType === 'short'}
                      onLoadedMetadata={(e) => validateShort(e.currentTarget)}
                    />
                  )}
                  {!previewUrl && <div className="w-full h-full flex items-center justify-center text-[#333]"><Play size={40} /></div>}
                  {videoType === 'short' && (
                    <div className="absolute top-3 right-3 p-1.5 bg-red-600 rounded-lg text-white shadow-lg animate-pulse">
                      <RefreshCcw size={14} />
                    </div>
                  )}
                </div>
                <div className="space-y-6">
                  <div>
                    <p className="text-[9px] text-[#555] font-black uppercase tracking-widest mb-1">Type</p>
                    <p className={`text-xs font-black uppercase tracking-widest flex items-center gap-2 ${videoType === 'short' ? 'text-red-500' : 'text-blue-500'}`}>
                      {videoType === 'short' ? <Smartphone size={14}/> : <FileVideo size={14}/>}
                      {videoType === 'short' ? 'Vertical Pulse' : 'Standard Cinematic'}
                    </p>
                  </div>
                  <div>
                    <p className="text-[9px] text-[#555] font-black uppercase tracking-widest mb-1">Status</p>
                    <p className="text-xs font-bold text-green-500 flex items-center gap-1"><CheckCircle size={14}/> Ready for processing</p>
                  </div>
                </div>
              </div>
            </div>
          )}

          {step === 3 && (
            <div className="p-8 max-w-4xl mx-auto flex flex-col h-full items-center justify-center">
              <div className={`w-20 h-20 rounded-[30px] flex items-center justify-center mb-8 ${videoType === 'short' ? 'bg-red-500/10 text-red-500' : 'bg-[#3ea6ff]/10 text-[#3ea6ff]'}`}>
                <Globe size={40} />
              </div>
              <h3 className="text-3xl font-black italic uppercase tracking-tighter mb-4 text-center">Visibility & Distribution</h3>
              <p className="text-sm font-bold text-[#555] mb-12 text-center">Choose when your {videoType === 'short' ? 'pulse' : 'video'} goes live and who can see it.</p>
              
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6 w-full mb-16">
                {[
                  { id: 'public', label: 'Public', icon: <Globe size={24} />, desc: 'Visible to everyone globally' },
                  { id: 'unlisted', label: 'Unlisted', icon: <EyeOff size={24} />, desc: 'Accessible via link only' },
                  { id: 'private', label: 'Private', icon: <Lock size={24} />, desc: 'Private to your eyes only' },
                ].map(opt => (
                  <button 
                    key={opt.id}
                    onClick={() => setVisibility(opt.id as any)}
                    className={`flex flex-col items-center text-center p-8 rounded-3xl border-2 transition-all group ${visibility === opt.id ? (videoType === 'short' ? 'bg-red-500/10 border-red-500 shadow-[0_0_30px_rgba(239,68,68,0.15)]' : 'bg-[#3ea6ff]/10 border-[#3ea6ff] shadow-[0_0_30px_rgba(62,166,255,0.15)]') : 'bg-white/5 border-white/5 hover:border-white/20'}`}
                  >
                    <div className={`p-4 rounded-2xl mb-4 transition-colors ${visibility === opt.id ? (videoType === 'short' ? 'bg-red-500 text-white' : 'bg-[#3ea6ff] text-black') : 'bg-white/5 text-[#555] group-hover:text-white'}`}>
                      {opt.icon}
                    </div>
                    <span className="text-sm font-black uppercase tracking-widest mb-2">{opt.label}</span>
                    <span className="text-[10px] font-bold text-[#555] font-medium leading-relaxed">{opt.desc}</span>
                  </button>
                ))}
              </div>

              <div className="flex gap-4 w-full max-w-md">
                <button onClick={() => setStep(2)} className="flex-1 py-4 border border-white/5 rounded-2xl text-xs font-black uppercase tracking-widest hover:bg-white/5 transition-all text-[#aaa]">Edit Metadata</button>
                <button onClick={() => setStep(4)} className={`flex-1 py-4 rounded-2xl text-xs font-black uppercase tracking-widest transition-all shadow-xl ${videoType === 'short' ? 'bg-red-600 text-white hover:bg-red-500 shadow-red-500/20' : 'bg-white text-black hover:bg-gray-200 shadow-white/10'}`}>Publish Now</button>
              </div>
            </div>
          )}

          {step === 4 && (
            <div className="flex flex-col items-center justify-center h-full p-12 text-center">
              <div className="relative mb-16">
                <div className={`w-56 h-56 border-[2px] border-t-transparent rounded-full animate-spin ${videoType === 'short' ? 'border-red-500' : 'border-[#3ea6ff]'}`}></div>
                <div className="absolute inset-0 flex items-center justify-center">
                  <div className="w-40 h-40 bg-white/5 rounded-full flex flex-col items-center justify-center gap-2">
                    <Loader2 size={48} className={`animate-pulse ${videoType === 'short' ? 'text-red-500' : 'text-[#3ea6ff]'}`} />
                    <span className={`text-xs font-black animate-pulse ${videoType === 'short' ? 'text-red-500' : 'text-[#3ea6ff]'}`}>{videoType === 'short' ? 'POLISHING' : 'OPTIMIZING'}</span>
                  </div>
                </div>
              </div>
              <div className="space-y-6 max-w-sm">
                <h4 className="text-5xl font-black italic tracking-tighter text-white">{Math.floor(processingProgress)}%</h4>
                <p className={`text-xs font-black animate-pulse uppercase tracking-[0.3em] ${videoType === 'short' ? 'text-red-500' : 'text-[#3ea6ff]'}`}>{processingStatus}</p>
                <div className="w-full h-2 bg-white/5 rounded-full overflow-hidden p-0.5 border border-white/10">
                  <div className={`h-full rounded-full transition-all duration-300 ${videoType === 'short' ? 'bg-gradient-to-r from-red-700 to-red-500 shadow-[0_0_15px_rgba(239,68,68,0.5)]' : 'bg-gradient-to-r from-blue-600 to-[#3ea6ff] shadow-[0_0_15px_rgba(62,166,255,0.5)]'}`} style={{ width: `${processingProgress}%` }}></div>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
      
      <style>{`
        .no-scrollbar::-webkit-scrollbar { display: none; }
        .no-scrollbar { -ms-overflow-style: none; scrollbar-width: none; }
      `}</style>
    </div>
  );
};

export default Upload;
