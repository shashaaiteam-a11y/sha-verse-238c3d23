
import React, { useState, useMemo } from 'react';
import { 
  Plus, LayoutDashboard, BarChart2, Video as VideoIcon, 
  Target, Trophy, Zap, ShieldCheck,
  Star, TrendingUp, Globe,
  Cpu, Scale, Users, BarChart3, Clock,
  MessageSquare, Eye, Edit3, Trash2, ExternalLink, Activity,
  PlayCircle
} from 'lucide-react';
import { useUserStore } from '../store';
import { Link, useNavigate } from 'react-router-dom';
import AnalyticsGraph from '../components/AnalyticsGraph';

type StudioTab = 'dashboard' | 'content' | 'analytics' | 'comments' | 'monetization';

const Studio: React.FC = () => {
  const [activeTab, setActiveTab] = useState<StudioTab>('dashboard');
  const { userVideos, userChannel, videoAnalytics, deleteVideo } = useUserStore();
  const navigate = useNavigate();

  const totalViews = useMemo(() => userVideos.reduce((acc: number, v: any) => acc + (videoAnalytics[v.id]?.views || 0), 0), [userVideos, videoAnalytics]);

  const mockAnalyticsData = [
    { day: 'Mon', views: 2400 }, { day: 'Tue', views: 1398 }, { day: 'Wed', views: 9800 },
    { day: 'Thu', views: 3908 }, { day: 'Fri', views: 4800 }, { day: 'Sat', views: 3800 }, { day: 'Sun', views: 4300 },
  ];

  const DashboardView = () => (
    <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 animate-in fade-in duration-500">
      <div className="lg:col-span-2 space-y-6">
        <div className="bg-[#1e1e1e] rounded-3xl p-8 border border-white/5 relative overflow-hidden group">
          <h3 className="text-xs font-black uppercase tracking-[0.3em] text-[#555] mb-6">Latest Video Performance</h3>
          {userVideos.length > 0 ? (
            <div className="flex flex-col md:flex-row gap-8">
              <div className="w-full md:w-64 aspect-video rounded-2xl overflow-hidden bg-black shrink-0 relative group">
                <img src={userVideos[0].thumbnail} className="w-full h-full object-cover transition-transform group-hover:scale-105" alt="" />
                <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 flex items-center justify-center transition-opacity">
                   <button onClick={() => navigate(`/watch/${userVideos[0].id}`)} className="p-3 bg-white text-black rounded-full"><PlayCircle size={24}/></button>
                </div>
              </div>
              <div className="flex-1 space-y-4">
                <h4 className="text-xl font-black tracking-tight">{userVideos[0].title}</h4>
                <div className="grid grid-cols-3 gap-4">
                  <div className="bg-white/5 p-4 rounded-2xl">
                    <p className="text-[10px] font-black uppercase tracking-widest text-[#555] mb-1">Views</p>
                    <p className="text-lg font-bold">{videoAnalytics[userVideos[0].id]?.views || 0}</p>
                  </div>
                  <div className="bg-white/5 p-4 rounded-2xl">
                    <p className="text-[10px] font-black uppercase tracking-widest text-[#555] mb-1">CTR</p>
                    <p className="text-lg font-bold">12.4%</p>
                  </div>
                  <div className="bg-white/5 p-4 rounded-2xl">
                    <p className="text-[10px] font-black uppercase tracking-widest text-[#555] mb-1">Engage</p>
                    <p className="text-lg font-bold">8.1%</p>
                  </div>
                </div>
              </div>
            </div>
          ) : (
            <div className="py-12 flex flex-col items-center justify-center border-2 border-dashed border-white/5 rounded-2xl">
               <VideoIcon size={40} className="text-[#333] mb-4" />
               <p className="text-sm font-bold text-[#555]">Upload a video to see analytics</p>
            </div>
          )}
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
           <div className="bg-[#1e1e1e] p-8 rounded-3xl border border-white/5 group hover:border-white/10 transition-all">
              <div className="flex items-center justify-between mb-4">
                 <h3 className="text-xs font-black uppercase tracking-widest text-[#555]">Channel Summary</h3>
                 <Activity size={16} className="text-green-500" />
              </div>
              <div className="space-y-4">
                <div className="flex justify-between items-end">
                   <p className="text-xs font-bold text-[#aaa]">Subscribers</p>
                   <p className="text-xl font-black">{userChannel.subscribers}</p>
                </div>
                <div className="flex justify-between items-end">
                   <p className="text-xs font-bold text-[#aaa]">Total Views</p>
                   <p className="text-xl font-black">{totalViews}</p>
                </div>
              </div>
           </div>
           <div className="bg-[#1e1e1e] p-8 rounded-3xl border border-white/5 text-center flex flex-col justify-center">
              <MessageSquare size={32} className="mx-auto text-[#333] mb-3" />
              <p className="text-[10px] font-black uppercase text-[#555]">No New Comments</p>
           </div>
        </div>
      </div>

      <div className="space-y-6">
        <div className="bg-gradient-to-tr from-[#1e1e1e] to-[#252525] p-8 rounded-[40px] border border-white/5 flex flex-col items-center text-center shadow-2xl">
           <div className="w-16 h-16 bg-white/5 rounded-2xl flex items-center justify-center mb-6">
              <Plus size={32} className="text-blue-500" />
           </div>
           <h3 className="text-xl font-black italic uppercase tracking-tight mb-4 text-white">Create</h3>
           <Link to="/upload" className="w-full py-3 bg-white text-black rounded-xl font-black text-[10px] uppercase tracking-widest hover:bg-gray-200 transition-all">New Upload</Link>
        </div>
        <div className="bg-[#1e1e1e] p-6 rounded-3xl border border-white/5">
           <h3 className="text-[10px] font-black uppercase tracking-widest text-[#555] mb-4">Studio Insights</h3>
           <div className="space-y-3">
              <p className="text-[11px] font-bold text-gray-400">Content strategies for 2025</p>
              <p className="text-[11px] font-bold text-gray-400">Algorithm update guide</p>
           </div>
        </div>
      </div>
    </div>
  );

  const ContentView = () => (
    <div className="bg-[#1e1e1e] rounded-[40px] border border-white/5 overflow-hidden animate-in fade-in duration-500">
      <div className="px-8 py-6 border-b border-white/5">
        <h3 className="text-sm font-black uppercase tracking-widest">Channel Content</h3>
      </div>
      <div className="overflow-x-auto">
        <table className="w-full text-left">
          <thead>
            <tr className="border-b border-white/5 text-[10px] font-black uppercase tracking-widest text-[#555]">
              <th className="px-8 py-4">Video</th>
              <th className="px-4 py-4">Visibility</th>
              <th className="px-4 py-4 text-center">Views</th>
              <th className="px-8 py-4 text-right">Actions</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-white/5">
            {userVideos.map((v: any) => (
              <tr key={v.id} className="group hover:bg-white/[0.02]">
                <td className="px-8 py-4">
                  <div className="flex items-center gap-4">
                    <img src={v.thumbnail} className="w-20 aspect-video rounded-lg object-cover" alt="" />
                    <p className="text-xs font-bold truncate max-w-[200px]">{v.title}</p>
                  </div>
                </td>
                <td className="px-4 py-4"><span className="text-[10px] font-black text-green-500 flex items-center gap-1 uppercase"><Eye size={12}/> Public</span></td>
                <td className="px-4 py-4 text-center text-xs font-bold">{videoAnalytics[v.id]?.views || 0}</td>
                <td className="px-8 py-4 text-right">
                  <button onClick={() => deleteVideo(v.id)} className="p-2 text-red-500 hover:bg-red-500/10 rounded-lg"><Trash2 size={16}/></button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );

  return (
    <div className="min-h-screen bg-[#0f0f0f] pb-20">
      <div className="max-w-[1400px] mx-auto px-4 sm:px-12 py-12">
        <header className="flex flex-col xl:flex-row items-start xl:items-center justify-between mb-16 gap-10">
           <div className="flex items-center gap-8">
              <div className="w-16 h-16 rounded-[24px] overflow-hidden border-4 border-white/5 shadow-2xl">
                 <img src={userChannel.avatar} className="w-full h-full object-cover" alt="" />
              </div>
              <div>
                <h1 className="text-3xl font-black italic uppercase tracking-tighter leading-none text-white">Studio Workspace</h1>
                <p className="text-[11px] font-black uppercase tracking-[0.5em] text-[#444] mt-2">Syncing with global feed</p>
              </div>
           </div>
           <div className="flex flex-wrap gap-2 bg-[#1e1e1e] p-1.5 rounded-[26px] border border-white/5">
              {[
                {id: 'dashboard', label: 'Overview', icon: <LayoutDashboard size={16}/>},
                {id: 'content', label: 'Content', icon: <VideoIcon size={16}/>},
                {id: 'analytics', label: 'Analytics', icon: <BarChart2 size={16}/>},
                {id: 'monetization', label: 'Revenue', icon: <Target size={16}/>},
              ].map(tab => (
                <button 
                  key={tab.id}
                  onClick={() => setActiveTab(tab.id as any)}
                  className={`flex items-center gap-2 px-5 py-2.5 rounded-[20px] text-[10px] font-black uppercase tracking-widest transition-all ${activeTab === tab.id ? 'bg-white text-black shadow-lg' : 'text-[#444] hover:text-[#888]'}`}
                >
                  {tab.icon} <span>{tab.label}</span>
                </button>
              ))}
           </div>
        </header>

        <main>
           {activeTab === 'dashboard' && <DashboardView />}
           {activeTab === 'content' && <ContentView />}
           {activeTab === 'analytics' && <div className="bg-[#1e1e1e] p-8 rounded-[40px] border border-white/5 h-[400px]"><AnalyticsGraph data={mockAnalyticsData} /></div>}
           {activeTab === 'monetization' && (
             <div className="bg-[#1e1e1e] p-12 rounded-[40px] border border-white/5 text-center">
                <Scale size={48} className="text-[#333] mx-auto mb-6" />
                <h3 className="text-xl font-black uppercase tracking-widest text-white mb-2">Revenue Streams</h3>
                <p className="text-[#555] font-bold text-xs uppercase tracking-widest">Connect bank account to view earnings</p>
             </div>
           )}
        </main>
      </div>
    </div>
  );
};

export default Studio;
