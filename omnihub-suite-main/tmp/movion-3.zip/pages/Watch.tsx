
import React, { useState, useRef, useEffect, useMemo, useCallback } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { MOCK_VIDEOS, MOCK_CHANNELS } from '../constants';
import VideoCard from '../components/VideoCard';
import SubscribeButton from '../components/SubscribeButton';
import ChannelBadge from '../components/ChannelBadge';
import ActionButton from '../components/ActionButton';
import CommentItem from '../components/CommentItem';
import VideoDescription from '../components/VideoDescription';
import ShareModal from '../components/ShareModal';
import { getRelatedVideos } from '../logic/algorithms';
import { 
  ThumbsUp, ThumbsDown, Share2, Play, Pause, Volume2, VolumeX, Maximize, 
  Loader2, AlertCircle, RefreshCcw, SortDesc
} from 'lucide-react';
import { useUserStore } from '../store';

const Watch: React.FC = () => {
  const { videoId } = useParams();
  const navigate = useNavigate();
  const { 
    addToHistory, toggleLike, toggleDislike, likedVideos, dislikedVideos,
    getVideoComments, addComment, isSubscribed, progress: storeProgress, recordEngagement,
    emitEvent, videoAnalytics, userVideos, userChannel
  } = useUserStore();
  
  const video = useMemo(() => {
    const found = [...userVideos, ...MOCK_VIDEOS].find(v => v.id === videoId);
    return found || MOCK_VIDEOS[0];
  }, [videoId, userVideos]);

  const analytics = videoAnalytics[video.id];
  const relatedVideos = useMemo(() => getRelatedVideos(video, [...MOCK_VIDEOS, ...userVideos]), [video, userVideos]);
  
  const isLiked = likedVideos.some((v: any) => v.id === video.id);
  const isDisliked = dislikedVideos.some((v: any) => v.id === video.id);
  const subscribed = isSubscribed(video.channelId);
  const isOwner = userChannel.id === video.channelId;

  const [commentSort, setCommentSort] = useState<'TOP' | 'NEWEST'>('TOP');
  const [commentText, setCommentText] = useState('');
  const [comments, setComments] = useState<any[]>([]);
  
  const [isPlaying, setIsPlaying] = useState(false);
  const [isMuted, setIsMuted] = useState(true); 
  const [currentProgress, setCurrentProgress] = useState(0);
  const [showControls, setShowControls] = useState(true);
  const [isLoading, setIsLoading] = useState(true);
  const [hasError, setHasError] = useState(false);
  const [isShareModalOpen, setIsShareModalOpen] = useState(false);
  
  const videoRef = useRef<HTMLVideoElement>(null);
  const controlsTimeoutRef = useRef<number | null>(null);
  const hasSentRetentionEventRef = useRef<boolean>(false);
  const hasSentViewEventRef = useRef<string | null>(null); 
  const channelData = MOCK_CHANNELS.find(c => c.id === video.channelId);

  useEffect(() => {
    setComments(getVideoComments(video.id, commentSort));
  }, [video.id, commentSort, getVideoComments, analytics]);

  useEffect(() => {
    if (video) {
      window.scrollTo(0, 0);
      setIsLoading(true);
      setHasError(false);
      hasSentRetentionEventRef.current = false;
      addToHistory(video);

      if (hasSentViewEventRef.current !== video.id) {
        emitEvent({ type: 'watch_started', videoId: video.id });
        hasSentViewEventRef.current = video.id;
      }

      if (videoRef.current) {
        videoRef.current.load();
        const savedTime = storeProgress[video.id] || 0;
        videoRef.current.currentTime = savedTime;
        
        const playPromise = videoRef.current.play();
        if (playPromise !== undefined) {
          playPromise
            .then(() => {
              setIsPlaying(true);
              setIsLoading(false);
            })
            .catch(error => {
              setIsPlaying(false);
              setIsLoading(false);
            });
        }
      }
    }
  }, [video.id, addToHistory, emitEvent]); 

  const handleVideoError = () => {
    setIsLoading(false);
    setHasError(true);
  };

  const retryLoad = () => {
    setHasError(false);
    setIsLoading(true);
    if (videoRef.current) {
      videoRef.current.load();
      videoRef.current.play().catch(() => {});
    }
  };

  const seekTo = useCallback((seconds: number) => {
    if (videoRef.current) {
      videoRef.current.currentTime = seconds;
      videoRef.current.play().then(() => setIsPlaying(true)).catch(() => {});
      window.scrollTo({ top: 0, behavior: 'smooth' });
    }
  }, []);

  useEffect(() => {
    const interval = setInterval(() => {
      if (videoRef.current && isPlaying && !videoRef.current.paused) {
        const currentTime = videoRef.current.currentTime;
        recordEngagement(video, currentTime, false);
        
        if (currentTime >= 30 && !hasSentRetentionEventRef.current) {
          emitEvent({ type: 'retention_hit', videoId: video.id });
          hasSentRetentionEventRef.current = true;
        }
      }
    }, 2000);
    return () => clearInterval(interval);
  }, [video.id, isPlaying, recordEngagement, emitEvent]);

  const handleShare = () => {
    setIsShareModalOpen(true);
  };

  const handleEnded = () => {
    recordEngagement(video, 0, true);
  };

  const togglePlay = () => {
    if (videoRef.current) {
      if (videoRef.current.paused) {
        videoRef.current.play();
        setIsPlaying(true);
      } else {
        videoRef.current.pause();
        setIsPlaying(false);
      }
    }
  };

  const handleCommentSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (commentText.trim()) {
      addComment(video.id, commentText);
      setCommentText('');
    }
  };

  return (
    <div className="flex flex-col xl:flex-row gap-6 p-0 sm:p-4 lg:p-6 bg-white min-h-screen">
      <div className="flex-1 w-full max-w-[1280px] mx-auto">
        <div 
          className="w-full aspect-video bg-black relative sm:rounded-2xl overflow-hidden shadow-2xl group border border-[#e5e5e5]"
          onMouseMove={() => { 
            setShowControls(true); 
            if(controlsTimeoutRef.current) clearTimeout(controlsTimeoutRef.current); 
            controlsTimeoutRef.current = window.setTimeout(()=>setShowControls(false), 3000); 
          }}
          onMouseLeave={() => setShowControls(false)}
        >
          {isLoading && !hasError && (
            <div className="absolute inset-0 flex flex-col items-center justify-center bg-black/60 z-20 backdrop-blur-sm">
              <Loader2 className="text-white animate-spin mb-4" size={48} />
              <span className="text-[10px] font-black uppercase tracking-[0.4em] text-white/50">Buffering</span>
            </div>
          )}
          {hasError && (
            <div className="absolute inset-0 flex flex-col items-center justify-center bg-[#111] z-20 p-6 text-center">
              <AlertCircle className="text-red-500 mb-4" size={56} />
              <button onClick={retryLoad} className="flex items-center gap-2 px-8 py-3 bg-white text-black rounded-full text-xs font-black uppercase tracking-widest hover:bg-gray-200 transition-all active:scale-95">
                <RefreshCcw size={16} /> Retry
              </button>
            </div>
          )}
          
          <video 
            ref={videoRef}
            src={video.videoUrl}
            className="w-full h-full object-contain cursor-pointer"
            muted={isMuted}
            playsInline
            onTimeUpdate={() => { if (videoRef.current) setCurrentProgress((videoRef.current.currentTime / (videoRef.current.duration || 1)) * 100); }}
            onEnded={handleEnded}
            onClick={togglePlay}
            onError={handleVideoError}
            onWaiting={() => setIsLoading(true)}
            onPlaying={() => setIsLoading(false)}
          />

          <div className={`absolute inset-0 bg-gradient-to-t from-black/70 via-transparent to-transparent flex flex-col justify-end p-4 lg:p-6 transition-all duration-300 pointer-events-none ${showControls || !isPlaying ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-4'}`}>
            <div className="space-y-4 pointer-events-auto">
              <input type="range" min="0" max="100" step="0.01" value={currentProgress} onChange={(e) => { if (videoRef.current) videoRef.current.currentTime = (parseFloat(e.target.value) / 100) * videoRef.current.duration; }} className="w-full h-1.5 bg-white/30 rounded-full appearance-none cursor-pointer accent-red-600 transition-all hover:h-2" />
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-6">
                  <button onClick={togglePlay} className="text-white">{isPlaying ? <Pause size={32} fill="currentColor" /> : <Play size={32} fill="currentColor" />}</button>
                  <div className="flex items-center gap-4 group/vol">
                    <button onClick={()=>setIsMuted(!isMuted)} className="text-white">{isMuted ? <VolumeX size={24}/> : <Volume2 size={24}/>}</button>
                    <span className="text-[13px] font-black text-white/90 font-mono tracking-tight">{Math.floor((videoRef.current?.currentTime || 0) / 60)}:{(Math.floor((videoRef.current?.currentTime || 0) % 60)).toString().padStart(2,'0')} / {video.duration}</span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>

        <div className="mt-4">
           <div className="px-4 sm:px-0">
              <h1 className="text-lg sm:text-xl font-bold text-[#0f0f0f] mb-1 line-clamp-2 leading-tight">{video.title}</h1>
              
              {/* Responsive Layout for Channel/Actions - Use overflow-visible to allow dropdown */}
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mt-3 mb-4 overflow-visible">
                 <div className="flex items-center gap-3 min-w-0 pr-4 relative z-20">
                   <ChannelBadge 
                      id={video.channelId} 
                      name={video.channelName} 
                      avatar={video.channelAvatar} 
                      subscribers={(channelData?.subscribers || 0) + (subscribed ? 1 : 0)} 
                      size="md" 
                      showSubscribers={true} 
                    />
                   <SubscribeButton channelId={video.channelId} size="md" dropdownAlign="left" />
                 </div>

                 <div className="flex items-center gap-2 overflow-x-auto no-scrollbar pb-2 sm:pb-0 -mx-4 px-4 sm:mx-0 sm:px-0 z-10">
                    <div className="flex items-center bg-[#f2f2f2] rounded-full h-9 overflow-hidden shrink-0">
                       <ActionButton 
                        icon={<ThumbsUp size={16} fill={isLiked ? "currentColor" : "none"} />} 
                        label={Intl.NumberFormat('en', { notation: 'compact' }).format((analytics?.likes || video.likes))} 
                        active={isLiked} 
                        type="video_liked" 
                        videoId={video.id} 
                        onClick={() => toggleLike(video)} 
                        variant="pill" 
                        className="rounded-r-none border-r border-[#d9d9d9] hover:bg-[#e5e5e5] h-full px-4 py-0 text-xs gap-2" 
                       />
                       <ActionButton 
                        icon={<ThumbsDown size={16} fill={isDisliked ? "currentColor" : "none"} />} 
                        active={isDisliked} 
                        type="video_disliked" 
                        videoId={video.id} 
                        onClick={() => toggleDislike(video)} 
                        variant="pill" 
                        className="rounded-l-none hover:bg-[#e5e5e5] px-4 h-full py-0" 
                       />
                    </div>
                    <ActionButton 
                      icon={<Share2 size={16} />} 
                      label="Share" 
                      type="content_shared" 
                      videoId={video.id} 
                      onClick={handleShare} 
                      variant="pill" 
                      className="bg-[#f2f2f2] hover:bg-[#e5e5e5] h-9 px-4 py-0 text-xs gap-2 shrink-0"
                    />
                 </div>
              </div>

              <div className="mb-6 relative z-0">
                <VideoDescription 
                  description={video.description}
                  views={analytics?.views || video.views}
                  uploadDate={video.timestamp}
                  onSeek={seekTo}
                  tags={video.tags || [video.category]}
                  isHighRetention={analytics && analytics.averageRetention > 0.6}
                />
              </div>

              <div className="space-y-6">
                 <div className="flex items-center justify-between">
                   <div className="flex items-center gap-6">
                     <h3 className="text-lg font-bold text-[#030303]">{analytics?.commentsCount || 0} Comments</h3>
                   </div>
                 </div>

                 <div className="flex gap-4 mb-8">
                   <img src={userChannel.avatar} className="w-10 h-10 rounded-full object-cover shrink-0" alt="" />
                   <form onSubmit={handleCommentSubmit} className="flex-1">
                     <input 
                       value={commentText} 
                       onChange={e => setCommentText(e.target.value)} 
                       placeholder="Add a comment..."
                       className="w-full bg-transparent border-b border-[#e5e5e5] focus:border-[#0f0f0f] outline-none py-2 text-sm transition-colors focus:border-b-2"
                     />
                     <div className="flex justify-end mt-2">
                        <button 
                          type="submit" 
                          disabled={!commentText.trim()}
                          className="px-4 py-2 bg-[#065fd4] text-white text-sm font-bold rounded-full disabled:bg-[#f2f2f2] disabled:text-[#909090] transition-colors"
                        >
                          Comment
                        </button>
                     </div>
                   </form>
                 </div>

                 <div className="space-y-6">
                    {comments.map((c: any) => (
                      <CommentItem key={c.id} comment={c} videoId={video.id} isCreatorView={isOwner} />
                    ))}
                 </div>
              </div>
           </div>
        </div>
      </div>

      <div className="xl:w-[400px] flex flex-col gap-6 px-4 sm:px-0 bg-white pt-6 lg:pt-0">
        <h4 className="text-sm font-bold text-[#0f0f0f] px-2 hidden lg:block">Up Next</h4>
        <div className="flex flex-col gap-2">
          {relatedVideos.map((v) => (
             <VideoCard key={v.id} video={v} layout="list" />
          ))}
        </div>
      </div>

      <ShareModal 
        isOpen={isShareModalOpen} 
        onClose={() => setIsShareModalOpen(false)} 
        videoId={video.id} 
        videoTitle={video.title} 
        currentTime={videoRef.current?.currentTime}
      />
    </div>
  );
};

export default Watch;
