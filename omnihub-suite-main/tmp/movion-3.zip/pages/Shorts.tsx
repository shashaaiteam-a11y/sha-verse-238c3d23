
import React, { useEffect, useRef, useState, useCallback, useMemo } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { Zap } from 'lucide-react';
import { useUserStore } from '../store';
import ShortsPlayer from '../components/ShortsPlayer';

const Shorts: React.FC = () => {
  const { videoId } = useParams();
  const navigate = useNavigate();
  const { getPulseFeed } = useUserStore();
  
  const shortsVideos = useMemo(() => getPulseFeed(), [getPulseFeed]);
  const [activeId, setActiveId] = useState<string>(videoId || (shortsVideos[0]?.id || ''));
  const [isGlobalMuted, setIsGlobalMuted] = useState(true);
  const containerRef = useRef<HTMLDivElement>(null);
  const isScrollingRef = useRef(false);

  // PRELOAD LOGIC: Determine which indices should be 'active' or 'preloading'
  const activeIndex = useMemo(() => shortsVideos.findIndex(v => v.id === activeId), [shortsVideos, activeId]);

  const scrollToId = useCallback((id: string) => {
    if (!containerRef.current || isScrollingRef.current) return;
    const target = containerRef.current.querySelector(`[data-id="${id}"]`);
    if (target) {
      isScrollingRef.current = true;
      target.scrollIntoView({ behavior: 'smooth' });
      setTimeout(() => { isScrollingRef.current = false; }, 500);
      navigate(`/shorts/${id}`, { replace: true });
    }
  }, [navigate]);

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'ArrowDown' && activeIndex < shortsVideos.length - 1) scrollToId(shortsVideos[activeIndex + 1].id);
      else if (e.key === 'ArrowUp' && activeIndex > 0) scrollToId(shortsVideos[activeIndex - 1].id);
    };

    const handleWheel = (e: WheelEvent) => {
      if (isScrollingRef.current) return;
      if (e.deltaY > 50 && activeIndex < shortsVideos.length - 1) scrollToId(shortsVideos[activeIndex + 1].id);
      else if (e.deltaY < -50 && activeIndex > 0) scrollToId(shortsVideos[activeIndex - 1].id);
    };

    window.addEventListener('keydown', handleKeyDown);
    containerRef.current?.addEventListener('wheel', handleWheel, { passive: true });
    return () => {
      window.removeEventListener('keydown', handleKeyDown);
      containerRef.current?.removeEventListener('wheel', handleWheel);
    };
  }, [activeIndex, shortsVideos, scrollToId]);

  useEffect(() => {
    const observer = new IntersectionObserver((entries) => {
      entries.forEach((entry) => {
        if (entry.isIntersecting) {
          const id = entry.target.getAttribute('data-id');
          if (id && id !== activeId) setActiveId(id);
        }
      });
    }, { root: containerRef.current, threshold: 0.7 });

    const elements = containerRef.current?.querySelectorAll('[data-short-item]');
    elements?.forEach((el) => observer.observe(el));
    return () => observer.disconnect();
  }, [activeId]);

  return (
    <div 
      className="fixed top-14 bottom-16 left-0 right-0 lg:static lg:h-[calc(100vh-56px)] overflow-y-scroll snap-y snap-mandatory no-scrollbar bg-black z-40" 
      ref={containerRef}
    >
      {shortsVideos.map((video, idx) => {
        // PRELOAD logic: isActive is true only for visible, but we may want to pass a "isPreload" prop
        const shouldLoadMedia = Math.abs(idx - activeIndex) <= 1; // Load current, prev, and next
        
        return (
          <ShortsPlayer 
            key={video.id} 
            video={video} 
            isActive={video.id === activeId} 
            isMuted={isGlobalMuted}
            onMuteToggle={() => setIsGlobalMuted(!isGlobalMuted)}
            shouldPreload={shouldLoadMedia}
          />
        );
      })}
    </div>
  );
};

export default Shorts;
