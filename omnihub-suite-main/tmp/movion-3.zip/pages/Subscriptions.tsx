
import React, { useState, useMemo } from 'react';
import { useUserStore } from '../store';
import { MOCK_CHANNELS } from '../constants';
import VideoCard from '../components/VideoCard';
import { LayoutGrid, List, Settings2, PlayCircle, Zap, FilterX, Clock, Sparkles } from 'lucide-react';
import { Link } from 'react-router-dom';

const Subscriptions: React.FC = () => {
  const { subscriptions, getSubscriptionFeed } = useUserStore();
  const [viewMode, setViewMode] = useState<'grid' | 'list'>('grid');
  const [selectedChannelId, setSelectedChannelId] = useState<string | null>(null);
  const [sortMode, setSortMode] = useState<'smart' | 'recent'>('smart');
  
  const subbedChannels = useMemo(() => 
    MOCK_CHANNELS.filter(c => subscriptions?.includes?.(c.id)),
    [subscriptions]
  );

  const subscribedVideos = useMemo(() => 
    getSubscriptionFeed(selectedChannelId || undefined, sortMode),
    [getSubscriptionFeed, selectedChannelId, sortMode]
  );

  return (
    <div className="flex flex-col min-h-full bg-[#0f0f0f]">
      <div className="sticky top-0 bg-[#0f0f0f]/95 backdrop-blur-md z-30 px-4 sm:px-6 py-4 flex items-center justify-between border-b border-white/5">
        <div className="flex items-center gap-6 overflow-x-auto no-scrollbar max-w-[calc(100%-250px)] scroll-smooth pb-1">
          {subbedChannels.length > 0 ? (
            <>
              <button 
                onClick={() => setSelectedChannelId(null)}
                className={`flex flex-col items-center gap-2 flex-shrink-0 group transition-all transform ${!selectedChannelId ? 'scale-110' : 'opacity-60 hover:opacity-100'}`}
              >
                <div className={`w-12 h-12 rounded-full flex items-center justify-center border-2 transition-all ${!selectedChannelId ? 'bg-white/10 border-white' : 'bg-white/5 border-transparent'}`}>
                  <FilterX size={20} className={!selectedChannelId ? 'text-white' : 'text-[#aaa]'} />
                </div>
                <span className="text-[10px] font-black uppercase tracking-widest">All</span>
              </button>
              {subbedChannels.map(channel => (
                <button 
                  key={channel.id} 
                  onClick={() => setSelectedChannelId(channel.id)}
                  className={`flex flex-col items-center gap-2 flex-shrink-0 group transition-all transform ${selectedChannelId === channel.id ? 'scale-110' : 'opacity-60 hover:opacity-100'}`}
                >
                  <img src={channel.avatar} className={`w-12 h-12 rounded-full object-cover transition-all border-2 ${selectedChannelId === channel.id ? 'border-[#3ea6ff]' : 'border-transparent'}`} alt="" />
                  <span className="text-[10px] font-bold text-[#aaa] group-hover:text-white truncate max-w-[70px]">{channel.name}</span>
                </button>
              ))}
            </>
          ) : (
            <p className="text-xs text-[#aaa] font-bold italic py-4">No subscriptions found.</p>
          )}
        </div>

        <div className="flex items-center gap-4 pl-4 border-l border-white/5">
          <div className="flex items-center bg-[#272727] rounded-xl p-1">
            <button onClick={() => setSortMode('smart')} className={`p-2 rounded-lg ${sortMode === 'smart' ? 'bg-blue-600' : ''}`}><Sparkles size={16} /></button>
            <button onClick={() => setSortMode('recent')} className={`p-2 rounded-lg ${sortMode === 'recent' ? 'bg-white text-black' : ''}`}><Clock size={16} /></button>
          </div>
          <div className="flex items-center gap-2">
            <button onClick={() => setViewMode('grid')} className={`p-2.5 rounded-xl ${viewMode === 'grid' ? 'bg-white text-black' : 'text-[#aaa]'}`}><LayoutGrid size={18} /></button>
            <button onClick={() => setViewMode('list')} className={`p-2.5 rounded-xl ${viewMode === 'list' ? 'bg-white text-black' : 'text-[#aaa]'}`}><List size={18} /></button>
          </div>
        </div>
      </div>

      <div className="p-4 lg:p-8 max-w-[1600px] mx-auto w-full">
        {subscribedVideos.length > 0 ? (
          <div className={viewMode === 'grid' ? "grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 2xl:grid-cols-5 gap-x-5 gap-y-12" : "flex flex-col gap-4 max-w-5xl mx-auto"}>
            {subscribedVideos.map((video, idx) => (
              <div key={`${video.id}-${idx}`} className="relative">
                <VideoCard video={video} layout={viewMode} />
                {(video.timestamp?.includes('hours') || video.timestamp?.includes('minutes')) && viewMode === 'grid' && (
                  <div className="absolute top-2 left-2 bg-blue-600 text-[9px] font-black px-2 py-0.5 rounded shadow-lg">NEW</div>
                )}
              </div>
            ))}
          </div>
        ) : (
          <div className="flex flex-col items-center justify-center py-40 text-center">
            <PlayCircle size={80} className="opacity-10 text-white mb-10" />
            <h2 className="text-3xl font-black italic text-white uppercase">The Feed is Quiet</h2>
          </div>
        )}
      </div>
    </div>
  );
};

export default Subscriptions;
