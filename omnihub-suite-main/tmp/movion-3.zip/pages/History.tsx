
import React, { useState, useMemo } from 'react';
import { useUserStore } from '../store';
import VideoCard from '../components/VideoCard';
import { 
  Trash2, Pause, Play, Settings, Search, 
  X, Shield, Calendar, Clock, ChevronRight,
  History as HistoryIcon 
} from 'lucide-react';

const HistoryPage: React.FC = () => {
  const { 
    history, clearHistory, removeFromHistory, 
    historyPaused, togglePauseHistory 
  } = useUserStore();
  const [searchTerm, setSearchTerm] = useState('');
  const [isSettingsModalOpen, setIsSettingsModalOpen] = useState(false);

  const filteredHistory = useMemo(() => {
    return (history || []).filter((v: any) => 
      v.title.toLowerCase().includes(searchTerm.toLowerCase())
    );
  }, [history, searchTerm]);

  // Group history by "Today", "Yesterday", "Earlier"
  const groupedHistory = useMemo(() => {
    const today: any[] = [];
    const yesterday: any[] = [];
    const earlier: any[] = [];
    
    filteredHistory.forEach((v, idx) => {
      if (idx < 2) today.push(v);
      else if (idx < 5) yesterday.push(v);
      else earlier.push(v);
    });
    
    return [
      { title: 'Today', videos: today },
      { title: 'Yesterday', videos: yesterday },
      { title: 'Earlier this week', videos: earlier }
    ].filter(g => g.videos.length > 0);
  }, [filteredHistory]);

  return (
    <div className="flex flex-col lg:flex-row gap-8 p-4 lg:p-8 max-w-[1400px] mx-auto min-h-full bg-white">
      <div className="flex-1">
        <h1 className="text-2xl font-bold mb-8 px-2">Watch history</h1>
        
        {groupedHistory.length > 0 ? (
          <div className="space-y-10">
            {groupedHistory.map(group => (
              <div key={group.title} className="space-y-4">
                <h2 className="text-lg font-bold px-2 mb-2">{group.title}</h2>
                <div className="flex flex-col gap-2">
                  {group.videos.map((video: any) => (
                    <div key={`history-item-${video.id}`} className="group relative flex items-center gap-4 pr-10">
                      <div className="flex-1">
                        <VideoCard video={video} layout="list-large" />
                      </div>
                      <button 
                        onClick={() => removeFromHistory(video.id)}
                        className="absolute right-2 p-2 text-gray-400 hover:text-red-600 hover:bg-red-50 rounded-full transition-all opacity-0 group-hover:opacity-100"
                        title="Remove from watch history"
                      >
                        <X size={20} />
                      </button>
                    </div>
                  ))}
                </div>
              </div>
            ))}
          </div>
        ) : (
          <div className="flex flex-col items-center justify-center py-32 text-center">
            <div className="w-24 h-24 bg-gray-50 rounded-full flex items-center justify-center mb-6 text-gray-200">
              <HistoryIcon size={48} />
            </div>
            <h2 className="text-xl font-bold mb-2 text-[#030303]">This list has no videos.</h2>
            <p className="text-gray-500 text-sm max-w-xs">
              Videos you watch will show up here.
            </p>
          </div>
        )}
      </div>

      {/* Desktop Sidebar Controls */}
      <div className="lg:w-80 space-y-8 sticky top-6 self-start hidden lg:block">
        <div className="relative group">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400 group-focus-within:text-black transition-colors" size={18} />
          <input 
            type="text" 
            placeholder="Search watch history"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full bg-gray-100 border-b border-gray-200 pl-10 pr-4 py-2.5 outline-none focus:border-black transition-all text-sm rounded-t-xl font-medium"
          />
        </div>

        <div className="space-y-1">
          <button 
            onClick={clearHistory}
            className="w-full flex items-center gap-4 p-3 hover:bg-gray-100 rounded-xl transition-colors text-sm font-bold text-left"
          >
            <Trash2 size={20} className="text-gray-500" />
            Clear all watch history
          </button>
          <button 
            onClick={togglePauseHistory}
            className="w-full flex items-center gap-4 p-3 hover:bg-gray-100 rounded-xl transition-colors text-sm font-bold text-left"
          >
            {historyPaused ? <Play size={20} className="text-blue-500" /> : <Pause size={20} className="text-gray-500" />}
            {historyPaused ? 'Resume watch history' : 'Pause watch history'}
          </button>
          <button 
            onClick={() => setIsSettingsModalOpen(true)}
            className="w-full flex items-center gap-4 p-3 hover:bg-gray-100 rounded-xl transition-colors text-sm font-bold text-left"
          >
            <Settings size={20} className="text-gray-500" />
            Manage all history
          </button>
        </div>

        <div className="p-6 bg-gray-50 rounded-2xl border border-gray-100 space-y-4 shadow-sm">
           <div className="flex items-center gap-3">
             <div className="w-10 h-10 bg-blue-50 rounded-full flex items-center justify-center">
                <Shield size={20} className="text-blue-500" />
             </div>
             <h3 className="text-sm font-bold">Privacy Controls</h3>
           </div>
           <p className="text-xs text-gray-500 leading-relaxed font-medium">
             Your watch history makes it easier to find videos you've recently watched and improves your recommendations.
           </p>
           <button className="text-xs text-blue-600 font-bold hover:underline uppercase tracking-widest">Manage activity</button>
        </div>
      </div>
    </div>
  );
};

export default HistoryPage;
