
import React from 'react';
import { useUserStore } from '../store';
import VideoCard from '../components/VideoCard';
import { 
  History as HistoryIcon, Clock, ThumbsUp, ChevronRight, 
  PlaySquare, ListVideo, Download, Scissors, Plus, Shield, 
  Settings, MoreVertical, Search, Activity, User, Share2, 
  MessageSquare, UserPlus, Zap, Trash2
} from 'lucide-react';
import { Link } from 'react-router-dom';

const ActionChip = ({ icon: Icon, label, linkTo }: { icon: any, label: string, linkTo: string }) => (
  <Link to={linkTo} className="flex items-center gap-2 px-4 py-1.5 border border-gray-200 rounded-full hover:bg-gray-100 transition-colors text-sm font-bold text-[#030303] whitespace-nowrap shrink-0">
    <Icon size={18} />
    {label}
  </Link>
);

const LibraryPage: React.FC = () => {
  const { history, watchLater, likedVideos, userChannel, userEvents, clearActivityLog } = useUserStore();

  const getActionIcon = (action: string) => {
    switch (action) {
      case 'VIDEO_LIKED': return <ThumbsUp size={14} className="text-blue-500" />;
      case 'WATCH_STARTED': return <HistoryIcon size={14} className="text-gray-500" />;
      case 'CHANNEL_FOLLOWED': return <UserPlus size={14} className="text-green-500" />;
      case 'CONTENT_SHARED': return <Share2 size={14} className="text-purple-500" />;
      case 'VIDEO_REPLAY': return <Zap size={14} className="text-yellow-500" />;
      default: return <Activity size={14} className="text-gray-400" />;
    }
  };

  const formatTimestamp = (ts: number) => {
    const diff = Date.now() - ts;
    if (diff < 60000) return 'Just now';
    if (diff < 3600000) return `${Math.floor(diff / 60000)}m ago`;
    if (diff < 86400000) return `${Math.floor(diff / 3600000)}h ago`;
    return new Date(ts).toLocaleDateString();
  };

  return (
    <div className="min-h-full bg-white pb-20">
      <div className="max-w-[1280px] mx-auto px-4 sm:px-6 lg:px-8 py-6 space-y-10">
        
        {/* User Stats Card (Viewer Panel) */}
        <div className="bg-gradient-to-r from-[#f8f9fa] to-white border border-gray-200 rounded-[32px] p-6 sm:p-10 flex flex-col md:flex-row items-center gap-8 shadow-sm">
           <img src={userChannel.avatar} className="w-24 h-24 sm:w-32 sm:h-32 rounded-full object-cover border-4 border-white shadow-xl" alt="" />
           <div className="flex-1 text-center md:text-left">
              <h1 className="text-3xl font-black italic uppercase tracking-tighter text-[#030303] mb-1">{userChannel.name}</h1>
              <p className="text-sm text-gray-500 font-bold mb-6">{userChannel.handle} • Viewer ID: {userChannel.id.split('-').pop()}</p>
              
              <div className="flex flex-wrap justify-center md:justify-start gap-4">
                 <div className="px-5 py-3 bg-white border border-gray-100 rounded-2xl shadow-sm text-center min-w-[100px]">
                    <p className="text-[10px] font-black uppercase text-gray-400 mb-1">Watched</p>
                    <p className="text-lg font-black">{history.length}</p>
                 </div>
                 <div className="px-5 py-3 bg-white border border-gray-100 rounded-2xl shadow-sm text-center min-w-[100px]">
                    <p className="text-[10px] font-black uppercase text-gray-400 mb-1">Liked</p>
                    <p className="text-lg font-black">{likedVideos.length}</p>
                 </div>
                 <div className="px-5 py-3 bg-white border border-gray-100 rounded-2xl shadow-sm text-center min-w-[100px]">
                    <p className="text-[10px] font-black uppercase text-gray-400 mb-1">Saved</p>
                    <p className="text-lg font-black">{watchLater.length}</p>
                 </div>
              </div>
           </div>
           <button className="p-4 bg-gray-100 hover:bg-gray-200 rounded-2xl transition-all text-gray-600 self-center md:self-start">
              <Settings size={24} />
           </button>
        </div>

        {/* Action Chips Row */}
        <div className="flex gap-3 overflow-x-auto no-scrollbar pb-2">
          <ActionChip icon={HistoryIcon} label="History" linkTo="/history" />
          <ActionChip icon={PlaySquare} label="Your Videos" linkTo={`/channel/${userChannel.id}`} />
          <ActionChip icon={Download} label="Downloads" linkTo="#" />
          <ActionChip icon={Scissors} label="Your Clips" linkTo="#" />
          <ActionChip icon={ListVideo} label="Playlists" linkTo="#" />
          <ActionChip icon={Shield} label="Your Movies" linkTo="#" />
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-10">
          <div className="lg:col-span-2 space-y-10">
            {/* History Section */}
            <section>
              <div className="flex items-center justify-between mb-4">
                <h2 className="text-xl font-bold text-[#030303]">Recent History</h2>
                <Link to="/history" className="text-sm font-bold text-blue-600 hover:bg-blue-50 px-3 py-1.5 rounded-full transition-all">
                  See all
                </Link>
              </div>
              
              <div className="relative">
                <div className="flex gap-4 overflow-x-auto no-scrollbar pb-4 scroll-smooth">
                  {history.length > 0 ? (
                    <>
                      {history.slice(0, 8).map((video: any) => (
                        <div key={`lib-hist-${video.id}`} className="min-w-[210px] w-[210px]">
                          <VideoCard video={video} />
                        </div>
                      ))}
                      <Link to="/history" className="min-w-[120px] flex flex-col items-center justify-center gap-3 group cursor-pointer py-10">
                        <div className="w-12 h-12 rounded-full bg-gray-100 flex items-center justify-center group-hover:bg-gray-200 transition-colors border border-gray-200">
                          <ChevronRight size={24} className="text-gray-600" />
                        </div>
                        <span className="text-[10px] font-black uppercase tracking-widest text-gray-500">View All</span>
                      </Link>
                    </>
                  ) : (
                    <div className="w-full py-12 bg-gray-50 rounded-2xl flex flex-col items-center justify-center text-center gap-3 border border-dashed border-gray-200">
                      <HistoryIcon size={40} className="text-gray-300" />
                      <p className="text-sm font-bold text-gray-500">No watch history yet</p>
                    </div>
                  )}
                </div>
              </div>
            </section>

            {/* Playlists Grid */}
            <section>
              <div className="flex items-center justify-between mb-6">
                <h2 className="text-xl font-bold text-[#030303]">Playlists</h2>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-6">
                <Link to="/liked" className="group">
                  <div className="aspect-video bg-gradient-to-br from-[#4b3d8c] to-[#2a1b4d] rounded-2xl relative overflow-hidden mb-3 shadow-md group-hover:shadow-lg transition-all">
                    {likedVideos.length > 0 && (
                      <img src={likedVideos[0].thumbnail} className="absolute inset-0 w-full h-full object-cover opacity-30 group-hover:scale-105 transition-transform duration-700" alt="" />
                    )}
                    <div className="absolute inset-0 flex flex-col items-center justify-center">
                      <ThumbsUp size={32} className="text-white mb-2 opacity-80" />
                      <p className="text-white font-black uppercase tracking-widest text-[10px]">Liked videos</p>
                      <p className="text-white/60 text-[10px] mt-1 font-bold">{likedVideos.length} videos</p>
                    </div>
                  </div>
                  <h3 className="text-sm font-bold text-[#030303]">Liked videos</h3>
                </Link>

                <Link to="/watch-later" className="group">
                  <div className="aspect-video bg-gradient-to-br from-[#1a3a5f] to-[#0a1a2e] rounded-2xl relative overflow-hidden mb-3 shadow-md group-hover:shadow-lg transition-all">
                    {watchLater.length > 0 && (
                      <img src={watchLater[0].thumbnail} className="absolute inset-0 w-full h-full object-cover opacity-30 group-hover:scale-105 transition-transform duration-700" alt="" />
                    )}
                    <div className="absolute inset-0 flex flex-col items-center justify-center">
                      <Clock size={32} className="text-white mb-2 opacity-80" />
                      <p className="text-white font-black uppercase tracking-widest text-[10px]">Watch Later</p>
                      <p className="text-white/60 text-[10px] mt-1 font-bold">{watchLater.length} videos</p>
                    </div>
                  </div>
                  <h3 className="text-sm font-bold text-[#030303]">Watch Later</h3>
                </Link>

                <button className="group text-left">
                  <div className="aspect-video bg-white border-2 border-dashed border-gray-200 rounded-2xl relative overflow-hidden mb-3 flex items-center justify-center group-hover:border-blue-500 group-hover:bg-blue-50 transition-all">
                    <Plus size={36} className="text-blue-600" />
                  </div>
                  <h3 className="text-sm font-bold text-[#030303] group-hover:text-blue-600 transition-colors">New Playlist</h3>
                </button>
              </div>
            </section>
          </div>

          {/* Activity Log Panel (Tracking Panel) */}
          <div className="space-y-6">
            <div className="bg-[#fcfcfc] border border-gray-100 rounded-[32px] overflow-hidden flex flex-col h-[600px] shadow-sm">
               <div className="p-6 border-b border-gray-100 flex items-center justify-between bg-white">
                  <div className="flex items-center gap-3">
                     <div className="p-2 bg-blue-50 text-blue-600 rounded-xl"><Activity size={18} /></div>
                     <h3 className="text-sm font-black uppercase tracking-widest">Tracking Log</h3>
                  </div>
                  <button onClick={clearActivityLog} className="p-2 hover:bg-gray-100 rounded-full text-gray-400 hover:text-red-500 transition-colors" title="Clear log">
                     <Trash2 size={16} />
                  </button>
               </div>
               
               <div className="flex-1 overflow-y-auto p-4 space-y-4 no-scrollbar">
                  {userEvents.length > 0 ? (
                    userEvents.map((ev: any) => (
                      <div key={ev.id} className="flex gap-4 p-3 hover:bg-white rounded-2xl transition-colors border border-transparent hover:border-gray-50 group">
                         <div className="mt-1 w-8 h-8 rounded-full bg-gray-50 flex items-center justify-center shrink-0 border border-gray-100 group-hover:bg-white group-hover:shadow-sm transition-all">
                            {getActionIcon(ev.action)}
                         </div>
                         <div className="flex-1 min-w-0">
                            <p className="text-[13px] text-gray-800 leading-tight">
                               <span className="font-black text-[10px] text-blue-600 uppercase tracking-widest block mb-0.5">{ev.action.replace('_', ' ')}</span>
                               {ev.videoTitle ? (
                                 <Link to={`/watch/${ev.videoId}`} className="font-bold hover:text-blue-600 transition-colors line-clamp-2">{ev.videoTitle}</Link>
                               ) : ev.channelName ? (
                                 <Link to={`/channel/${ev.channelId}`} className="font-bold hover:text-blue-600 transition-colors">{ev.channelName}</Link>
                               ) : <span className="font-medium text-gray-400">Interaction recorded</span>}
                            </p>
                            <p className="text-[10px] font-bold text-gray-400 mt-1 uppercase tracking-tighter">{formatTimestamp(ev.timestamp)}</p>
                         </div>
                      </div>
                    ))
                  ) : (
                    <div className="h-full flex flex-col items-center justify-center text-center p-10">
                       <Activity size={48} className="text-gray-100 mb-4" />
                       <p className="text-xs font-black uppercase tracking-widest text-gray-300">No activity captured</p>
                    </div>
                  )}
               </div>
               
               <div className="p-4 bg-gray-50 border-t border-gray-100">
                  <p className="text-[9px] font-bold text-gray-400 text-center uppercase tracking-[0.2em]">Live Data Stream • End-to-End Encrypted</p>
               </div>
            </div>
            
            <div className="p-6 bg-blue-600 rounded-[32px] text-white shadow-xl shadow-blue-600/20 relative overflow-hidden group cursor-pointer">
               <div className="absolute top-0 right-0 p-8 opacity-10 rotate-12 group-hover:rotate-0 transition-transform">
                  <Shield size={100} />
               </div>
               <h4 className="text-lg font-black uppercase italic tracking-tighter mb-2">Privacy Shield</h4>
               <p className="text-xs font-bold text-blue-100 leading-relaxed opacity-80">Your interaction data is only used to personalize your MOVION experience. Manage data sharing in settings.</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default LibraryPage;
