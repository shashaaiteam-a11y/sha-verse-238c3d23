
import React from 'react';
import { HashRouter as Router, Routes, Route } from 'react-router-dom';
import Layout from './components/Layout';
import Home from './pages/Home';
import Watch from './pages/Watch';
import Channel from './pages/Channel';
import Monetization from './pages/Monetization';
import Upload from './pages/Upload';
import Shorts from './pages/Shorts';
import HistoryPage from './pages/History';
import LibraryPage from './pages/Library';
import PlaylistPage from './pages/Playlist';
import Subscriptions from './pages/Subscriptions';
import MobileSearch from './pages/MobileSearch';
import SearchResults from './pages/SearchResults';
import { UserStoreProvider } from './store';

const App = () => {
  return (
    <UserStoreProvider>
      <Router>
        <Layout>
          <Routes>
            <Route path="/" element={<Home />} />
            <Route path="/shorts" element={<Shorts />} />
            <Route path="/shorts/:videoId" element={<Shorts />} />
            <Route path="/watch/:videoId" element={<Watch />} />
            <Route path="/channel/:channelId" element={<Channel />} />
            <Route path="/monetization" element={<Monetization />} />
            <Route path="/studio" element={<Monetization />} />
            <Route path="/upload" element={<Upload />} />
            <Route path="/subscriptions" element={<Subscriptions />} />
            <Route path="/search" element={<MobileSearch />} />
            <Route path="/results" element={<SearchResults />} />
            
            <Route path="/history" element={<HistoryPage />} />
            <Route path="/library" element={<LibraryPage />} />
            <Route path="/watch-later" element={<PlaylistPage type="Watch Later" />} />
            <Route path="/liked" element={<PlaylistPage type="Liked Videos" />} />
            
            {/* Fallback routes */}
            <Route path="/my-videos" element={<Channel />} />
          </Routes>
        </Layout>
      </Router>
    </UserStoreProvider>
  );
};

export default App;
