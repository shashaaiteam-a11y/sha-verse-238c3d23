
import React, { createContext, useContext, useState, useEffect, useMemo, useCallback, ReactNode } from 'react';
import { Video, Comment, Channel, VideoAnalytics, NotificationLevel, VideoType, AnalyticsEvent, Subscription, ToastMessage, Notification, LiveChatMessage } from './types';
import { MOCK_VIDEOS, MOCK_CHANNELS } from './constants';
import { prioritizeVideos, prioritizePulse, prioritizeSubscriptions } from './logic/algorithms';

export interface UserEventLog {
  id: string;
  userId: string;
  action: string;
  videoId?: string;
  videoTitle?: string;
  channelId?: string;
  channelName?: string;
  sourcePlatform?: string;
  timestamp: number;
}

const DEFAULT_CHANNEL: Channel = {
  id: 'my-channel-main',
  name: 'Main Creator',
  handle: '@main_creator',
  avatar: `https://api.dicebear.com/7.x/avataaars/svg?seed=main`,
  subscribers: 0,
  description: 'My primary creative outlet.',
  watchTimeHours: 0,
  shortsViews: 0,
  joinedDate: new Date().toLocaleDateString('en-US', { month: 'short', year: 'numeric' })
};

const UserStoreContext = createContext<any>(null);

export const UserStoreProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [allChannels, setAllChannels] = useState<Channel[]>(() => {
    try {
      const savedUserChannel = localStorage.getItem('movion_user_channel');
      const parsedUserChannel = savedUserChannel ? JSON.parse(savedUserChannel) : DEFAULT_CHANNEL;
      const baseChannels = [...MOCK_CHANNELS];
      const exists = baseChannels.find(c => c.id === parsedUserChannel.id);
      if (!exists) baseChannels.push(parsedUserChannel);
      return baseChannels;
    } catch { return [...MOCK_CHANNELS]; }
  });

  const [userChannel, setUserChannel] = useState<Channel>(() => {
    try {
      const saved = localStorage.getItem('movion_user_channel');
      return saved ? JSON.parse(saved) : DEFAULT_CHANNEL;
    } catch { return DEFAULT_CHANNEL; }
  });

  const [subscriptions, setSubscriptions] = useState<Record<string, Subscription>>(() => {
    try {
      const saved = localStorage.getItem('movion_subscriptions_v2');
      if (saved) return JSON.parse(saved);
      return { "c1": { channelId: "c1", subscribedAt: Date.now(), notificationLevel: 'ALL' } };
    } catch { return {}; }
  });

  const [toasts, setToasts] = useState<ToastMessage[]>([]);
  const [notifications, setNotifications] = useState<Notification[]>([]);
  const [unreadCount, setUnreadCount] = useState(0);
  const [liveChatMessages, setLiveChatMessages] = useState<Record<string, LiveChatMessage[]>>({});
  const [searchHistory, setSearchHistory] = useState<string[]>(() => {
    try { return JSON.parse(localStorage.getItem('movion_search_history') || '[]'); } catch { return []; }
  });

  const [comments, setComments] = useState<Record<string, Comment[]>>(() => {
    try { return JSON.parse(localStorage.getItem('movion_comments_v2') || '{}'); } catch { return {}; }
  });
  
  const [videoAnalytics, setVideoAnalytics] = useState<Record<string, VideoAnalytics>>(() => {
    try {
      const saved = localStorage.getItem('movion_analytics_v4');
      if (saved) return JSON.parse(saved);
    } catch {}
    
    const initial: Record<string, VideoAnalytics> = {};
    [...MOCK_VIDEOS].forEach(v => {
      initial[v.id] = {
        views: v.views, likes: v.likes, dislikes: v.dislikes || 0, shares: Math.floor(v.views * 0.01),
        commentsCount: Math.floor(v.views * 0.005), watchTimeSeconds: v.views * 180, averageRetention: 0.4 + Math.random() * 0.3,
        replays: 0, engagementSpeed: Math.random(),
        subscribersGained: Math.floor(v.views * 0.002), uploadTimestampMs: Date.now() - (Math.random() * 86400000 * 30),
        dailyViews: Array.from({length: 7}, () => Math.floor(v.views / 7))
      };
    });
    return initial;
  });

  const [likedVideos, setLikedVideos] = useState<Video[]>(() => {
    try { return JSON.parse(localStorage.getItem('movion_liked') || '[]'); } catch { return []; }
  });
  const [dislikedVideos, setDislikedVideos] = useState<Video[]>(() => {
    try { return JSON.parse(localStorage.getItem('movion_disliked') || '[]'); } catch { return []; }
  });
  const [watchLater, setWatchLater] = useState<Video[]>(() => {
    try { return JSON.parse(localStorage.getItem('movion_watch_later') || '[]'); } catch { return []; }
  });
  const [history, setHistory] = useState<Video[]>(() => {
    try { return JSON.parse(localStorage.getItem('movion_history') || '[]'); } catch { return []; }
  });
  const [userVideos, setUserVideos] = useState<Video[]>(() => {
    try { return JSON.parse(localStorage.getItem('movion_user_videos') || '[]'); } catch { return []; }
  });
  const [hiddenVideos, setHiddenVideos] = useState<string[]>(() => {
    try { return JSON.parse(localStorage.getItem('movion_hidden_videos') || '[]'); } catch { return []; }
  });
  const [userEvents, setUserEvents] = useState<UserEventLog[]>(() => {
    try { return JSON.parse(localStorage.getItem('movion_user_events') || '[]'); } catch { return []; }
  });

  const [searchQuery, setSearchQuery] = useState('');
  const [historyPaused, setHistoryPaused] = useState(false);
  const [progress, setProgress] = useState<Record<string, number>>({});

  useEffect(() => {
    localStorage.setItem('movion_subscriptions_v2', JSON.stringify(subscriptions));
    localStorage.setItem('movion_user_channel', JSON.stringify(userChannel));
    localStorage.setItem('movion_analytics_v4', JSON.stringify(videoAnalytics));
    localStorage.setItem('movion_user_videos', JSON.stringify(userVideos));
    localStorage.setItem('movion_user_events', JSON.stringify(userEvents));
    localStorage.setItem('movion_history', JSON.stringify(history));
    localStorage.setItem('movion_liked', JSON.stringify(likedVideos));
    localStorage.setItem('movion_disliked', JSON.stringify(dislikedVideos));
    localStorage.setItem('movion_watch_later', JSON.stringify(watchLater));
    localStorage.setItem('movion_comments_v2', JSON.stringify(comments));
    localStorage.setItem('movion_hidden_videos', JSON.stringify(hiddenVideos));
    localStorage.setItem('movion_search_history', JSON.stringify(searchHistory));
  }, [subscriptions, userChannel, videoAnalytics, userVideos, userEvents, history, likedVideos, dislikedVideos, watchLater, comments, hiddenVideos, searchHistory]);

  const addToast = useCallback((message: string, type: 'success' | 'info' | 'error' = 'info') => {
    const id = Math.random().toString(36).substr(2, 9);
    setToasts(prev => [...prev, { id, message, type }]);
    setTimeout(() => { setToasts(prev => prev.filter(t => t.id !== id)); }, 3000);
  }, []);

  const removeToast = useCallback((id: string) => { 
    setToasts(prev => prev.filter(t => t.id !== id)); 
  }, []);

  const emitEvent = useCallback((event: AnalyticsEvent) => {
    const vId = event.videoId;
    setUserEvents(prevEvents => {
      const findVideo = [...MOCK_VIDEOS, ...userVideos].find(v => v.id === vId);
      const logEntry: UserEventLog = {
        id: Math.random().toString(36).substr(2, 9),
        userId: userChannel.id,
        action: event.type.toUpperCase(),
        videoId: vId,
        videoTitle: findVideo?.title,
        channelId: event.channelId || findVideo?.channelId,
        sourcePlatform: event.payload?.platform,
        timestamp: Date.now()
      };
      return [logEntry, ...prevEvents].slice(0, 50);
    });

    if (!vId) return;

    setVideoAnalytics(prev => {
      const current = prev[vId] || { views: 0, likes: 0, dislikes: 0, shares: 0, watchTimeSeconds: 0, averageRetention: 0, commentsCount: 0, replays: 0, engagementSpeed: 0, subscribersGained: 0, uploadTimestampMs: Date.now(), dailyViews: [0,0,0,0,0,0,0] };
      switch (event.type) {
        case 'watch_started': return { ...prev, [vId]: { ...current, views: (current.views || 0) + 1 } };
        case 'video_liked': return { ...prev, [vId]: { ...current, likes: (current.likes || 0) + (event.payload?.isLiked ? 1 : -1) } };
        case 'content_shared': return { ...prev, [vId]: { ...current, shares: (current.shares || 0) + 1, engagementSpeed: (current.engagementSpeed || 0) + 0.1 } };
        default: return prev;
      }
    });
  }, [userChannel.id, userVideos]);

  const toggleSubscription = useCallback((channelId: string) => {
    setSubscriptions(prev => {
      const isSubbed = !!prev[channelId];
      const newSubs = { ...prev };
      
      if (isSubbed) delete newSubs[channelId];
      else newSubs[channelId] = { channelId, subscribedAt: Date.now(), notificationLevel: 'ALL' };
      
      setAllChannels(channels => channels.map(c => c.id === channelId ? { ...c, subscribers: c.subscribers + (isSubbed ? -1 : 1) } : c));
      
      if (userChannel.id === channelId) {
        setUserChannel(prevChannel => ({ ...prevChannel, subscribers: prevChannel.subscribers + (isSubbed ? -1 : 1) }));
      }

      emitEvent({ type: 'channel_followed', channelId, payload: { isFollowed: !isSubbed } });
      addToast(isSubbed ? "Subscription removed" : "Subscribed", isSubbed ? "info" : "success");
      return newSubs;
    });
  }, [addToast, emitEvent, userChannel.id]);

  const toggleWatchLater = useCallback((v: Video) => {
    setWatchLater(prev => {
      const exists = prev.find(x => x.id === v.id);
      if (exists) {
        addToast("Removed from Watch Later", "info");
        return prev.filter(x => x.id !== v.id);
      } else {
        emitEvent({ type: 'content_shared', videoId: v.id, payload: { action: 'saved' } });
        addToast("Saved to Watch Later", "success");
        return [...prev, v];
      }
    });
  }, [addToast, emitEvent]);

  const toggleLike = useCallback((v: Video) => {
    setLikedVideos(prev => {
      const isLiked = prev.some(x => x.id === v.id);
      emitEvent({ type: 'video_liked', videoId: v.id, payload: { isLiked: !isLiked } });
      return isLiked ? prev.filter(x => x.id !== v.id) : [...prev, v];
    });
  }, [emitEvent]);

  const toggleDislike = useCallback((v: Video) => {
    setDislikedVideos(prev => {
      const isDisliked = prev.some(x => x.id === v.id);
      return isDisliked ? prev.filter(x => x.id !== v.id) : [...prev, v];
    });
  }, []);

  const hideVideo = useCallback((id: string) => {
    setHiddenVideos(prev => [...prev, id]);
    addToast("Video hidden", "info");
  }, [addToast]);

  const addToHistory = useCallback((v: Video) => {
    if (!historyPaused) {
      setHistory(prev => [v, ...prev.filter(x => x.id !== v.id)].slice(0, 50));
    }
  }, [historyPaused]);

  const recordEngagement = useCallback((v: Video, t: number) => {
    setProgress(prev => ({ ...prev, [v.id]: t }));
  }, []);

  const removeFromHistory = useCallback((id: string) => {
    setHistory(prev => prev.filter(v => v.id !== id));
  }, []);

  const clearHistory = useCallback(() => {
    setHistory([]);
    addToast("History cleared", "info");
  }, [addToast]);

  const togglePauseHistory = useCallback(() => {
    setHistoryPaused(prev => {
      const newState = !prev;
      addToast(newState ? "History paused" : "History resumed", "info");
      return newState;
    });
  }, [addToast]);

  const addComment = useCallback((vid: string, txt: string, pid?: string) => {
    const nc: Comment = { 
      id: Math.random().toString(36).substr(2, 9), 
      videoId: vid, 
      userId: userChannel.id, 
      userName: userChannel.name, 
      userHandle: userChannel.handle, 
      userAvatar: userChannel.avatar, 
      text: txt, 
      createdAt: Date.now(), 
      likeCount: 0, 
      dislikeCount: 0, 
      isLiked: false, 
      isDisliked: false, 
      pinned: false, 
      isOwner: true, 
      parentId: pid 
    };
    setComments(prev => ({ ...prev, [vid]: [nc, ...(prev[vid] || [])] }));
    emitEvent({ type: 'content_shared', videoId: vid, payload: { action: 'comment' } });
    addToast("Comment posted", "success");
  }, [userChannel, emitEvent, addToast]);

  const sendLiveMessage = useCallback((sid: string, t: string, isSC = false, amt = '', clr = 'bg-blue-500') => {
    const nm: LiveChatMessage = { 
      id: Math.random().toString(36).substr(2, 9), 
      userId: userChannel.id, 
      userName: userChannel.name, 
      userAvatar: userChannel.avatar, 
      text: t, 
      timestamp: Date.now(), 
      isSuperChat: isSC, 
      amount: amt, 
      color: clr 
    };
    setLiveChatMessages(prev => ({ ...prev, [sid]: [...(prev[sid] || []), nm].slice(-50) }));
  }, [userChannel]);

  const getFeed = useCallback((cat: string) => prioritizeVideos(
    [...MOCK_VIDEOS, ...userVideos].filter(v => v && !hiddenVideos.includes(v.id)), 
    Object.keys(subscriptions || {}), 
    history || [], 
    searchQuery || '', 
    cat
  ), [userVideos, hiddenVideos, subscriptions, history, searchQuery]);

  const getPulseFeed = useCallback(() => prioritizePulse(
    [...MOCK_VIDEOS, ...userVideos].filter(v => v && !hiddenVideos.includes(v.id))
  ), [userVideos, hiddenVideos]);

  const getSubscriptionFeed = useCallback((cid?: string, mode?: any) => prioritizeSubscriptions(
    [...MOCK_VIDEOS, ...userVideos].filter(v => v && !hiddenVideos.includes(v.id)), 
    subscriptions || {}, 
    history || [], 
    cid, 
    mode
  ), [userVideos, hiddenVideos, subscriptions, history]);

  const getChannel = useCallback((id: string) => 
    allChannels.find(c => c.id === id) || DEFAULT_CHANNEL, 
  [allChannels]);

  const getVideoComments = useCallback((vid: string) => {
    const raw = comments[vid] || [];
    return raw.filter(c => !c.parentId).map(p => ({ ...p, replies: raw.filter(r => r.parentId === p.id) }));
  }, [comments]);

  const updateChannelProfile = useCallback((upd: Partial<Channel>) => { 
    setUserChannel(prev => ({...prev, ...upd})); 
    setAllChannels(prev => prev.map(c => c.id === userChannel.id ? {...c, ...upd} : c)); 
    addToast("Profile updated", "success");
  }, [userChannel.id, addToast]);

  const clearActivityLog = useCallback(() => { 
    setUserEvents([]); 
    addToast("Activity log cleared", "info"); 
  }, [addToast]);

  const value = useMemo(() => ({
    currentUser: { id: 'sha_user_777', name: userChannel.name, handle: userChannel.handle, avatar: userChannel.avatar, permissions: { canUpload: true, canComment: true, isCreator: true, monetizationEnabled: true } },
    userChannel, allChannels, videoAnalytics, history, watchLater, likedVideos, dislikedVideos, subscriptions: Object.keys(subscriptions || {}), userVideos, userEvents, liveChatMessages, hiddenVideos,
    searchQuery, setSearchQuery, emitEvent, progress, notifications, unreadCount, toasts, historyPaused,
    getFeed, getPulseFeed, getSubscriptionFeed,
    toggleSubscription, isSubscribed: (id: string) => !!subscriptions[id], getSubNotification: (id: string) => subscriptions[id]?.notificationLevel || 'PERSONALIZED',
    setSubNotification: (id: string, lvl: NotificationLevel) => setSubscriptions(p => p[id] ? {...p, [id]: {...p[id], notificationLevel: lvl}} : p),
    getChannel, addToast, removeToast, toggleWatchLater, toggleLike, toggleDislike, hideVideo,
    uploadVideo: (v: Video) => { setUserVideos(p => [v, ...(p || [])]); addToast("Video uploaded", "success"); },
    deleteVideo: (id: string) => setUserVideos(p => p.filter(v => v.id !== id)),
    updateChannelProfile, clearActivityLog, addComment, getVideoComments, sendLiveMessage, addToHistory,
    recordEngagement, removeFromHistory, clearHistory, togglePauseHistory,
    updateChannelBanner: () => {}, getChannelBanner: () => undefined,
    addToSearchHistory: () => {}, removeFromSearchHistory: () => {}
  }), [
    userChannel, allChannels, videoAnalytics, history, watchLater, likedVideos, dislikedVideos, subscriptions, userVideos, userEvents, liveChatMessages, hiddenVideos, searchQuery, progress, notifications, unreadCount, toasts, historyPaused, 
    getFeed, getPulseFeed, getSubscriptionFeed, toggleSubscription, getChannel, addToast, removeToast, toggleWatchLater, toggleLike, toggleDislike, hideVideo, updateChannelProfile, clearActivityLog, addComment, getVideoComments, sendLiveMessage, addToHistory, recordEngagement, removeFromHistory, clearHistory, togglePauseHistory
  ]);

  return React.createElement(UserStoreContext.Provider, { value }, children);
};

export const useUserStore = () => useContext(UserStoreContext);
