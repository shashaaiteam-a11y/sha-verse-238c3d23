
import React, { ReactNode } from 'react';
import { useUserStore } from '../store';
import { AnalyticsEventType } from '../types';

interface ActionButtonProps {
  icon: ReactNode;
  label?: string | number;
  active?: boolean;
  type: AnalyticsEventType;
  videoId?: string;
  channelId?: string;
  payload?: any;
  onClick?: () => void;
  variant?: 'circular' | 'pill';
  className?: string;
}

const ActionButton: React.FC<ActionButtonProps> = ({ 
  icon, label, active, type, videoId, channelId, payload, onClick, variant = 'circular', className = '' 
}) => {
  const { emitEvent } = useUserStore();

  const handleClick = (e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    
    emitEvent({ type, videoId, channelId, payload });
    
    if (onClick) onClick();
  };

  const baseStyles = "flex items-center justify-center gap-2 transition-all duration-300 transform active:scale-90 border border-[#e5e5e5] shadow-sm";
  const variants = {
    circular: "p-4 rounded-full",
    pill: "px-5 py-2 rounded-full text-xs font-black uppercase tracking-widest"
  };

  const activeStyles = active 
    ? "bg-red-600 text-white border-red-500 shadow-red-600/20" 
    : "bg-[#f2f2f2] text-[#030303] hover:bg-[#e5e5e5]";

  return (
    <div className="flex flex-col items-center gap-1 group">
      <button 
        onClick={handleClick}
        className={`${baseStyles} ${variants[variant]} ${activeStyles} ${className}`}
      >
        {icon}
        {variant === 'pill' && label && <span>{label}</span>}
      </button>
      {variant === 'circular' && label && (
        <span className="text-[10px] font-black uppercase tracking-widest text-[#606060]">{label}</span>
      )}
    </div>
  );
};

export default ActionButton;
