
import React from 'react';
import { Video } from '../types';
import { useNavigate } from 'react-router-dom';
import { Zap } from 'lucide-react';

interface ShortsCardProps {
  video: Video;
}

const ShortsCard: React.FC<ShortsCardProps> = ({ video }) => {
  const navigate = useNavigate();

  const handleOpenShort = (e: React.MouseEvent) => {
    e.preventDefault();
    // Navigate to full-screen short view
    navigate(`/shorts/${video.id}`);
  };

  return (
    <div 
      onClick={handleOpenShort}
      className="flex flex-col group relative overflow-hidden rounded-2xl cursor-pointer transition-all active:scale-[0.96] snap-start shrink-0 select-none shadow-xl border border-white/5"
    >
      {/* 1. 9:16 Aspect Ratio Frame - Story Style */}
      <div className="aspect-[9/16] w-full bg-[#1a1a1a] relative overflow-hidden transition-all duration-500">
        <img 
          src={video.thumbnail} 
          alt={video.title} 
          className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110" 
          loading="lazy"
        />
        
        {/* 2. Immersive Story Overlays (Gradients for UI readability) */}
        <div className="absolute inset-x-0 top-0 h-1/4 bg-gradient-to-b from-black/70 to-transparent" />
        <div className="absolute inset-x-0 bottom-0 h-2/5 bg-gradient-to-t from-black/90 via-black/30 to-transparent" />

        {/* 3. Top Left: Creator Profile Picture with Dynamic Story Ring */}
        <div className="absolute top-2.5 left-2.5 z-10">
          <div className="p-[2.5px] bg-gradient-to-tr from-[#f09433] via-[#e6683c] via-[#dc2743] via-[#cc2366] to-[#bc1888] rounded-full shadow-xl ring-1 ring-black/10 transform transition-all duration-300 group-hover:scale-110">
            <div className="p-[1.5px] bg-black rounded-full">
              <img 
                src={video.channelAvatar} 
                className="w-8 h-8 sm:w-10 sm:h-10 rounded-full object-cover" 
                alt={video.channelName} 
              />
            </div>
          </div>
        </div>

        {/* 4. Top Right: Pulse Duration Badge */}
        <div className="absolute top-2.5 right-2.5 z-10">
          <div className="bg-black/40 backdrop-blur-md px-1.5 py-0.5 rounded-lg text-white shadow-lg flex items-center gap-1 border border-white/10 group-hover:bg-red-600 transition-colors">
            <Zap size={10} fill="white" className="text-white" />
            <span className="text-[9px] font-black uppercase tracking-tighter">{video.duration}</span>
          </div>
        </div>

        {/* 5. Bottom Details: Title & Creator Label */}
        <div className="absolute bottom-0 left-0 right-0 p-3 sm:p-4 flex flex-col justify-end pointer-events-none">
          <h3 className="text-[11px] sm:text-[13px] font-black leading-tight text-white drop-shadow-2xl line-clamp-2 mb-1 group-hover:text-blue-300 transition-colors">
            {video.title}
          </h3>
          <p className="text-[9px] sm:text-[10px] font-bold text-white/70 truncate uppercase tracking-tighter">
             {video.channelName}
          </p>
        </div>
        
        {/* 6. Story Interactive Edge Glow & Hover Overlay */}
        <div className="absolute inset-0 ring-1 ring-inset ring-white/5 group-hover:ring-white/20 rounded-2xl transition-all pointer-events-none" />
        <div className="absolute inset-0 bg-white/0 group-hover:bg-white/[0.03] transition-colors pointer-events-none" />
      </div>
    </div>
  );
};

export default ShortsCard;
