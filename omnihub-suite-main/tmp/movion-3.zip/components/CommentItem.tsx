
import React, { useState } from 'react';
import { Comment } from '../types';
import { ThumbsUp, ThumbsDown, MoreVertical, Flag, Pin, CheckCircle2 } from 'lucide-react';
import { useUserStore } from '../store';
import { Link } from 'react-router-dom';

interface CommentItemProps {
  comment: Comment;
  videoId: string;
  isCreatorView?: boolean;
}

const CommentItem: React.FC<CommentItemProps> = ({ comment, videoId, isCreatorView }) => {
  const { toggleCommentLike, addComment, pinComment } = useUserStore();
  const [isReplying, setIsReplying] = useState(false);
  const [replyText, setReplyText] = useState('');
  const [showMenu, setShowMenu] = useState(false);

  const timeAgo = (timestamp: number) => {
    const seconds = Math.floor((Date.now() - timestamp) / 1000);
    if (seconds < 60) return 'Just now';
    const minutes = Math.floor(seconds / 60);
    if (minutes < 60) return `${minutes} minutes ago`;
    const hours = Math.floor(minutes / 60);
    if (hours < 24) return `${hours} hours ago`;
    const days = Math.floor(hours / 24);
    return `${days} days ago`;
  };

  const handleReply = (e: React.FormEvent) => {
    e.preventDefault();
    if (replyText.trim()) {
      addComment(videoId, replyText, comment.id);
      setReplyText('');
      setIsReplying(false);
    }
  };

  const handlePin = () => {
    pinComment(videoId, comment.id);
    setShowMenu(false);
  };

  return (
    <div className="flex gap-4 group/comment w-full">
      <Link to={`/channel/user-${comment.userId}`} className="shrink-0">
        <img src={comment.userAvatar} className="w-10 h-10 rounded-full object-cover" alt="" />
      </Link>
      
      <div className="flex-1 min-w-0">
        <div className="flex flex-col gap-1">
          {/* Header Line */}
          <div className="flex items-center gap-2 mb-0.5">
            <span className={`text-[13px] font-bold text-[#030303] flex items-center gap-1 ${comment.isOwner ? 'bg-[#888888] text-white px-2 py-0.5 rounded-full text-[11px]' : ''}`}>
              {comment.userName}
              {comment.isOwner && !comment.userName.includes('Creator') && <CheckCircle2 size={12} className="text-white ml-0.5"/>}
            </span>
            <span className="text-[12px] text-[#606060]">{timeAgo(comment.createdAt)}</span>
            {comment.pinned && (
              <div className="flex items-center gap-1 text-[11px] font-medium text-[#606060] bg-gray-100 px-1.5 py-0.5 rounded">
                <Pin size={12} fill="currentColor" /> Pinned
              </div>
            )}
          </div>

          {/* Comment Text */}
          <p className="text-[14px] text-[#030303] leading-relaxed whitespace-pre-wrap">{comment.text}</p>

          {/* Action Bar */}
          <div className="flex items-center gap-4 mt-1">
            <button 
              onClick={() => toggleCommentLike(videoId, comment.id, true)}
              className={`flex items-center gap-1.5 p-1 -ml-1 rounded-full hover:bg-gray-100 transition-colors ${comment.isLiked ? 'text-black' : 'text-[#030303]'}`}
            >
              <ThumbsUp size={16} fill={comment.isLiked ? "currentColor" : "none"} />
              <span className="text-xs font-medium text-[#606060]">{comment.likeCount > 0 ? Intl.NumberFormat('en', { notation: 'compact' }).format(comment.likeCount) : ''}</span>
            </button>

            <button 
              onClick={() => toggleCommentLike(videoId, comment.id, false)}
              className={`p-1 rounded-full hover:bg-gray-100 transition-colors ${comment.isDisliked ? 'text-black' : 'text-[#030303]'}`}
            >
              <ThumbsDown size={16} fill={comment.isDisliked ? "currentColor" : "none"} />
            </button>

            <button 
              onClick={() => setIsReplying(!isReplying)}
              className="text-[12px] font-bold text-[#030303] hover:bg-gray-100 px-3 py-1.5 rounded-full transition-colors"
            >
              Reply
            </button>
          </div>

          {/* Inline Reply Input */}
          {isReplying && (
            <form onSubmit={handleReply} className="flex flex-col gap-2 mt-2 animate-in fade-in slide-in-from-top-1">
              <div className="flex gap-3 items-start">
                <img src={`https://api.dicebear.com/7.x/avataaars/svg?seed=main`} className="w-6 h-6 rounded-full mt-1" alt="" />
                <div className="flex-1">
                  <input 
                    autoFocus 
                    value={replyText}
                    onChange={e => setReplyText(e.target.value)}
                    placeholder="Add a reply..."
                    className="w-full bg-transparent border-b border-[#3e3e3e] focus:border-[#030303] outline-none py-1 text-sm transition-colors pb-2"
                  />
                  <div className="flex justify-end gap-2 mt-2">
                    <button type="button" onClick={() => setIsReplying(false)} className="px-3 py-1.5 text-xs font-bold hover:bg-gray-100 rounded-full">Cancel</button>
                    <button type="submit" disabled={!replyText.trim()} className="px-3 py-1.5 text-xs font-bold bg-[#3ea6ff] text-white rounded-full disabled:bg-gray-200 disabled:text-gray-500">Reply</button>
                  </div>
                </div>
              </div>
            </form>
          )}

          {/* Replies Section */}
          {comment.replies && comment.replies.length > 0 && (
            <div className="mt-2">
              <button className="flex items-center gap-2 text-blue-600 font-bold text-xs hover:bg-blue-50 px-3 py-1.5 rounded-full w-fit group/replies mb-2">
                <div className="w-0.5 h-3 bg-blue-600 rotate-12 group-hover/replies:rotate-0 transition-transform"></div>
                {comment.replies.length} replies
              </button>
              <div className="pl-0 space-y-4 border-l-2 border-transparent hover:border-[#e5e5e5] transition-colors ml-2 pl-2">
                {comment.replies.map(reply => (
                  <CommentItem key={reply.id} comment={reply} videoId={videoId} isCreatorView={isCreatorView} />
                ))}
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Options Menu */}
      <div className="relative">
        <button 
          onClick={() => setShowMenu(!showMenu)} 
          className="opacity-0 group-hover/comment:opacity-100 p-2 hover:bg-gray-100 rounded-full transition-all text-[#030303]"
        >
          <MoreVertical size={16} />
        </button>
        {showMenu && (
          <div className="absolute right-0 top-8 bg-white shadow-xl border border-gray-100 rounded-xl py-2 w-40 z-20 animate-in fade-in zoom-in duration-100">
            {isCreatorView && !comment.parentId && (
              <button onClick={handlePin} className="w-full text-left px-4 py-2 hover:bg-gray-100 text-sm font-medium flex items-center gap-2">
                <Pin size={14} /> {comment.pinned ? 'Unpin' : 'Pin'}
              </button>
            )}
            <button onClick={() => setShowMenu(false)} className="w-full text-left px-4 py-2 hover:bg-gray-100 text-sm font-medium flex items-center gap-2 text-red-600">
              <Flag size={14} /> Report
            </button>
          </div>
        )}
      </div>
    </div>
  );
};

export default CommentItem;
