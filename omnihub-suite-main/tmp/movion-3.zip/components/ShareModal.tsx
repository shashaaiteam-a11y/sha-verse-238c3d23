
import React, { useState, useEffect } from 'react';
import { X, Copy, Check, Facebook, Twitter, MessageCircle, Mail, Code, ExternalLink } from 'lucide-react';
import { useUserStore } from '../store';

interface ShareModalProps {
  isOpen: boolean;
  onClose: () => void;
  videoId: string;
  videoTitle: string;
  currentTime?: number;
}

const ShareModal: React.FC<ShareModalProps> = ({ isOpen, onClose, videoId, videoTitle, currentTime = 0 }) => {
  const [copied, setCopied] = useState(false);
  const [startAt, setStartAt] = useState(false);
  const [timestamp, setTimestamp] = useState(Math.floor(currentTime));
  const { emitEvent, addToast } = useUserStore();

  const baseUrl = `${window.location.origin}/#/watch/${videoId}`;
  const shareUrl = startAt ? `${baseUrl}?t=${timestamp}` : baseUrl;

  useEffect(() => {
    if (isOpen) setTimestamp(Math.floor(currentTime));
  }, [isOpen, currentTime]);

  const handleCopy = () => {
    navigator.clipboard.writeText(shareUrl);
    setCopied(true);
    emitEvent({ type: 'content_shared', videoId, payload: { platform: 'copy_link', hasTimestamp: startAt } });
    addToast("Link copied to clipboard", "success");
    setTimeout(() => setCopied(false), 2000);
  };

  const socialPlatforms = [
    { name: 'WhatsApp', icon: <MessageCircle size={24} />, color: 'bg-[#25D366]', url: `https://wa.me/?text=${encodeURIComponent(videoTitle + ' ' + shareUrl)}` },
    { name: 'Facebook', icon: <Facebook size={24} />, color: 'bg-[#1877F2]', url: `https://www.facebook.com/sharer/sharer.php?u=${encodeURIComponent(shareUrl)}` },
    { name: 'Twitter', icon: <Twitter size={24} />, color: 'bg-[#1DA1F2]', url: `https://twitter.com/intent/tweet?text=${encodeURIComponent(videoTitle)}&url=${encodeURIComponent(shareUrl)}` },
    { name: 'Email', icon: <Mail size={24} />, color: 'bg-gray-600', url: `mailto:?subject=${encodeURIComponent(videoTitle)}&body=${encodeURIComponent(shareUrl)}` },
  ];

  const handleSocialClick = (platform: string, url: string) => {
    emitEvent({ type: 'content_shared', videoId, payload: { platform: platform.toLowerCase(), hasTimestamp: startAt } });
    window.open(url, '_blank');
  };

  if (!isOpen) return null;

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };

  return (
    <div className="fixed inset-0 z-[5000] flex items-center justify-center p-4">
      <div className="absolute inset-0 bg-black/60 backdrop-blur-sm animate-in fade-in duration-300" onClick={onClose} />
      <div className="relative w-full max-w-md bg-white rounded-[32px] shadow-2xl overflow-hidden animate-in zoom-in duration-200">
        <div className="flex items-center justify-between px-6 py-5 border-b border-gray-100">
          <h3 className="font-black uppercase tracking-widest text-sm text-[#030303]">Share Video</h3>
          <button onClick={onClose} className="p-2 hover:bg-gray-100 rounded-full transition-colors text-gray-400 hover:text-black">
            <X size={20} />
          </button>
        </div>

        <div className="p-6">
          {/* Social Grid */}
          <div className="grid grid-cols-4 gap-4 mb-8">
            {socialPlatforms.map((platform) => (
              <button 
                key={platform.name}
                onClick={() => handleSocialClick(platform.name, platform.url)}
                className="flex flex-col items-center gap-2 group"
              >
                <div className={`w-12 h-12 rounded-full flex items-center justify-center text-white shadow-lg group-hover:scale-110 transition-transform ${platform.color}`}>
                  {platform.icon}
                </div>
                <span className="text-[10px] font-black uppercase text-gray-500 tracking-tighter">{platform.name}</span>
              </button>
            ))}
          </div>

          {/* Link Section */}
          <div className="space-y-4">
            <div className="flex items-center bg-gray-50 border border-gray-200 rounded-2xl p-2 pl-4">
              <span className="flex-1 text-sm font-medium text-gray-600 truncate mr-4">{shareUrl}</span>
              <button 
                onClick={handleCopy}
                className={`flex items-center gap-2 px-6 py-2 rounded-xl text-xs font-black uppercase tracking-widest transition-all ${copied ? 'bg-green-600 text-white' : 'bg-blue-600 text-white hover:bg-blue-700'}`}
              >
                {copied ? <Check size={14} /> : <Copy size={14} />}
                {copied ? 'Copied' : 'Copy'}
              </button>
            </div>

            <div className="flex items-center justify-between px-2 pt-2">
              <div className="flex items-center gap-3">
                <input 
                  type="checkbox" 
                  id="start-at" 
                  checked={startAt} 
                  onChange={(e) => setStartAt(e.target.checked)}
                  className="w-5 h-5 rounded border-gray-300 text-blue-600 focus:ring-blue-500"
                />
                <label htmlFor="start-at" className="text-sm font-bold text-gray-700">Start at {formatTime(timestamp)}</label>
              </div>
              
              <div className="flex items-center gap-2 text-[10px] font-black text-blue-600 uppercase tracking-widest hover:underline cursor-pointer">
                <Code size={14} /> Embed
              </div>
            </div>
          </div>
        </div>

        <div className="px-6 py-4 bg-gray-50 border-t border-gray-100 flex items-center justify-between">
           <p className="text-[9px] font-black text-gray-400 uppercase tracking-widest">Share count is tracked for virality</p>
           <ExternalLink size={14} className="text-gray-300" />
        </div>
      </div>
    </div>
  );
};

export default ShareModal;
