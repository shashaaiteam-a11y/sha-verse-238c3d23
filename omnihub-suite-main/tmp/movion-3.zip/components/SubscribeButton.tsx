
import React, { useState, useRef, useEffect } from 'react';
import { Bell, BellRing, ChevronDown, Check, Flag, BellOff } from 'lucide-react';
import { useUserStore } from '../store';
import { NotificationLevel } from '../types';

interface SubscribeButtonProps {
  channelId: string;
  variant?: 'default' | 'minimal';
  size?: 'sm' | 'md';
  className?: string;
  dropdownAlign?: 'left' | 'right';
  dropdownPosition?: 'top' | 'bottom';
}

const SubscribeButton: React.FC<SubscribeButtonProps> = ({ 
  channelId, 
  variant = 'default', 
  size = 'md', 
  className = '',
  dropdownAlign = 'right',
  dropdownPosition = 'bottom'
}) => {
  const { isSubscribed, toggleSubscription, getSubNotification, setSubNotification } = useUserStore();
  const [showBellMenu, setShowBellMenu] = useState(false);
  const bellMenuRef = useRef<HTMLDivElement>(null);

  const subscribed = isSubscribed(channelId);
  const notificationLevel = getSubNotification(channelId);

  useEffect(() => {
    const handleClickOutside = (e: MouseEvent) => {
      if (bellMenuRef.current && !bellMenuRef.current.contains(e.target as Node)) {
        setShowBellMenu(false);
      }
    };
    if (showBellMenu) {
      document.addEventListener('mousedown', handleClickOutside);
    }
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, [showBellMenu]);

  const handleNotificationSelect = (e: React.MouseEvent, level: NotificationLevel) => {
    e.stopPropagation();
    setSubNotification(channelId, level);
    setShowBellMenu(false);
  };

  const getBellIcon = () => {
    const iconSize = size === 'sm' ? 18 : 20;
    if (notificationLevel === 'ALL') return <BellRing size={iconSize} fill="currentColor" />;
    if (notificationLevel === 'NONE') return <BellOff size={iconSize} className="text-[#606060]" />;
    return <Bell size={iconSize} />;
  };

  const heightClass = size === 'sm' ? 'h-9' : 'h-9 sm:h-10';
  const textClass = size === 'sm' ? 'text-xs' : 'text-sm';
  const pxClass = size === 'sm' ? 'px-3' : 'px-4';

  if (subscribed) {
    return (
      <div className={`relative inline-block ${className} z-[100]`} ref={bellMenuRef}>
        <div className={`flex items-center bg-[#f2f2f2] hover:bg-[#e5e5e5] rounded-full transition-all group overflow-hidden border border-[#0000000d] ${heightClass}`}>
          <button 
            onClick={(e) => { e.stopPropagation(); setShowBellMenu(!showBellMenu); }}
            className={`flex items-center gap-2 ${pxClass} font-medium text-[#0f0f0f] active:scale-95 transition-transform ${textClass}`}
          >
            {getBellIcon()}
            {variant !== 'minimal' && <span className="font-semibold">Subscribed</span>}
            <ChevronDown size={16} className={`text-[#606060] transition-transform duration-200 ${showBellMenu ? 'rotate-180' : ''}`} />
          </button>
        </div>

        {showBellMenu && (
          <div className={`absolute ${dropdownPosition === 'top' ? 'bottom-full mb-2' : 'top-full mt-2'} w-64 bg-white border border-[#0000001a] rounded-xl shadow-[0_4px_32px_0_rgba(0,0,0,0.15)] z-[100] py-2 animate-in fade-in zoom-in-95 duration-100 ${dropdownAlign === 'right' ? 'right-0 origin-top-right' : 'left-0 origin-top-left'}`}>
            <div className="px-4 py-2 text-xs font-bold text-[#606060] uppercase tracking-wider">Notifications</div>
            <button 
              onClick={(e) => handleNotificationSelect(e, 'ALL')} 
              className={`w-full flex items-center justify-between px-4 py-3 hover:bg-[#f2f2f2] text-sm text-left transition-colors ${notificationLevel === 'ALL' ? 'bg-[#f2f2f2]' : ''}`}
            >
              <div className="flex items-center gap-3 font-medium text-[#0f0f0f]"><BellRing size={20} /> All</div>
              {notificationLevel === 'ALL' && <Check size={18} />}
            </button>
            <button 
              onClick={(e) => handleNotificationSelect(e, 'PERSONALIZED')} 
              className={`w-full flex items-center justify-between px-4 py-3 hover:bg-[#f2f2f2] text-sm text-left transition-colors ${notificationLevel === 'PERSONALIZED' ? 'bg-[#f2f2f2]' : ''}`}
            >
              <div className="flex items-center gap-3 font-medium text-[#0f0f0f]"><Bell size={20} /> Personalized</div>
              {notificationLevel === 'PERSONALIZED' && <Check size={18} />}
            </button>
            <button 
              onClick={(e) => handleNotificationSelect(e, 'NONE')} 
              className={`w-full flex items-center justify-between px-4 py-3 hover:bg-[#f2f2f2] text-sm text-left transition-colors ${notificationLevel === 'NONE' ? 'bg-[#f2f2f2]' : ''}`}
            >
              <div className="flex items-center gap-3 font-medium text-[#0f0f0f]"><BellOff size={20} /> None</div>
              {notificationLevel === 'NONE' && <Check size={18} />}
            </button>
            <div className="h-[1px] bg-[#0000001a] my-2" />
            <button 
              onClick={(e) => { e.stopPropagation(); toggleSubscription(channelId); setShowBellMenu(false); }}
              className="w-full flex items-center gap-3 px-4 py-3 hover:bg-[#f2f2f2] text-sm text-left transition-colors font-medium text-[#0f0f0f]"
            >
              <div className="w-5 flex justify-center"><Flag size={18} /></div> Unsubscribe
            </button>
          </div>
        )}
      </div>
    );
  }

  return (
    <button 
      onClick={(e) => { e.stopPropagation(); toggleSubscription(channelId); }}
      className={`${heightClass} ${pxClass} ${textClass} ${className} bg-[#cc0000] text-white rounded-full font-medium hover:bg-[#cc0000]/90 transition-all active:scale-95 shadow-sm shrink-0 flex items-center justify-center`}
    >
      Subscribe
    </button>
  );
};

export default SubscribeButton;
