
import React, { useState, useRef, useEffect } from 'react';
import { Video } from '../types';
import { Link, useNavigate } from 'react-router-dom';
import { Play, CheckCircle2, Clock, ListPlus } from 'lucide-react';
import { useUserStore } from '../store';
import VideoOptionsButton from './VideoOptionsButton';
import VideoOptionsBottomSheet from './VideoOptionsBottomSheet';
import PlaylistSelectorModal from './PlaylistSelectorModal';

interface VideoCardProps {
  video: Video;
  layout?: 'grid' | 'list' | 'list-large';
}

const VideoCard: React.FC<VideoCardProps> = ({ video, layout = 'grid' }) => {
  const { 
    toggleWatchLater, 
    watchLater, 
    userChannel, 
    deleteVideo,
    hideVideo,
    hiddenVideos
  } = useUserStore();
  
  const [showMenu, setShowMenu] = useState(false);
  const [showPlaylistModal, setShowPlaylistModal] = useState(false);
  const [isHovered, setIsHovered] = useState(false);
  const previewVideoRef = useRef<HTMLVideoElement>(null);
  const navigate = useNavigate();
  
  const isSavedInWatchLater = watchLater.some((v: Video) => v.id === video.id);
  const isOwner = video.channelId === userChannel.id;
  const isHidden = hiddenVideos.includes(video.id);

  if (isHidden) return null;

  useEffect(() => {
    let playTimeout: number;
    if (isHovered && previewVideoRef.current && layout === 'grid') {
      playTimeout = window.setTimeout(() => {
        previewVideoRef.current?.play().catch(() => {});
      }, 600);
    } else {
      previewVideoRef.current?.pause();
      if (previewVideoRef.current) previewVideoRef.current.currentTime = 0;
    }
    return () => clearTimeout(playTimeout);
  }, [isHovered, layout]);

  const handleMenuToggle = (e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation(); 
    setShowMenu(!showMenu);
  };

  const stopProp = (e: React.MouseEvent) => {
    e.stopPropagation();
    e.preventDefault();
  };

  const onAction = (action: string) => {
    switch (action) {
      case 'edit': navigate('/studio'); break;
      case 'analytics': navigate('/studio'); break;
      case 'delete':
        if(confirm('Delete this video forever?')) deleteVideo(video.id);
        break;
      case 'watch_later': toggleWatchLater(video); break;
      case 'playlist': setShowPlaylistModal(true); break;
      case 'not_interested': hideVideo(video.id); break;
      case 'share':
        navigator.clipboard.writeText(window.location.origin + '/#/watch/' + video.id);
        alert('Link copied!');
        break;
      default: break;
    }
    setShowMenu(false);
  };

  const renderThumbnail = () => (
    <div className={`relative aspect-video rounded-xl overflow-hidden bg-[#eeeeee] shadow-sm group-hover:shadow-md transition-all duration-300 ${layout === 'grid' ? '' : (layout === 'list-large' ? 'w-40 sm:w-56 md:w-64' : 'w-32 sm:w-40 md:w-44')}`}>
      <img src={video.thumbnail} className={`w-full h-full object-cover transition-opacity duration-300 ${isHovered && layout === 'grid' ? 'opacity-0' : 'opacity-100'}`} alt={video.title} />
      {layout === 'grid' && (
        <video
          ref={previewVideoRef}
          src={isHovered ? video.videoUrl : undefined}
          muted
          loop
          playsInline
          className={`absolute inset-0 w-full h-full object-cover transition-opacity duration-500 pointer-events-none ${isHovered ? 'opacity-100' : 'opacity-0'}`}
        />
      )}
      <span className="absolute bottom-1 right-1 bg-black/80 text-white text-[10px] md:text-[11px] font-bold px-1.5 py-0.5 rounded">
        {video.duration}
      </span>
      <div className="absolute inset-0 bg-black/10 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center pointer-events-none">
         <Play size={layout === 'grid' ? 32 : 20} fill="white" className="text-white drop-shadow-lg" />
      </div>
      
      <div className={`absolute top-2 right-2 flex flex-col gap-1.5 transition-opacity duration-200 ${isHovered ? 'opacity-100' : 'opacity-0'} hidden lg:flex`}>
        <button 
          onClick={(e) => { stopProp(e); toggleWatchLater(video); }}
          className="p-2 bg-black/70 hover:bg-black rounded-lg text-white shadow-xl transition-all active:scale-90"
        >
          <Clock size={18} className={isSavedInWatchLater ? "fill-blue-500 text-blue-500" : "text-white"} />
        </button>
        <button 
          onClick={(e) => { stopProp(e); setShowPlaylistModal(true); }}
          className="p-2 bg-black/70 hover:bg-black rounded-lg text-white shadow-xl transition-all active:scale-90"
        >
          <ListPlus size={18} />
        </button>
      </div>
    </div>
  );

  if (layout === 'list' || layout === 'list-large') {
    const isLarge = layout === 'list-large';
    return (
      <div className={`flex gap-3 md:gap-4 mb-2 group relative hover:bg-[#f2f2f2] p-2 rounded-2xl transition-all ${isLarge ? 'items-start' : 'items-center'}`}>
        <Link to={`/watch/${video.id}`} className="flex-shrink-0">{renderThumbnail()}</Link>
        <div className="flex flex-col flex-1 min-w-0 pr-10 relative">
          <div className="flex justify-between items-start gap-2">
            <Link to={`/watch/${video.id}`} className="flex-1 min-w-0">
              <h3 className={`font-bold line-clamp-2 leading-tight text-[#030303] mb-1.5 transition-colors group-hover:text-blue-600 ${isLarge ? 'text-base md:text-[17px]' : 'text-sm md:text-[15px]'}`}>{video.title}</h3>
            </Link>
            <div className="absolute top-0 right-0">
               <VideoOptionsButton onClick={handleMenuToggle} isActive={showMenu} className="group-hover:opacity-100 text-[#030303]" />
               <VideoOptionsBottomSheet video={video} isOpen={showMenu} onClose={() => setShowMenu(false)} isOwner={isOwner} onAction={onAction} isSavedInWatchLater={isSavedInWatchLater} />
            </div>
          </div>
          <div className="flex flex-col gap-1">
            <div className={`flex items-center gap-1.5 ${isLarge ? 'mt-1 order-last' : ''}`}>
              {isLarge && <img src={video.channelAvatar} className="w-6 h-6 rounded-full hidden sm:block object-cover border border-gray-100" alt="" />}
              <Link to={`/channel/${video.channelId}`} className="text-xs md:text-[13px] text-[#606060] hover:text-[#030303] flex items-center gap-1 font-medium">{video.channelName} <CheckCircle2 size={12} className="text-[#606060]" /></Link>
            </div>
            <div className="text-[11px] md:text-xs text-[#606060]">
              <span>{Intl.NumberFormat('en', { notation: 'compact' }).format(video.views)} views • {video.timestamp}</span>
            </div>
            {isLarge && <p className="line-clamp-2 text-xs text-[#606060] mt-1.5 leading-relaxed max-w-2xl">{video.description}</p>}
          </div>
        </div>
        <PlaylistSelectorModal isOpen={showPlaylistModal} onClose={() => setShowPlaylistModal(false)} />
      </div>
    );
  }

  return (
    <div 
      className="flex flex-col gap-3.5 group cursor-pointer animate-in fade-in slide-in-from-bottom-2 duration-400 bg-white"
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
      onClick={() => navigate(`/watch/${video.id}`)}
    >
      {renderThumbnail()}
      <div className="flex gap-3 px-0.5 bg-white">
        <Link to={`/channel/${video.channelId}`} className="shrink-0 mt-0.5" onClick={(e) => e.stopPropagation()}>
          <img src={video.channelAvatar} className="w-9 h-9 rounded-full object-cover border border-gray-100" alt="" />
        </Link>
        <div className="flex-1 min-w-0">
          <div className="flex justify-between items-start gap-1 relative">
            <h3 className="text-[14px] sm:text-[15px] font-bold line-clamp-2 leading-[1.3] text-[#030303] group-hover:text-blue-700 transition-colors flex-1 min-h-[2.4rem] pr-2">{video.title}</h3>
            <div className="shrink-0 relative">
              <VideoOptionsButton onClick={handleMenuToggle} isActive={showMenu} size={18} className="text-[#030303]" />
              <VideoOptionsBottomSheet video={video} isOpen={showMenu} onClose={() => setShowMenu(false)} isOwner={isOwner} onAction={onAction} isSavedInWatchLater={isSavedInWatchLater} />
            </div>
          </div>
          <div className="mt-1 flex flex-col gap-0.5">
            <Link to={`/channel/${video.channelId}`} className="text-[12px] sm:text-[13px] text-[#606060] hover:text-[#030303] flex items-center gap-1 w-fit font-medium" onClick={(e) => e.stopPropagation()}>{video.channelName} <CheckCircle2 size={12} className="text-[#606060]" /></Link>
            <div className="text-[12px] sm:text-[13px] text-[#606060] font-medium">
              <span>{Intl.NumberFormat('en', { notation: 'compact' }).format(video.views)} views • {video.timestamp}</span>
            </div>
          </div>
        </div>
      </div>
      <PlaylistSelectorModal isOpen={showPlaylistModal} onClose={() => setShowPlaylistModal(false)} />
    </div>
  );
};

export default VideoCard;
