
import React, { useEffect, useRef, useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { 
  MessageSquare, Share2, Music2, Volume2, VolumeX,
  Pause, Loader2, Heart, ArrowLeft, MoreVertical, AlertCircle, ThumbsDown
} from 'lucide-react';
import { Video } from '../types';
import { useUserStore } from '../store';
import ActionButton from './ActionButton';
import SubscribeButton from './SubscribeButton';
import ShareModal from './ShareModal';

interface ShortsPlayerProps {
  video: Video;
  isActive: boolean;
  isMuted: boolean;
  onMuteToggle: () => void;
  shouldPreload?: boolean;
}

const ShortsPlayer: React.FC<ShortsPlayerProps> = ({ video, isActive, isMuted, onMuteToggle, shouldPreload = false }) => {
  const navigate = useNavigate();
  const { toggleLike, toggleDislike, likedVideos, dislikedVideos, recordEngagement, emitEvent } = useUserStore();
  const videoRef = useRef<HTMLVideoElement>(null);
  const [isPlaying, setIsPlaying] = useState(false);
  const [isLoading, setIsLoading] = useState(true);
  const [hasError, setHasError] = useState(false);
  const [progress, setProgress] = useState(0);
  const [showHeart, setShowHeart] = useState(false);
  const [isShareModalOpen, setIsShareModalOpen] = useState(false);
  
  const isLiked = likedVideos.some((v: any) => v.id === video.id);
  const isDisliked = dislikedVideos.some((v: any) => v.id === video.id);

  useEffect(() => {
    if (isActive) {
      emitEvent({ type: 'watch_started', videoId: video.id });
      if (videoRef.current) {
        setHasError(false);
        videoRef.current.load();
        videoRef.current.play()
          .then(() => {
            setIsPlaying(true);
            setIsLoading(false);
          })
          .catch(() => {
            setIsPlaying(false);
            setIsLoading(false);
          });
      }
    } else {
      if (videoRef.current) {
        recordEngagement(video, videoRef.current.currentTime, false);
        videoRef.current.pause();
      }
      setIsPlaying(false);
      setProgress(0);
    }
  }, [isActive, video.id, recordEngagement, emitEvent]);

  const handleVideoClick = (e: React.MouseEvent) => {
    if (e.detail === 2) {
      if (!isLiked) toggleLike(video);
      setShowHeart(true);
      setTimeout(() => setShowHeart(false), 800);
    } else {
      if (videoRef.current?.paused) {
        videoRef.current.play();
        setIsPlaying(true);
      } else {
        videoRef.current?.pause();
        setIsPlaying(false);
      }
    }
  };

  return (
    <div 
      data-short-item data-id={video.id}
      className="h-full w-full snap-start flex items-center justify-center relative bg-black overflow-hidden"
    >
      <div className="absolute inset-0 z-0 opacity-40 blur-[120px] scale-150 pointer-events-none">
        <img src={video.thumbnail} className="w-full h-full object-cover" alt="" />
      </div>

      <div className="relative h-full w-full md:w-auto md:h-[94%] md:aspect-[9/16] bg-black shadow-2xl overflow-hidden md:rounded-3xl z-10 border-0 md:border border-white/5 group">
        <video
          ref={videoRef}
          src={shouldPreload || isActive ? video.videoUrl : ""}
          className="h-full w-full object-cover cursor-pointer"
          loop 
          playsInline 
          muted={isMuted}
          onTimeUpdate={() => setProgress((videoRef.current?.currentTime || 0) / (videoRef.current?.duration || 1) * 100)}
          onWaiting={() => setIsLoading(true)}
          onPlaying={() => {
            setIsLoading(false);
            setHasError(false);
          }}
          onEnded={() => emitEvent({ type: 'video_replay', videoId: video.id })}
          onClick={handleVideoClick}
          onCanPlay={() => {
            setIsLoading(false);
            setHasError(false);
          }}
          onError={() => {
            setIsLoading(false);
            setHasError(true);
          }}
        />

        <div className="absolute top-0 left-0 right-0 p-4 flex items-center justify-between z-50 pointer-events-none">
           <button onClick={() => navigate(-1)} className="p-2.5 bg-black/20 hover:bg-black/40 backdrop-blur-md rounded-full text-white pointer-events-auto transition-all active:scale-90">
             <ArrowLeft size={24} />
           </button>
           <div className="flex items-center gap-4 pointer-events-auto">
              <button onClick={onMuteToggle} className="p-2.5 bg-black/20 hover:bg-black/40 backdrop-blur-md rounded-full text-white transition-all active:scale-90">
                {isMuted ? <VolumeX size={24} /> : <Volume2 size={24} />}
              </button>
              <button className="p-2.5 bg-black/20 hover:bg-black/40 backdrop-blur-md rounded-full text-white transition-all active:scale-90">
                <MoreVertical size={24} />
              </button>
           </div>
        </div>

        <div className="absolute right-3 bottom-24 flex flex-col items-center gap-6 z-30">
          <ActionButton 
            icon={<Heart size={28} fill={isLiked ? "currentColor" : "none"} />}
            label={Intl.NumberFormat('en', { notation: 'compact' }).format((video.analytics?.likes || video.likes))}
            active={isLiked}
            type="video_liked"
            videoId={video.id}
            payload={{ isLiked: !isLiked }}
            onClick={() => toggleLike(video)}
            className="w-14 h-14"
          />
          <ActionButton 
            icon={<ThumbsDown size={28} fill={isDisliked ? "currentColor" : "none"} />}
            label="Dislike"
            active={isDisliked}
            type="video_disliked"
            videoId={video.id}
            payload={{ isDisliked: !isDisliked }}
            onClick={() => toggleDislike(video)}
            className="w-14 h-14"
          />
          <ActionButton 
            icon={<MessageSquare size={28} />}
            label={Intl.NumberFormat('en', { notation: 'compact' }).format((video.analytics?.commentsCount || 0))}
            type="content_shared" 
            videoId={video.id}
            className="w-14 h-14"
          />
          <ActionButton 
            icon={<Share2 size={28} />}
            label="Share"
            type="content_shared"
            videoId={video.id}
            onClick={() => setIsShareModalOpen(true)}
            className="w-14 h-14"
          />
          <Link to={`/channel/${video.channelId}`} className="mt-4 p-[3px] bg-gradient-to-tr from-[#f09433] to-[#bc1888] rounded-full active:scale-90 transition-transform shadow-2xl relative">
             <img src={video.channelAvatar} className="w-12 h-12 rounded-full border-2 border-black object-cover" alt="" />
             <div className="absolute -bottom-1 left-1/2 -translate-x-1/2 bg-red-600 text-white text-[10px] w-5 h-5 rounded-full flex items-center justify-center font-black border-2 border-black ring-1 ring-black shadow-lg">+</div>
          </Link>
        </div>

        <div className="absolute bottom-0 left-0 right-0 p-4 sm:p-6 pb-10 bg-gradient-to-t from-black/90 via-black/30 to-transparent pointer-events-none z-20">
          <div className="flex flex-col gap-3 pointer-events-auto max-w-[85%]">
            <div className="flex items-center gap-3">
              <Link to={`/channel/${video.channelId}`} className="flex items-center gap-2 min-w-0 group/channel overflow-hidden">
                <img src={video.channelAvatar} className="w-9 h-9 rounded-full border border-white/20 shrink-0" alt="" />
                <span className="font-black text-white text-[15px] sm:text-[16px] drop-shadow-md tracking-tight truncate">
                  @{video.channelName.replace(/\s+/g, '').toLowerCase()}
                </span>
              </Link>
              <div className="shrink-0">
                <SubscribeButton channelId={video.channelId} variant="minimal" dropdownPosition="top" />
              </div>
            </div>
            <p className="text-[14px] sm:text-[15px] font-bold text-white leading-relaxed drop-shadow-2xl line-clamp-2 pr-4">{video.title}</p>
          </div>
        </div>

        <div className="absolute inset-0 flex items-center justify-center pointer-events-none z-40">
           {isLoading && isActive && !hasError && (
             <div className="flex flex-col items-center gap-3">
               <Loader2 size={56} className="text-white animate-spin opacity-50" />
               <span className="text-[10px] font-black uppercase tracking-[0.4em] text-white/40 animate-pulse">Syncing Pulse</span>
             </div>
           )}
           {hasError && isActive && (
             <div className="flex flex-col items-center gap-3 bg-black/60 p-10 rounded-3xl backdrop-blur-md">
                <AlertCircle size={56} className="text-red-500" />
                <span className="text-xs font-black uppercase text-white/80">Source Unreachable</span>
             </div>
           )}
           {!isPlaying && isActive && !isLoading && !hasError && (
             <div className="bg-black/30 p-8 rounded-full backdrop-blur-md animate-in fade-in zoom-in duration-200">
               <Pause size={56} className="text-white opacity-80" />
             </div>
           )}
           {showHeart && <div className="animate-heart-pop text-red-500"><Heart size={140} fill="currentColor" /></div>}
        </div>

        <div className="absolute bottom-0 left-0 right-0 h-1.5 bg-white/10 z-30 cursor-pointer group/progress">
          <div 
            className="h-full bg-gradient-to-r from-red-700 via-red-500 to-pink-500 transition-all duration-100 ease-linear shadow-[0_0_20px_rgba(239,68,68,0.8)] relative" 
            style={{ width: `${progress}%` }} 
          />
        </div>
      </div>

      <ShareModal 
        isOpen={isShareModalOpen} 
        onClose={() => setIsShareModalOpen(false)} 
        videoId={video.id} 
        videoTitle={video.title} 
      />
    </div>
  );
};

export default ShortsPlayer;
