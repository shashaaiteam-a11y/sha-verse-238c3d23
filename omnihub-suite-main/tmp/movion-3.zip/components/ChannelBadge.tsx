
import React from 'react';
import { Link } from 'react-router-dom';
import { CheckCircle2 } from 'lucide-react';

interface ChannelBadgeProps {
  id: string;
  name: string;
  avatar: string;
  subscribers?: number;
  size?: 'sm' | 'md' | 'lg';
  showSubscribers?: boolean;
}

const ChannelBadge: React.FC<ChannelBadgeProps> = ({ id, name, avatar, subscribers, size = 'md', showSubscribers = false }) => {
  const avatarSizes = {
    sm: 'w-6 h-6',
    md: 'w-10 h-10',
    lg: 'w-14 h-14'
  };

  const textSizes = {
    sm: 'text-xs',
    md: 'text-sm',
    lg: 'text-base'
  };

  return (
    <div className="flex items-center gap-3">
      <Link to={`/channel/${id}`} className="shrink-0">
        <img src={avatar} className={`${avatarSizes[size]} rounded-full border border-gray-100 object-cover shadow-sm`} alt={name} />
      </Link>
      <div className="flex flex-col min-w-0">
        <Link to={`/channel/${id}`} className={`font-black text-[#030303] flex items-center gap-1 hover:text-blue-600 transition-colors ${textSizes[size]}`}>
          {name} <CheckCircle2 size={size === 'sm' ? 12 : 14} className="text-[#606060]" />
        </Link>
        {showSubscribers && subscribers !== undefined && (
          <span className="text-[11px] text-[#606060] font-bold">
            {Intl.NumberFormat('en', { notation: 'compact' }).format(subscribers)} subscribers
          </span>
        )}
      </div>
    </div>
  );
};

export default ChannelBadge;
