
import React from 'react';
import { 
  XAxis, YAxis, CartesianGrid, Tooltip, 
  ResponsiveContainer, AreaChart, Area 
} from 'recharts';

interface AnalyticsGraphProps {
  data: { day: string; views: number }[];
  color?: string;
  height?: number | string;
}

const AnalyticsGraph: React.FC<AnalyticsGraphProps> = ({ data, color = "#3ea6ff", height = "85%" }) => {
  return (
    <div className="w-full h-full min-h-[300px]">
      <ResponsiveContainer width="100%" height="100%" minWidth={0}>
        <AreaChart data={data} margin={{ top: 10, right: 30, left: 0, bottom: 0 }}>
          <defs>
            <linearGradient id="colorValue" x1="0" y1="0" x2="0" y2="1">
              <stop offset="5%" stopColor={color} stopOpacity={0.3}/>
              <stop offset="95%" stopColor={color} stopOpacity={0}/>
            </linearGradient>
          </defs>
          <CartesianGrid strokeDasharray="3 3" stroke="#ffffff05" vertical={false} />
          <XAxis 
            dataKey="day" 
            axisLine={false} 
            tickLine={false} 
            tick={{fill: '#555', fontSize: 10, fontWeight: 900}} 
          />
          <YAxis 
            axisLine={false} 
            tickLine={false} 
            tick={{fill: '#555', fontSize: 10, fontWeight: 900}} 
          />
          <Tooltip 
            contentStyle={{
              backgroundColor: '#282828', 
              borderRadius: '16px', 
              border: '1px solid #ffffff10', 
              color: '#fff',
              fontSize: '12px',
              fontWeight: 'bold'
            }} 
            itemStyle={{ color: '#fff' }}
          />
          <Area 
            type="monotone" 
            dataKey="views" 
            stroke={color} 
            strokeWidth={4} 
            fillOpacity={1} 
            fill="url(#colorValue)" 
          />
        </AreaChart>
      </ResponsiveContainer>
    </div>
  );
};

export default AnalyticsGraph;
