
import React, { useEffect } from 'react';
import { ToastMessage } from '../types';
import { X, CheckCircle, Info, AlertCircle } from 'lucide-react';
import { useUserStore } from '../store';

const Toast: React.FC<{ toast: ToastMessage }> = ({ toast }) => {
  const { removeToast } = useUserStore();

  const icons = {
    success: <CheckCircle size={18} className="text-black" />,
    info: <Info size={18} className="text-black" />,
    error: <AlertCircle size={18} className="text-black" />
  };

  return (
    <div className="flex items-center gap-3 bg-white text-black px-4 py-3 rounded-lg shadow-2xl animate-in slide-in-from-bottom-5 fade-in duration-300 min-w-[280px] max-w-sm pointer-events-auto">
      {icons[toast.type]}
      <span className="text-sm font-medium flex-1">{toast.message}</span>
      <button onClick={() => removeToast(toast.id)} className="text-black/50 hover:text-black">
        <X size={16} />
      </button>
    </div>
  );
};

export const ToastContainer: React.FC = () => {
  const { toasts } = useUserStore();

  if (toasts.length === 0) return null;

  return (
    <div className="fixed bottom-6 left-6 z-[9999] flex flex-col gap-3 pointer-events-none">
      {toasts.map((toast: ToastMessage) => (
        <Toast key={toast.id} toast={toast} />
      ))}
    </div>
  );
};

export default ToastContainer;
