import React, { useEffect, useRef, useState } from 'react';
import { 
  X, PlayCircle, ListVideo, Clock, ListPlus, 
  Share2, MinusCircle, Flag, Edit3, Trash2, BarChart2,
  ChevronLeft, AlertCircle, ShieldAlert, HeartOff, Info
} from 'lucide-react';
import { Video } from '../types';

interface OptionItem {
  label: string;
  icon: React.ReactNode;
  onClick: () => void;
  variant?: 'default' | 'danger';
}

// Fixed: Moved OptionRow outside to avoid TypeScript errors with 'key' prop 
// which occur when defining a component function within another component's body.
const OptionRow: React.FC<{ item: OptionItem }> = ({ item }) => (
  <button 
    onClick={(e) => { e.stopPropagation(); item.onClick(); }} 
    className={`
      w-full flex items-center gap-4 lg:gap-3 px-6 lg:px-4 py-4 lg:py-2.5 hover:bg-white/5 lg:hover:bg-[#3e3e3e] text-[15px] lg:text-[14px] font-bold lg:font-medium transition-colors
      ${item.variant === 'danger' ? 'text-red-500' : 'text-white'}
    `}
  >
    <span className={`${item.variant === 'danger' ? 'text-red-500' : 'text-[#aaa]'}`}>{item.icon}</span>
    <span>{item.label}</span>
  </button>
);

interface VideoOptionsBottomSheetProps {
  video: Video;
  isOpen: boolean;
  onClose: () => void;
  isOwner: boolean;
  onAction: (action: string) => void;
  isSavedInWatchLater: boolean;
}

const VideoOptionsBottomSheet: React.FC<VideoOptionsBottomSheetProps> = ({
  video,
  isOpen,
  onClose,
  isOwner,
  onAction,
  isSavedInWatchLater
}) => {
  const [currentView, setCurrentView] = useState<'main' | 'report'>('main');
  const desktopMenuRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (!isOpen) setCurrentView('main');
  }, [isOpen]);

  useEffect(() => {
    const handleOutsideClick = (e: MouseEvent) => {
      if (desktopMenuRef.current && !desktopMenuRef.current.contains(e.target as Node)) {
        onClose();
      }
    };
    if (isOpen) {
      document.addEventListener('mousedown', handleOutsideClick);
      if (window.innerWidth < 1024) document.body.style.overflow = 'hidden';
    }
    return () => {
      document.removeEventListener('mousedown', handleOutsideClick);
      document.body.style.overflow = 'auto';
    };
  }, [isOpen, onClose]);

  if (!isOpen) return null;

  const creatorOptions: OptionItem[] = [
    { label: 'Edit video', icon: <Edit3 size={20} />, onClick: () => onAction('edit') },
    { label: 'Delete video', icon: <Trash2 size={20} />, onClick: () => onAction('delete'), variant: 'danger' },
    { label: 'Analytics', icon: <BarChart2 size={20} />, onClick: () => onAction('analytics') },
  ];

  const viewerOptions: OptionItem[] = [
    { label: 'Play next', icon: <PlayCircle size={20} />, onClick: () => onAction('play_next') },
    { label: 'Add to queue', icon: <ListVideo size={20} />, onClick: () => onAction('add_to_queue') },
    { 
      label: isSavedInWatchLater ? 'Remove from Watch later' : 'Save to Watch later', 
      icon: <Clock size={20} />, 
      onClick: () => onAction('watch_later') 
    },
    { label: 'Save to playlist', icon: <ListPlus size={20} />, onClick: () => onAction('playlist') },
    { label: 'Share', icon: <Share2 size={20} />, onClick: () => onAction('share') },
    { label: 'Not interested', icon: <MinusCircle size={20} />, onClick: () => onAction('not_interested') },
    { label: 'Report', icon: <Flag size={20} />, onClick: () => setCurrentView('report') },
  ];

  const reportReasons = [
    { label: 'Sexual content', icon: <HeartOff size={20} /> },
    { label: 'Violent or repulsive content', icon: <ShieldAlert size={20} /> },
    { label: 'Hateful or abusive content', icon: <AlertCircle size={20} /> },
    { label: 'Spam or misleading', icon: <ListVideo size={20} /> },
  ];

  const allOptions = isOwner ? [...creatorOptions, ...viewerOptions] : viewerOptions;

  return (
    <div className="z-[2000] relative">
      {/* Desktop View */}
      <div 
        ref={desktopMenuRef}
        className="hidden lg:block absolute right-0 top-full mt-1 w-64 bg-[#282828] border border-[#3e3e3e] rounded-xl shadow-2xl py-2 animate-in fade-in zoom-in duration-100 origin-top-right"
      >
        {currentView === 'main' ? (
          allOptions.map((item, idx) => <OptionRow key={idx} item={item} />)
        ) : (
          <div className="flex flex-col">
            <button onClick={() => setCurrentView('main')} className="flex items-center gap-3 px-4 py-2 border-b border-white/5 text-xs font-black text-[#aaa]"><ChevronLeft size={16}/> Back</button>
            {reportReasons.map((r, idx) => <OptionRow key={idx} item={{...r, onClick: () => alert('Reported')}} />)}
          </div>
        )}
      </div>

      {/* Mobile View */}
      <div className="lg:hidden fixed inset-0 flex items-end justify-center pointer-events-auto">
        <div className="absolute inset-0 bg-black/60 backdrop-blur-sm animate-in fade-in duration-300" onClick={onClose} />
        <div className="relative w-full bg-[#1e1e1e] rounded-t-3xl border-t border-white/10 animate-in slide-in-from-bottom duration-300 overflow-hidden flex flex-col max-h-[85vh]">
          <div className="flex items-center justify-between p-5 border-b border-white/5">
            <h4 className="text-xs font-black uppercase tracking-widest text-[#aaa] ml-2">
              {currentView === 'main' ? 'Video Options' : 'Report Video'}
            </h4>
            <button onClick={onClose} className="p-2 hover:bg-white/5 rounded-full"><X size={22}/></button>
          </div>
          <div className="overflow-y-auto no-scrollbar py-2 pb-12">
            {currentView === 'main' ? (
              allOptions.map((item, idx) => <OptionRow key={idx} item={item} />)
            ) : (
              <>
                <button onClick={() => setCurrentView('main')} className="w-full flex items-center gap-5 px-6 py-4 text-blue-400 font-black text-sm uppercase tracking-widest"><ChevronLeft size={20}/> Main Menu</button>
                {reportReasons.map((r, idx) => <OptionRow key={idx} item={{...r, onClick: () => { alert('Video Reported'); onClose(); }}} />)}
              </>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default VideoOptionsBottomSheet;