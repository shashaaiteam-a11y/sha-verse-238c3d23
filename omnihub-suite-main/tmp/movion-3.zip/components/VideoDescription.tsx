
import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { TrendingUp } from 'lucide-react';

interface VideoDescriptionProps {
  description: string;
  views: number;
  uploadDate: string;
  onSeek: (seconds: number) => void;
  tags?: string[];
  isHighRetention?: boolean;
}

const VideoDescription: React.FC<VideoDescriptionProps> = ({ 
  description, 
  views, 
  uploadDate, 
  onSeek,
  tags,
  isHighRetention 
}) => {
  const [isExpanded, setIsExpanded] = useState(false);

  // Helper to convert "MM:SS" or "H:MM:SS" to seconds
  const parseTimestampToSeconds = (ts: string) => {
    const parts = ts.split(':').map(Number);
    if (parts.length === 3) return parts[0] * 3600 + parts[1] * 60 + parts[2];
    if (parts.length === 2) return parts[0] * 60 + parts[1];
    return 0;
  };

  const renderContent = (text: string) => {
    // Regex matches: Timestamps, URLs, Hashtags
    const regex = /(\d{1,2}:\d{2}(?::\d{2})?)|(https?:\/\/[^\s]+)|(#[a-zA-Z0-9_]+)/g;
    
    const parts = text.split(regex);
    
    return parts.map((part, i) => {
      if (!part) return null;

      // 1. Timestamp match
      if (/^\d{1,2}:\d{2}(?::\d{2})?$/.test(part)) {
        return (
          <button 
            key={i} 
            onClick={(e) => {
              e.stopPropagation();
              onSeek(parseTimestampToSeconds(part));
            }}
            className="text-blue-600 font-bold hover:underline cursor-pointer inline-block mx-0.5"
          >
            {part}
          </button>
        );
      }
      
      // 2. URL match
      if (/^https?:\/\/[^\s]+$/.test(part)) {
        return (
          <a 
            key={i} 
            href={part} 
            target="_blank" 
            rel="noopener noreferrer" 
            onClick={(e) => e.stopPropagation()}
            className="text-blue-600 hover:underline break-all"
          >
            {part}
          </a>
        );
      }

      // 3. Hashtag match
      if (/^#[a-zA-Z0-9_]+$/.test(part)) {
        return (
          <Link 
            key={i} 
            to={`/results?search_query=${encodeURIComponent(part)}`}
            onClick={(e) => e.stopPropagation()}
            className="text-blue-600 hover:underline"
          >
            {part}
          </Link>
        );
      }

      // 4. Plain Text
      return <span key={i}>{part}</span>;
    });
  };

  return (
    <div 
      className={`bg-[#f2f2f2] rounded-2xl p-4 border border-[#e5e5e5] hover:bg-[#ebebeb] hover:border-[#d9d9d9] transition-all cursor-pointer group relative overflow-hidden ${isExpanded ? '' : 'max-h-[140px]'}`}
      onClick={() => setIsExpanded(!isExpanded)}
    >
      <div className="flex flex-wrap items-center gap-x-4 gap-y-1 text-sm font-bold text-[#030303] mb-3">
        <span>{Intl.NumberFormat('en').format(views)} views</span>
        <span>{uploadDate}</span>
        {tags && tags.slice(0, 3).map(tag => (
          <span key={tag} className="text-[#606060] text-xs">#{tag.replace(/\s+/g, '')}</span>
        ))}
        {isHighRetention && (
          <span className="bg-green-600/10 text-green-700 px-2 py-0.5 rounded flex items-center gap-1 text-xs">
            <TrendingUp size={12}/> High Retention
          </span>
        )}
      </div>

      <div className="text-[14px] text-[#030303] leading-relaxed whitespace-pre-wrap font-medium">
        {renderContent(description)}
      </div>

      {!isExpanded && (
        <button 
          className="font-bold text-sm text-[#030303] mt-2 group-hover:underline bg-gradient-to-r from-transparent via-[#f2f2f2] to-[#f2f2f2] absolute bottom-4 right-4 pl-8"
        >
          ...more
        </button>
      )}
      
      {isExpanded && (
        <button 
          className="font-bold text-sm text-[#030303] mt-6 hover:underline block"
          onClick={(e) => {
            e.stopPropagation();
            setIsExpanded(false);
          }}
        >
          Show less
        </button>
      )}
    </div>
  );
};

export default VideoDescription;
