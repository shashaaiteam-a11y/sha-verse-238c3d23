
import React, { useState } from 'react';
import { X, Plus, Lock, Globe } from 'lucide-react';

interface PlaylistSelectorModalProps {
  isOpen: boolean;
  onClose: () => void;
}

const PlaylistSelectorModal: React.FC<PlaylistSelectorModalProps> = ({ isOpen, onClose }) => {
  const [selectedPlaylists, setSelectedPlaylists] = useState<string[]>(['p3']);

  if (!isOpen) return null;

  const mockPlaylists = [
    { id: 'p1', name: 'My Favorites', visibility: 'private' },
    { id: 'p2', name: 'Tech Reviews', visibility: 'public' },
    { id: 'p3', name: 'Watch Later', visibility: 'private' },
  ];

  const togglePlaylist = (id: string) => {
    setSelectedPlaylists(prev => 
      prev.includes(id) ? prev.filter(x => x !== id) : [...prev, id]
    );
  };

  return (
    <div className="fixed inset-0 z-[3000] flex items-center justify-center p-4">
      <div className="absolute inset-0 bg-black/80 backdrop-blur-md animate-in fade-in duration-300" onClick={onClose} />
      <div className="relative w-full max-w-sm bg-[#1e1e1e] rounded-3xl shadow-2xl border border-white/10 overflow-hidden animate-in zoom-in duration-200">
        <div className="flex items-center justify-between px-6 py-5 border-b border-white/5">
          <h3 className="font-black uppercase tracking-widest text-sm text-[#aaa]">Save to playlist</h3>
          <button onClick={onClose} className="p-1 hover:bg-white/10 rounded-full transition-colors"><X size={20}/></button>
        </div>
        
        <div className="max-h-80 overflow-y-auto py-2">
          {mockPlaylists.map(playlist => (
            <div 
              key={playlist.id} 
              onClick={() => togglePlaylist(playlist.id)}
              className="flex items-center px-6 py-4 hover:bg-white/5 cursor-pointer group"
            >
              <div className={`w-5 h-5 rounded border-2 mr-4 flex items-center justify-center transition-colors ${selectedPlaylists.includes(playlist.id) ? 'bg-blue-500 border-blue-500' : 'border-white/20'}`}>
                {selectedPlaylists.includes(playlist.id) && <div className="w-2 h-2 bg-white rounded-full" />}
              </div>
              <div className="flex-1 min-w-0">
                <p className="text-[15px] font-bold truncate text-white">{playlist.name}</p>
              </div>
              {playlist.visibility === 'private' ? <Lock size={14} className="text-[#555]" /> : <Globe size={14} className="text-[#555]" />}
            </div>
          ))}
        </div>

        <div className="px-6 py-5 border-t border-white/5">
          <button className="w-full flex items-center gap-3 text-sm font-black uppercase tracking-widest text-white hover:text-blue-400 transition-colors">
            <Plus size={20} />
            Create new playlist
          </button>
        </div>
      </div>
    </div>
  );
};

export default PlaylistSelectorModal;
