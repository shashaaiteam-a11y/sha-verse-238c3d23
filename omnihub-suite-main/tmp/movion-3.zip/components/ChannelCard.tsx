
import React from 'react';
import { Channel } from '../types';
import { Link } from 'react-router-dom';
import SubscribeButton from './SubscribeButton';
import { CheckCircle2 } from 'lucide-react';

interface ChannelCardProps {
  channel: Channel;
}

const ChannelCard: React.FC<ChannelCardProps> = ({ channel }) => {
  return (
    <div className="flex flex-col sm:flex-row items-center gap-6 py-6 px-4 hover:bg-white/5 rounded-2xl transition-all border-b border-white/5 sm:border-none">
      <Link to={`/channel/${channel.id}`} className="shrink-0">
        <img 
          src={channel.avatar} 
          className="w-24 h-24 sm:w-32 sm:h-32 rounded-full object-cover shadow-2xl ring-2 ring-white/10 group-hover:ring-white/20 transition-all" 
          alt={channel.name} 
        />
      </Link>
      
      <div className="flex-1 text-center sm:text-left min-w-0">
        <Link to={`/channel/${channel.id}`} className="inline-flex items-center gap-2 group">
          <h3 className="text-lg sm:text-xl font-black text-white group-hover:text-blue-400 transition-colors truncate">
            {channel.name}
          </h3>
          <CheckCircle2 size={16} className="text-[#aaa]" />
        </Link>
        <p className="text-sm text-[#aaa] font-bold mt-0.5">
          {channel.handle} • {Intl.NumberFormat('en', { notation: 'compact' }).format(channel.subscribers)} subscribers
        </p>
        <p className="text-sm text-[#aaa] mt-3 line-clamp-2 max-w-2xl hidden sm:block">
          {channel.description}
        </p>
      </div>

      <div className="shrink-0 pt-2 sm:pt-0">
        <SubscribeButton channelId={channel.id} />
      </div>
    </div>
  );
};

export default ChannelCard;
