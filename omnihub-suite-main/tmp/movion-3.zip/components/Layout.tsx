
import React, { useState, useEffect, useRef } from 'react';
import { 
  Menu, Search, Bell, Home, PlayCircle, Clapperboard, 
  Library as LibraryIcon, LayoutDashboard, Upload, 
  Plus, Zap, X, User, ChevronRight, BellRing, Settings,
  MessageSquare, Radio, ShieldAlert, CheckCheck, Users
} from 'lucide-react';
import { Link, useNavigate, useLocation } from 'react-router-dom';
import { useUserStore } from '../store';
import Logo from './Logo';
import { ToastContainer } from './Toast';
import { Notification } from '../types';

interface LayoutProps {
  children: React.ReactNode;
}

const Layout: React.FC<LayoutProps> = ({ children }) => {
  const [isSidebarOpen, setIsSidebarOpen] = useState(true);
  const [isProfileMenuOpen, setIsProfileMenuOpen] = useState(false);
  const [isNotificationsOpen, setIsNotificationsOpen] = useState(false);
  
  const { 
    searchQuery, setSearchQuery, addToSearchHistory, 
    userChannel, notifications, unreadCount, markAsRead, markAllAsRead
  } = useUserStore();
  
  const [localSearch, setLocalSearch] = useState(searchQuery);
  const location = useLocation();
  const navigate = useNavigate();
  const profileMenuRef = useRef<HTMLDivElement>(null);
  const notifMenuRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    setLocalSearch(searchQuery);
  }, [searchQuery]);

  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (profileMenuRef.current && !profileMenuRef.current.contains(event.target as Node)) {
        setIsProfileMenuOpen(false);
      }
      if (notifMenuRef.current && !notifMenuRef.current.contains(event.target as Node)) {
        setIsNotificationsOpen(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  useEffect(() => {
    const handleResize = () => {
      if (window.innerWidth < 1024) setIsSidebarOpen(false);
      else setIsSidebarOpen(true);
    };
    handleResize();
    window.addEventListener('resize', handleResize);
    return () => window.removeEventListener('resize', handleResize);
  }, []);

  useEffect(() => {
    if (window.innerWidth < 1024) setIsSidebarOpen(false);
    setIsProfileMenuOpen(false);
    setIsNotificationsOpen(false);
  }, [location.pathname]);

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    if (localSearch.trim()) {
      addToSearchHistory(localSearch);
      setSearchQuery(localSearch);
      navigate(`/results?search_query=${encodeURIComponent(localSearch)}`);
    }
  };

  const navItems = [
    { name: 'Home', icon: <Home size={22} />, path: '/' },
    { name: 'Pulse', icon: <Zap size={22} />, path: '/shorts' },
    { name: 'Subscriptions', icon: <Clapperboard size={22} />, path: '/subscriptions' },
    { name: 'Library', icon: <LibraryIcon size={22} />, path: '/library' },
  ];

  const isActiveLink = (path: string) => {
    if (path === '/') return location.pathname === '/';
    return location.pathname.startsWith(path);
  };

  const getNotificationIcon = (type: string) => {
    switch (type) {
      case 'live': return <Radio size={14} className="text-white" />;
      case 'comment': return <MessageSquare size={14} className="text-white" />;
      case 'alert': return <ShieldAlert size={14} className="text-white" />;
      case 'community': return <Users size={14} className="text-white" />;
      default: return <PlayCircle size={14} className="text-white" />;
    }
  };

  const getNotificationColor = (type: string) => {
    switch (type) {
      case 'live': return 'bg-red-600';
      case 'comment': return 'bg-blue-500';
      case 'alert': return 'bg-yellow-500';
      case 'community': return 'bg-green-500';
      default: return 'bg-purple-500'; // Upload
    }
  };

  return (
    <div className="flex flex-col h-screen bg-white overflow-hidden text-[#030303]">
      <header className="flex items-center justify-between px-4 h-16 sticky top-0 bg-white z-[60] border-b border-[#e5e5e5]">
        <div className="flex items-center gap-4">
          <button onClick={() => setIsSidebarOpen(!isSidebarOpen)} className="p-2 hover:bg-[#f2f2f2] rounded-full transition-all active:scale-90">
            <Menu size={24} className="text-[#030303]" />
          </button>
          <Link to="/" className="flex items-center gap-2 group" onClick={() => setSearchQuery('')}>
            <Logo size={32} />
            <span className="text-xl font-black tracking-tighter uppercase text-[#030303] hidden sm:block">MOVION</span>
          </Link>
        </div>

        <form onSubmit={handleSearch} className="hidden md:flex flex-1 max-w-[720px] items-center gap-2 px-8">
          <div className="flex flex-1 items-center bg-white border border-[#cccccc] rounded-full overflow-hidden focus-within:border-[#065fd4] focus-within:ring-0.5 focus-within:ring-[#065fd4] transition-all h-10">
            <input 
              type="text" 
              value={localSearch}
              onChange={(e) => setLocalSearch(e.target.value)}
              placeholder="Search MOVION" 
              className="w-full bg-transparent px-5 py-2 outline-none text-[#030303] text-[15px]"
            />
            <button type="submit" className="bg-[#f8f8f8] px-6 h-full border-l border-[#cccccc] hover:bg-[#f0f0f0] transition-colors flex items-center justify-center">
              <Search size={20} className="text-[#606060]" />
            </button>
          </div>
        </form>

        <div className="flex items-center gap-1 md:gap-4 relative">
          <button onClick={() => navigate('/search')} className="p-2 hover:bg-[#f2f2f2] rounded-full md:hidden"><Search size={22} className="text-[#030303]" /></button>
          <button onClick={() => navigate('/upload')} className="hidden sm:flex items-center gap-2 px-4 h-10 hover:bg-[#f2f2f2] rounded-full transition-all border border-[#e5e5e5]">
            <Upload size={20} className="text-[#030303]" />
            <span className="font-bold text-sm text-[#030303]">Create</span>
          </button>
          
          <div ref={notifMenuRef} className="relative">
            <button 
              onClick={() => setIsNotificationsOpen(!isNotificationsOpen)} 
              className="p-2 hover:bg-[#f2f2f2] rounded-full relative active:scale-95 transition-transform"
            >
              <Bell size={20} className="text-[#030303]" />
              {unreadCount > 0 && (
                <span className="absolute top-1 right-1 w-4 h-4 bg-red-600 rounded-full border border-white text-[9px] font-bold text-white flex items-center justify-center">
                  {unreadCount > 9 ? '9+' : unreadCount}
                </span>
              )}
            </button>
            
            {isNotificationsOpen && (
              <div className="absolute right-0 top-full mt-2 w-[320px] sm:w-[400px] bg-white border border-[#e5e5e5] rounded-2xl shadow-2xl z-[100] py-2 overflow-hidden animate-in fade-in slide-in-from-top-2 duration-200">
                <div className="px-4 py-3 border-b border-[#f2f2f2] flex justify-between items-center">
                   <span className="text-sm font-black uppercase tracking-widest text-[#030303]">Notifications</span>
                   <div className="flex gap-1">
                     <button onClick={() => markAllAsRead()} className="text-[#606060] text-xs font-bold p-1 hover:bg-[#f2f2f2] rounded flex items-center gap-1" title="Mark all as read">
                        <CheckCheck size={16} />
                     </button>
                     <button className="text-[#606060] text-xs font-bold p-1 hover:bg-[#f2f2f2] rounded"><Settings size={16}/></button>
                   </div>
                </div>
                <div className="max-h-[480px] overflow-y-auto">
                   {notifications.length > 0 ? (
                     notifications.map((notif: Notification) => (
                       <div 
                        key={notif.id} 
                        onClick={() => {
                          markAsRead(notif.id);
                          if (notif.videoId) navigate(`/watch/${notif.videoId}`);
                          else setIsNotificationsOpen(false); // Alert type close
                        }}
                        className={`px-4 py-3 hover:bg-[#f8f8f8] flex gap-3 cursor-pointer transition-colors group relative ${!notif.read ? 'bg-blue-50/50' : ''}`}
                       >
                          <div className="shrink-0 relative">
                            <img src={notif.channelAvatar} className="w-10 h-10 rounded-full object-cover" alt="" />
                            <div className={`absolute -bottom-1 -right-1 w-5 h-5 rounded-full border-2 border-white flex items-center justify-center ${getNotificationColor(notif.type)}`}>
                              {getNotificationIcon(notif.type)}
                            </div>
                          </div>
                          <div className="flex-1 min-w-0">
                             <p className="text-sm text-[#030303] leading-snug line-clamp-3">
                                <span className="font-bold">{notif.channelName}</span> {notif.text}
                             </p>
                             <p className="text-[10px] text-[#606060] mt-1 font-bold">{notif.time}</p>
                          </div>
                          {notif.thumbnail && (
                            <div className="w-20 h-12 bg-gray-200 rounded-lg shrink-0 overflow-hidden relative border border-gray-100">
                               <img src={notif.thumbnail} className="w-full h-full object-cover" alt="" />
                            </div>
                          )}
                          {!notif.read && <div className="absolute right-2 top-1/2 -translate-y-1/2 w-2 h-2 bg-blue-600 rounded-full"></div>}
                       </div>
                     ))
                   ) : (
                     <div className="py-10 text-center text-[#aaa]">
                       <Bell size={32} className="mx-auto mb-2 opacity-50" />
                       <p className="text-xs font-bold">No new notifications</p>
                     </div>
                   )}
                </div>
              </div>
            )}
          </div>

          <div ref={profileMenuRef} className="relative ml-1">
            <button onClick={() => setIsProfileMenuOpen(!isProfileMenuOpen)} className="w-10 h-10 rounded-full overflow-hidden border border-[#e5e5e5] hover:ring-2 hover:ring-gray-200 transition-all shadow-sm">
              <img src={userChannel.avatar} alt="Avatar" className="w-full h-full object-cover" />
            </button>

            {isProfileMenuOpen && (
              <div className="absolute right-0 top-full mt-2 w-[300px] bg-white border border-[#e5e5e5] rounded-2xl shadow-2xl z-[100] py-2 overflow-hidden animate-in fade-in slide-in-from-top-2 duration-200">
                <div className="flex items-start gap-4 px-4 py-4 border-b border-[#f2f2f2]">
                  <img src={userChannel.avatar} className="w-12 h-12 rounded-full object-cover shrink-0 ring-1 ring-gray-100" alt="" />
                  <div className="flex flex-col min-w-0">
                    <span className="font-bold text-[16px] text-[#030303] truncate">{userChannel.name}</span>
                    <span className="text-xs text-[#606060] truncate">{userChannel.handle}</span>
                    <Link to={`/channel/${userChannel.id}`} onClick={() => setIsProfileMenuOpen(false)} className="text-blue-600 text-[11px] font-bold mt-1 uppercase tracking-wider">
                      View Channel
                    </Link>
                  </div>
                </div>
                <div className="py-2">
                  <Link 
                    to={`/channel/${userChannel.id}`} 
                    onClick={() => setIsProfileMenuOpen(false)}
                    className="flex items-center justify-between px-4 py-3 hover:bg-[#f2f2f2] transition-colors group"
                  >
                    <div className="flex items-center gap-4">
                      <User size={20} className="text-[#030303]" />
                      <span className="text-[14px] font-medium text-[#030303]">Your channel</span>
                    </div>
                  </Link>
                  <Link 
                    to="/studio" 
                    onClick={() => setIsProfileMenuOpen(false)}
                    className="flex items-center justify-between px-4 py-3 hover:bg-[#f2f2f2] transition-colors group"
                  >
                    <div className="flex items-center gap-4">
                      <LayoutDashboard size={20} className="text-[#030303]" />
                      <span className="text-[14px] font-medium text-[#030303]">Studio</span>
                    </div>
                    <ChevronRight size={16} className="text-[#ccc] group-hover:text-[#030303]" />
                  </Link>
                </div>
              </div>
            )}
          </div>
        </div>
      </header>

      <div className="flex flex-1 overflow-hidden relative">
        {isSidebarOpen && (
          <div className="fixed inset-0 bg-black/20 z-[65] lg:hidden animate-in fade-in duration-300" onClick={() => setIsSidebarOpen(false)} />
        )}

        <aside className={`fixed inset-y-0 left-0 z-[70] bg-white transition-all duration-300 lg:relative lg:translate-x-0 lg:z-auto ${isSidebarOpen ? 'translate-x-0 w-64 px-3' : '-translate-x-full lg:translate-x-0 lg:w-20 lg:px-1'}`}>
          <div className="flex items-center gap-4 px-4 h-16 lg:hidden border-b border-[#f2f2f2] mb-2">
             <button onClick={() => setIsSidebarOpen(false)} className="p-2 hover:bg-[#f2f2f2] rounded-full text-[#030303]"><X size={24} /></button>
             <Link to="/" className="flex items-center gap-2">
                <Logo size={28} />
                <span className="text-base font-black tracking-tighter uppercase text-[#030303]">MOVION</span>
             </Link>
          </div>
          <div className="flex flex-col gap-1 py-2 h-full overflow-y-auto no-scrollbar bg-white">
            {navItems.map((item) => (
              <Link 
                key={item.path} 
                to={item.path} 
                className={`flex items-center gap-5 p-3 rounded-xl transition-all ${isActiveLink(item.path) ? 'bg-[#f2f2f2] text-[#030303] font-bold' : 'hover:bg-[#f2f2f2] text-[#030303]'} ${(!isSidebarOpen && window.innerWidth >= 1024) ? 'flex-col gap-1 px-1 py-4' : ''}`}
              >
                <div className={isActiveLink(item.path) ? (item.name === 'Pulse' ? 'text-pink-600' : 'text-blue-600') : 'text-[#030303]'}>{item.icon}</div>
                <span className={`text-[13px] ${(!isSidebarOpen && window.innerWidth >= 1024) ? 'text-[10px]' : ''}`}>{item.name}</span>
              </Link>
            ))}
          </div>
        </aside>

        <main className="flex-1 overflow-y-auto bg-white pb-20 lg:pb-0">
          {children}
        </main>
        
        {/* Toast Container Injection */}
        <ToastContainer />

        <nav className="fixed bottom-0 left-0 right-0 h-16 bg-white/95 backdrop-blur-xl border-t border-[#f2f2f2] flex items-center justify-around z-50 lg:hidden px-2 shadow-2xl">
          {navItems.map((item) => {
            const active = isActiveLink(item.path);
            return (
              <Link key={item.path} to={item.path} className={`flex flex-col items-center justify-center gap-1 transition-all flex-1 h-full relative group`}>
                {active && <div className="absolute top-0 left-1/2 -translate-x-1/2 w-8 h-0.5 bg-gradient-to-r from-red-500 to-pink-500 rounded-full" />}
                <div className={`transition-transform duration-300 ${active ? 'scale-110 -translate-y-0.5' : 'text-[#606060]'}`}>
                  {React.cloneElement(item.icon as React.ReactElement<any>, { size: 22, className: active ? (item.name === 'Pulse' ? 'text-pink-600 fill-pink-600/5' : 'text-[#030303] fill-[#030303]/5') : 'text-[#606060]' })}
                </div>
                <span className={`text-[9px] font-black uppercase tracking-widest transition-all ${active ? 'text-[#030303]' : 'text-[#606060]'}`}>{item.name}</span>
              </Link>
            );
          })}
          <button onClick={() => navigate('/upload')} className="flex-1 flex flex-col items-center justify-center gap-1 h-full group active:scale-95 transition-all">
            <div className="p-1.5 bg-[#f2f2f2] rounded-xl border border-[#e5e5e5]"><Plus size={22} className="text-[#030303]" /></div>
            <span className="text-[9px] font-black uppercase tracking-widest text-[#606060]">Create</span>
          </button>
        </nav>
      </div>
    </div>
  );
};

export default Layout;
