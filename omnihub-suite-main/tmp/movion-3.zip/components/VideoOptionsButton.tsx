
import React from 'react';
import { MoreVertical } from 'lucide-react';

interface VideoOptionsButtonProps {
  onClick: (e: React.MouseEvent) => void;
  isActive?: boolean;
  className?: string;
  size?: number;
}

const VideoOptionsButton: React.FC<VideoOptionsButtonProps> = ({ 
  onClick, 
  isActive = false, 
  className = "",
  size = 20 
}) => {
  return (
    <button 
      onClick={onClick}
      className={`
        p-2 hover:bg-white/10 rounded-full text-white transition-all active:scale-90
        ${isActive ? 'bg-white/10 opacity-100' : 'opacity-0 group-hover:opacity-100 lg:opacity-0'}
        ${className}
      `}
      aria-label="Action Menu"
    >
      <MoreVertical size={size} />
    </button>
  );
};

export default VideoOptionsButton;
