
import React, { useRef } from 'react';
import { Video } from '../types';
import ShortVideoCard from './ShortVideoCard';
import { ChevronLeft, ChevronRight, Zap } from 'lucide-react';

interface ShortVideoHorizontalListProps {
  videos: Video[];
  title?: string;
  subtitle?: string;
}

const ShortVideoHorizontalList: React.FC<ShortVideoHorizontalListProps> = ({ 
  videos, 
  title = "Pulse Stories", 
  subtitle = "Creators you might like" 
}) => {
  const scrollRef = useRef<HTMLDivElement>(null);

  const scroll = (direction: 'left' | 'right') => {
    if (scrollRef.current) {
      const scrollAmount = 400;
      scrollRef.current.scrollBy({ 
        left: direction === 'left' ? -scrollAmount : scrollAmount, 
        behavior: 'smooth' 
      });
    }
  };

  if (!videos || videos.length === 0) return null;

  return (
    <section className="bg-gradient-to-b from-white/[0.02] to-transparent pt-6 pb-6 group/shorts relative overflow-hidden border-b border-white/5">
      {/* Subtle Ambient Background */}
      <div className="absolute -top-24 -left-24 w-64 h-64 bg-red-600/5 rounded-full blur-[100px] pointer-events-none" />
      
      <div className="max-w-[1800px] mx-auto px-4 sm:px-6 relative z-10">
        <div className="flex items-center justify-between mb-5">
          <div className="flex items-center gap-3">
            <div className="bg-red-600 p-2 rounded-xl shadow-lg shadow-red-600/20">
              <Zap className="text-white fill-white" size={14} />
            </div>
            <div>
              <h2 className="text-[12px] font-black italic tracking-[0.15em] uppercase text-white leading-none">{title}</h2>
              <p className="text-[9px] font-black text-[#555] uppercase tracking-widest mt-1 leading-none">{subtitle}</p>
            </div>
          </div>
          <div className="flex items-center gap-1.5">
            <button 
              onClick={() => scroll('left')} 
              className="p-1.5 hover:bg-white/10 rounded-full text-[#aaa] transition-all hover:text-white"
            >
              <ChevronLeft size={20} />
            </button>
            <button 
              onClick={() => scroll('right')} 
              className="p-1.5 hover:bg-white/10 rounded-full text-[#aaa] transition-all hover:text-white"
            >
              <ChevronRight size={20} />
            </button>
          </div>
        </div>

        <div 
          ref={scrollRef}
          className="flex gap-3 sm:gap-4 overflow-x-auto no-scrollbar scroll-smooth snap-x snap-mandatory px-1"
        >
          {videos.map(video => (
            <ShortVideoCard 
              key={video.id} 
              video={video} 
              className="w-[125px] sm:w-[150px] md:w-[170px]"
            />
          ))}
        </div>
      </div>
      
      <style>{`
        .no-scrollbar::-webkit-scrollbar { display: none; }
        .no-scrollbar { -ms-overflow-style: none; scrollbar-width: none; }
      `}</style>
    </section>
  );
};

export default ShortVideoHorizontalList;
