
import React from 'react';
import { Video } from '../types';
import { useNavigate } from 'react-router-dom';
import { Zap } from 'lucide-react';

interface ShortVideoCardProps {
  video: Video;
  className?: string;
}

const ShortVideoCard: React.FC<ShortVideoCardProps> = ({ video, className = "" }) => {
  const navigate = useNavigate();

  const handleClick = (e: React.MouseEvent) => {
    e.preventDefault();
    navigate(`/shorts/${video.id}`);
  };

  return (
    <div 
      onClick={handleClick}
      className={`group relative aspect-[9/16] overflow-hidden rounded-2xl cursor-pointer transition-all duration-300 active:scale-95 snap-start shrink-0 select-none shadow-xl border border-white/5 ${className}`}
    >
      {/* Background Media */}
      <img 
        src={video.thumbnail} 
        alt={video.title} 
        className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110" 
        loading="lazy"
      />
      
      {/* Immersive Overlays */}
      <div className="absolute inset-x-0 top-0 h-1/4 bg-gradient-to-b from-black/60 to-transparent" />
      <div className="absolute inset-x-0 bottom-0 h-2/5 bg-gradient-to-t from-black/80 via-black/30 to-transparent" />

      {/* Top UI: Avatar with Pulse Ring */}
      <div className="absolute top-3 left-3 z-10">
        <div className="p-[2px] bg-gradient-to-tr from-[#f09433] to-[#bc1888] rounded-full shadow-lg transform transition-transform group-hover:scale-105">
          <div className="p-[1.5px] bg-black rounded-full">
            <img 
              src={video.channelAvatar} 
              className="w-8 h-8 sm:w-10 sm:h-10 rounded-full object-cover" 
              alt={video.channelName} 
            />
          </div>
        </div>
      </div>

      {/* Top UI: Duration Badge */}
      <div className="absolute top-3 right-3 z-10">
        <div className="bg-black/30 backdrop-blur-md px-1.5 py-0.5 rounded-lg text-white border border-white/10 flex items-center gap-1 group-hover:bg-red-600 transition-colors duration-300">
          <Zap size={10} fill="white" className="text-white" />
          <span className="text-[9px] font-black uppercase tracking-tighter">{video.duration}</span>
        </div>
      </div>

      {/* Bottom UI: Content Info */}
      <div className="absolute bottom-0 left-0 right-0 p-4 flex flex-col justify-end pointer-events-none">
        <h3 className="text-[12px] sm:text-[14px] font-black leading-tight text-white drop-shadow-lg line-clamp-2 mb-1 group-hover:text-[#3ea6ff] transition-colors">
          {video.title}
        </h3>
        <p className="text-[9px] sm:text-[10px] font-bold text-white/60 truncate uppercase tracking-widest">
           {video.channelName}
        </p>
      </div>
      
      {/* Subtle Glow Overlay */}
      <div className="absolute inset-0 ring-1 ring-inset ring-white/5 group-hover:ring-white/20 transition-all pointer-events-none" />
    </div>
  );
};

export default ShortVideoCard;
