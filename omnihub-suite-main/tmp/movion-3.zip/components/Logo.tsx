
import React from 'react';

interface LogoProps {
  className?: string;
  size?: number;
}

const Logo: React.FC<LogoProps> = ({ className = "", size = 40 }) => {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 100 100"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      className={className}
    >
      <defs>
        <filter id="dropShadow" x="-20%" y="-20%" width="140%" height="140%">
          <feGaussianBlur in="SourceAlpha" stdDeviation="2" />
          <feOffset dx="1" dy="1" result="offsetblur" />
          <feComponentTransfer>
            <feFuncA type="linear" slope="0.3" />
          </feComponentTransfer>
          <feMerge>
            <feMergeNode />
            <feMergeNode in="SourceGraphic" />
          </feMerge>
        </filter>
        <linearGradient id="greyGrad1" x1="0%" y1="0%" x2="100%" y2="100%">
          <stop offset="0%" stopColor="#E5E7EB" />
          <stop offset="100%" stopColor="#9CA3AF" />
        </linearGradient>
        <linearGradient id="greyGrad2" x1="0%" y1="0%" x2="100%" y2="100%">
          <stop offset="0%" stopColor="#D1D5DB" />
          <stop offset="100%" stopColor="#6B7280" />
        </linearGradient>
      </defs>

      {/* Outer Shutter Segments */}
      <g filter="url(#dropShadow)">
        {/* Top Segment */}
        <path d="M50 5 L80 15 L65 40 L35 40 L20 15 Z" fill="url(#greyGrad1)" stroke="white" strokeWidth="0.5" />
        {/* Top Right */}
        <path d="M80 15 L95 45 L75 65 L65 40 Z" fill="url(#greyGrad2)" stroke="white" strokeWidth="0.5" />
        {/* Bottom Right */}
        <path d="M95 45 L80 85 L50 75 L75 65 Z" fill="url(#greyGrad1)" stroke="white" strokeWidth="0.5" />
        {/* Bottom Segment */}
        <path d="M80 85 L50 95 L20 85 L35 60 L50 75 Z" fill="url(#greyGrad2)" stroke="white" strokeWidth="0.5" />
        {/* Bottom Left */}
        <path d="M20 85 L5 55 L25 35 L35 60 Z" fill="url(#greyGrad1)" stroke="white" strokeWidth="0.5" />
        {/* Top Left */}
        <path d="M5 55 L20 15 L35 40 L25 35 Z" fill="url(#greyGrad2)" stroke="white" strokeWidth="0.5" />
      </g>

      {/* Center Hexagon Background */}
      <path d="M35 40 L65 40 L75 65 L50 75 L35 60 L25 35 Z" fill="#F3F4F6" />

      {/* The 'S' Mark */}
      <path 
        d="M62 42 C58 37 46 37 42 42 C38 46 38 52 42 56 C46 60 54 60 58 64 C62 68 62 74 58 78 C54 82 44 82 40 78" 
        stroke="#0f0f0f" 
        strokeWidth="7" 
        strokeLinecap="round"
        fill="none"
      />
      
      {/* Motion Lines (Speed effect) */}
      <path d="M28 50 L18 50" stroke="#0f0f0f" strokeWidth="2.5" strokeLinecap="round" />
      <path d="M25 56 L15 56" stroke="#0f0f0f" strokeWidth="2.5" strokeLinecap="round" />
      <path d="M28 62 L18 62" stroke="#0f0f0f" strokeWidth="2.5" strokeLinecap="round" />

    </svg>
  );
};

export default Logo;
