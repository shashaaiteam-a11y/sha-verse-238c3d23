
export interface Friend {
  id: string;
  name: string;
  avatar: string;
  mutualFriends?: number;
}

export interface User {
  id: string;
  name: string;
  avatar: string;
  bio?: string;
  coverPhoto?: string;
  work?: string;
  education?: string;
  location?: string;
  hometown?: string;
  relationshipStatus?: string;
  joinedDate?: string;
  friendsCount?: number;
  friends?: Friend[];
  photos?: string[];
  hobbies?: string[];
  isVerified?: boolean;
}

export interface Comment {
  id: string;
  userId: string;
  userName: string;
  userAvatar: string;
  text: string;
  timestamp: number;
  likes: number;
  isLikedByCurrentUser?: boolean;
}

export type PostType = 'text' | 'image' | 'video' | 'reel' | 'poll';
export type ReactionType = 'like' | 'love' | 'haha' | 'wow' | 'sad' | 'angry';

export interface PollOption {
  id: string;
  text: string;
  votes: number;
}

export interface Post {
  id: string;
  userId: string;
  userName: string;
  userAvatar: string;
  content: string;
  mediaUrls?: string[]; 
  type: PostType;
  reactions: Record<ReactionType, number>;
  currentUserReaction?: ReactionType;
  comments: Comment[];
  timestamp: number;
  pollOptions?: PollOption[];
  totalVotes?: number;
  votedOptionId?: string;
  isEdited?: boolean;
  userIsVerified?: boolean;
}

export interface Group {
  id: string;
  name: string;
  description: string;
  coverImage: string;
  members: number;
  isJoined?: boolean;
}

// --- Movion Types ---
export interface Video {
  id: string;
  title: string;
  thumbnail: string;
  channelName: string;
  channelAvatar: string;
  views: number;
  uploadedAt: string;
  duration: string;
}

export interface MonetizationStats {
  revenue: number;
  views: number;
  subscribers: number;
  watchTimeHours: number;
}

// --- NovaChat Types ---
export interface ChatMessage {
  id: string;
  role: 'user' | 'model';
  text: string;
  timestamp: number;
}

// --- Bookshelf Types ---
export interface Book {
  id: string;
  title: string;
  author: string;
  cover: string;
  description: string;
  content: string; // Mock content
  reads: number;
  rating: number;
}

// --- Messages / WhatsApp Clone Types ---
export type MessageStatus = 'sent' | 'delivered' | 'read';

export interface DirectMessage {
  id: string;
  senderId: string;
  text: string;
  timestamp: number;
  status: MessageStatus;
  isAudio?: boolean;
  duration?: string;
}

export interface ChatThread {
  id: string;
  contactId: string;
  contactName: string;
  contactAvatar: string;
  lastMessage: string;
  lastMessageTime: number;
  unreadCount: number;
  isOnline: boolean;
  messages: DirectMessage[];
}

export enum ViewState {
  HOME = 'HOME',
  MOVION = 'MOVION',
  NOVACHAT = 'NOVACHAT',
  BOOKSHELF = 'BOOKSHELF',
  GROUPS = 'GROUPS',
  PROFILE = 'PROFILE',
  MESSAGES = 'MESSAGES'
}
