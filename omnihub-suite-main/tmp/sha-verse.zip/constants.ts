
import { User, Post, Group, Friend, Video, Book, ChatThread } from './types';

export const MOCK_FRIENDS: Friend[] = [
  { id: 'f1', name: 'Sarah Designer', avatar: 'https://picsum.photos/150/150?random=2', mutualFriends: 12 },
  { id: 'f2', name: 'Mike Manager', avatar: 'https://picsum.photos/150/150?random=3', mutualFriends: 8 },
  { id: 'f3', name: 'David Traveler', avatar: 'https://picsum.photos/150/150?random=4', mutualFriends: 24 },
  { id: 'f4', name: 'Tech News Daily', avatar: 'https://picsum.photos/150/150?random=5', mutualFriends: 2 },
  { id: 'f5', name: 'Jenny Photographer', avatar: 'https://picsum.photos/150/150?random=6', mutualFriends: 45 },
  { id: 'f6', name: 'Tom Coder', avatar: 'https://picsum.photos/150/150?random=7', mutualFriends: 3 },
  { id: 'f7', name: 'Lisa Baker', avatar: 'https://picsum.photos/150/150?random=8', mutualFriends: 15 },
  { id: 'f8', name: 'James Hiker', avatar: 'https://picsum.photos/150/150?random=9', mutualFriends: 9 },
  { id: 'f9', name: 'Emily Writer', avatar: 'https://picsum.photos/150/150?random=13', mutualFriends: 31 },
];

export const CURRENT_USER: User = {
  id: 'u1',
  name: 'Alex Developer',
  avatar: 'https://picsum.photos/150/150?random=1',
  bio: 'Frontend Engineer | Coffee Enthusiast | React Lover',
  coverPhoto: 'https://picsum.photos/800/350?random=99',
  work: 'Senior Engineer at TechFlow',
  education: 'Studied CS at MIT',
  location: 'San Francisco, CA',
  hometown: 'Austin, TX',
  relationshipStatus: 'Single',
  joinedDate: 'September 2015',
  friendsCount: 1245,
  friends: MOCK_FRIENDS,
  hobbies: ['Coding', 'Coffee', 'React', 'Sci-Fi'],
  isVerified: true,
  photos: [
    'https://picsum.photos/300/300?random=101',
    'https://picsum.photos/300/300?random=102',
    'https://picsum.photos/300/300?random=103',
    'https://picsum.photos/300/300?random=104',
    'https://picsum.photos/300/300?random=105',
    'https://picsum.photos/300/300?random=106',
    'https://picsum.photos/300/300?random=107',
    'https://picsum.photos/300/300?random=108',
    'https://picsum.photos/300/300?random=109',
  ]
};

export const INITIAL_GROUPS: Group[] = [
  {
    id: 'g1',
    name: 'React Developers',
    description: 'A community for React.js enthusiasts to share knowledge and projects.',
    coverImage: 'https://picsum.photos/400/200?random=10',
    members: 15420,
    isJoined: true,
  },
  {
    id: 'g2',
    name: 'Landscape Photography',
    description: 'Share your best shots of nature and landscapes.',
    coverImage: 'https://picsum.photos/400/200?random=11',
    members: 8300,
    isJoined: false,
  },
  {
    id: 'g3',
    name: 'Delicious Recipes',
    description: 'Home cooking, baking, and culinary experiments.',
    coverImage: 'https://picsum.photos/400/200?random=12',
    members: 42100,
    isJoined: false,
  },
  {
    id: 'g4',
    name: 'Gemini AI Enthusiasts',
    description: 'Exploring the capabilities of Google Gemini models.',
    coverImage: 'https://picsum.photos/400/200?random=14',
    members: 12050,
    isJoined: true,
  },
  {
    id: 'g5',
    name: 'Digital Nomads',
    description: 'Tips and tricks for working remotely from anywhere in the world.',
    coverImage: 'https://picsum.photos/400/200?random=15',
    members: 25600,
    isJoined: false,
  }
];

export const INITIAL_POSTS: Post[] = [
  {
    id: 'p1',
    userId: 'u2',
    userName: 'Sarah Designer',
    userAvatar: 'https://picsum.photos/150/150?random=2',
    content: 'Just finished the new UI kit for our upcoming project. The colors are popping! 🎨✨',
    mediaUrls: ['https://picsum.photos/600/400?random=20', 'https://picsum.photos/600/400?random=920'],
    type: 'image',
    reactions: { like: 42, love: 10, haha: 2, wow: 5, sad: 0, angry: 0 },
    comments: [
      {
        id: 'c1',
        userId: 'u3',
        userName: 'Mike Manager',
        userAvatar: 'https://picsum.photos/150/150?random=3',
        text: 'Looks amazing, Sarah!',
        timestamp: Date.now() - 3600000,
        likes: 2,
        isLikedByCurrentUser: false
      }
    ],
    timestamp: Date.now() - 7200000,
    currentUserReaction: undefined,
  },
  {
    id: 'p2',
    userId: 'u4',
    userName: 'David Traveler',
    userAvatar: 'https://picsum.photos/150/150?random=4',
    content: 'Hiking in the Alps was an unforgettable experience. The view from the top is breathtaking.',
    mediaUrls: ['https://picsum.photos/600/400?random=21', 'https://picsum.photos/600/400?random=22', 'https://picsum.photos/600/400?random=23'],
    type: 'image',
    reactions: { like: 128, love: 45, haha: 0, wow: 20, sad: 0, angry: 0 },
    comments: [],
    timestamp: Date.now() - 86400000,
    currentUserReaction: 'love',
  },
  {
    id: 'p3',
    userId: 'u5',
    userName: 'Tech News Daily',
    userAvatar: 'https://picsum.photos/150/150?random=5',
    content: 'Gemini 2.5 Flash is incredibly fast! Have you tried building with it yet? 🚀',
    type: 'text',
    reactions: { like: 899, love: 0, haha: 5, wow: 120, sad: 0, angry: 2 },
    comments: [],
    timestamp: Date.now() - 172800000,
    currentUserReaction: undefined,
    userIsVerified: true,
  },
  {
      id: 'p4',
      userId: 'u1',
      userName: 'Alex Developer',
      userAvatar: 'https://picsum.photos/150/150?random=1',
      content: 'Updated my portfolio with the latest React 19 features. Check it out!',
      type: 'text',
      reactions: { like: 15, love: 2, haha: 0, wow: 1, sad: 0, angry: 0 },
      comments: [],
      timestamp: Date.now() - 200000000,
      currentUserReaction: undefined,
      userIsVerified: true,
  }
];

export const MOCK_VIDEOS: Video[] = [
  {
    id: 'v1',
    title: 'Building a Full Stack App in 10 Minutes',
    thumbnail: 'https://picsum.photos/600/340?random=201',
    channelName: 'Code Master',
    channelAvatar: 'https://picsum.photos/50/50?random=202',
    views: 125000,
    uploadedAt: '2 days ago',
    duration: '10:24',
  },
  {
    id: 'v2',
    title: 'Relaxing Jazz Music for Coding',
    thumbnail: 'https://picsum.photos/600/340?random=203',
    channelName: 'Chill Vibes',
    channelAvatar: 'https://picsum.photos/50/50?random=204',
    views: 3400000,
    uploadedAt: '1 year ago',
    duration: '3:00:00',
  },
  {
    id: 'v3',
    title: 'Top 10 Travel Destinations 2025',
    thumbnail: 'https://picsum.photos/600/340?random=205',
    channelName: 'Wanderlust',
    channelAvatar: 'https://picsum.photos/50/50?random=206',
    views: 89000,
    uploadedAt: '5 hours ago',
    duration: '15:45',
  },
  {
    id: 'v4',
    title: 'Understanding AI Models: Deep Dive',
    thumbnail: 'https://picsum.photos/600/340?random=207',
    channelName: 'Tech Explained',
    channelAvatar: 'https://picsum.photos/50/50?random=208',
    views: 560000,
    uploadedAt: '1 month ago',
    duration: '22:10',
  },
];

export const MOCK_BOOKS: Book[] = [
  {
    id: 'b1',
    title: 'The Art of Code',
    author: 'Alex Smith',
    cover: 'https://picsum.photos/200/300?random=301',
    description: 'A comprehensive guide to writing clean and efficient code.',
    content: 'Chapter 1: Simplicity\n\nSimplicity is the soul of efficiency. When writing code, one must always strive for clarity over cleverness...',
    reads: 45000,
    rating: 4.8,
  },
  {
    id: 'b2',
    title: 'Mountain Whispers',
    author: 'Elena Fisher',
    cover: 'https://picsum.photos/200/300?random=302',
    description: 'A thrilling mystery set in the snowy peaks of the Rockies.',
    content: 'The wind howled through the valley, carrying secrets from the peaks above. Sarah pulled her coat tighter...',
    reads: 12000,
    rating: 4.5,
  },
  {
    id: 'b3',
    title: 'Future Tech 2050',
    author: 'Dr. R. Data',
    cover: 'https://picsum.photos/200/300?random=303',
    description: 'Predictions about humanity\'s future with advanced AI.',
    content: 'By 2050, the integration of biological and synthetic intelligence will be indistinguishable...',
    reads: 89000,
    rating: 4.9,
  },
];

export const MOCK_CHATS: ChatThread[] = [
  {
    id: 'chat1',
    contactId: 'f1',
    contactName: 'Sarah Designer',
    contactAvatar: 'https://picsum.photos/150/150?random=2',
    lastMessage: 'The new designs look great! 👍',
    lastMessageTime: Date.now() - 120000,
    unreadCount: 2,
    isOnline: true,
    messages: [
        { id: 'm1', senderId: 'u1', text: 'Hey Sarah, how is the project going?', timestamp: Date.now() - 3600000, status: 'read' },
        { id: 'm2', senderId: 'f1', text: 'Going well! I just finished the new icon set.', timestamp: Date.now() - 3500000, status: 'read' },
        { id: 'm3', senderId: 'u1', text: 'Awesome, can I see them?', timestamp: Date.now() - 3400000, status: 'read' },
        { id: 'm4', senderId: 'f1', text: 'Sure, sending them now.', timestamp: Date.now() - 200000, status: 'read' },
        { id: 'm5', senderId: 'f1', text: 'The new designs look great! 👍', timestamp: Date.now() - 120000, status: 'delivered' },
    ]
  },
  {
    id: 'chat2',
    contactId: 'f2',
    contactName: 'Mike Manager',
    contactAvatar: 'https://picsum.photos/150/150?random=3',
    lastMessage: 'Meeting in 10 mins?',
    lastMessageTime: Date.now() - 18000000,
    unreadCount: 0,
    isOnline: false,
    messages: [
         { id: 'm1', senderId: 'f2', text: 'Are we still on for today?', timestamp: Date.now() - 19000000, status: 'read' },
         { id: 'm2', senderId: 'u1', text: 'Yes, absolutely.', timestamp: Date.now() - 18500000, status: 'read' },
         { id: 'm3', senderId: 'f2', text: 'Meeting in 10 mins?', timestamp: Date.now() - 18000000, status: 'read' },
    ]
  },
  {
    id: 'chat3',
    contactId: 'f3',
    contactName: 'David Traveler',
    contactAvatar: 'https://picsum.photos/150/150?random=4',
    lastMessage: 'Sent a photo',
    lastMessageTime: Date.now() - 86400000,
    unreadCount: 0,
    isOnline: true,
    messages: [
         { id: 'm1', senderId: 'f3', text: 'Check out this view!', timestamp: Date.now() - 86500000, status: 'read' },
         { id: 'm2', senderId: 'f3', text: 'Sent a photo', timestamp: Date.now() - 86400000, status: 'read' },
    ]
  },
  {
    id: 'chat4',
    contactId: 'f6',
    contactName: 'Tom Coder',
    contactAvatar: 'https://picsum.photos/150/150?random=7',
    lastMessage: 'Voice message (0:42)',
    lastMessageTime: Date.now() - 200000000,
    unreadCount: 0,
    isOnline: false,
    messages: [
        { id: 'm1', senderId: 'u1', text: 'Did you fix the bug?', timestamp: Date.now() - 200500000, status: 'read' },
        { id: 'm2', senderId: 'f6', text: 'Voice message (0:42)', timestamp: Date.now() - 200000000, status: 'read', isAudio: true, duration: '0:42' },
    ]
  }
];
