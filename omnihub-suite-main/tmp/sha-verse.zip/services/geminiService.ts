import { GoogleGenAI } from "@google/genai";

const getAiClient = () => {
  if (!process.env.API_KEY) {
    console.warn("API_KEY is missing from environment variables.");
    return null;
  }
  return new GoogleGenAI({ apiKey: process.env.API_KEY });
};

export const generatePostContent = async (topic: string): Promise<string> => {
  const ai = getAiClient();
  if (!ai) return `Check out this cool topic: ${topic}!`;

  try {
    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: `Write a short, engaging, and casual Facebook-style social media post about: "${topic}". Include emojis. Do not include hashtags. Keep it under 280 characters.`,
    });
    return response.text.trim();
  } catch (error) {
    console.error("Error generating content:", error);
    return `Thinking about ${topic}... (AI unavailable)`;
  }
};

export const sendChatMessage = async (history: { role: string, parts: { text: string }[] }[], newMessage: string): Promise<string> => {
  const ai = getAiClient();
  if (!ai) return "I'm offline right now, but I'd love to chat later!";

  try {
    const chat = ai.chats.create({
      model: 'gemini-2.5-flash',
      history: history,
      config: {
        systemInstruction: "You are Nova, a friendly, witty, and highly intelligent AI assistant integrated into the NovaChat social platform. You are helpful, concise, and engaging.",
      }
    });

    const result = await chat.sendMessage({ message: newMessage });
    return result.text;
  } catch (error) {
    console.error("Error sending chat message:", error);
    return "I'm having trouble connecting to the server. Please try again.";
  }
};