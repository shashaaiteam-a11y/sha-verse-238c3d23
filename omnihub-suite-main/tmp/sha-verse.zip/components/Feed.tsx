
import React from 'react';
import { Post, User, ReactionType } from '../types';
import { CreatePost } from './CreatePost';
import { PostCard } from './PostCard';

interface FeedProps {
  currentUser: User;
  posts: Post[];
  onCreatePost: (content: string, mediaUrl?: string, type?: 'text' | 'image' | 'video' | 'reel' | 'poll', pollOptions?: string[]) => void;
  onLike: (postId: string, reaction: ReactionType) => void;
  onComment: (postId: string, text: string) => void;
  onVote: (postId: string, optionId: string) => void;
  onEditPost: (postId: string, content: string) => void;
  onDeletePost: (postId: string) => void;
  onLikeComment: (postId: string, commentId: string) => void;
}

export const Feed: React.FC<FeedProps> = ({ currentUser, posts, onCreatePost, onLike, onComment, onVote, onEditPost, onDeletePost, onLikeComment }) => {
  return (
    <div className="max-w-[590px] mx-auto pt-4 pb-24 px-0">
        {/* Stories Section (Mock) */}
        <div className="bg-white md:rounded-lg shadow-sm p-4 mb-4 flex gap-2 overflow-x-auto no-scrollbar">
             {/* Add Story Card */}
             <div className="relative min-w-[100px] h-[170px] rounded-xl overflow-hidden cursor-pointer group flex-shrink-0">
                  <img src={currentUser.avatar} className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300" alt="Me" />
                  <div className="absolute inset-0 bg-black/10"></div>
                  <div className="absolute bottom-0 left-0 right-0 h-10 bg-white flex justify-center items-end pb-2">
                       <span className="text-xs font-semibold">Create story</span>
                  </div>
                  <div className="absolute bottom-6 left-1/2 transform -translate-x-1/2 w-8 h-8 bg-blue-600 rounded-full border-4 border-white flex items-center justify-center text-white">
                      <span className="text-xl font-bold">+</span>
                  </div>
             </div>
             
             {/* Friend Stories */}
             {[1,2,3,4,5].map((i) => (
                 <div key={i} className="relative min-w-[100px] h-[170px] rounded-xl overflow-hidden cursor-pointer group flex-shrink-0">
                      <img src={`https://picsum.photos/200/300?random=${i+50}`} className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300" alt="Story" />
                      <div className="absolute inset-0 bg-gradient-to-b from-black/30 to-transparent"></div>
                      <div className="absolute top-3 left-3 w-9 h-9 rounded-full border-4 border-blue-600 p-0.5 bg-blue-600">
                          <img src={`https://picsum.photos/100/100?random=${i}`} className="w-full h-full rounded-full object-cover" />
                      </div>
                      <div className="absolute bottom-2 left-2 text-white font-semibold text-xs">
                          Friend {i}
                      </div>
                 </div>
             ))}
        </div>

      <CreatePost currentUser={currentUser} onCreatePost={onCreatePost} />
      
      <div className="space-y-4">
        {posts.map(post => (
          <PostCard
            key={post.id}
            post={post}
            currentUser={currentUser}
            onLike={onLike}
            onComment={onComment}
            onVote={onVote}
            onEditPost={onEditPost}
            onDeletePost={onDeletePost}
            onLikeComment={onLikeComment}
          />
        ))}
      </div>
    </div>
  );
};
