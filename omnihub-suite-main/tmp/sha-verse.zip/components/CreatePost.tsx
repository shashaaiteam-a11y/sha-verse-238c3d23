
import React, { useState } from 'react';
import { User, PostType } from '../types';
import { Image, Sparkles, X, Loader2, Video, BarChart2, Plus, Trash2 } from 'lucide-react';
import { generatePostContent } from '../services/geminiService';

interface CreatePostProps {
  currentUser: User;
  onCreatePost: (content: string, mediaUrl?: string, type?: PostType, pollOptions?: string[]) => void;
}

const MAX_CHARACTERS = 500;

export const CreatePost: React.FC<CreatePostProps> = ({ currentUser, onCreatePost }) => {
  const [content, setContent] = useState('');
  const [isAiLoading, setIsAiLoading] = useState(false);
  const [showAiInput, setShowAiInput] = useState(false);
  const [aiPrompt, setAiPrompt] = useState('');
  
  // Media State
  const [mediaUrl, setMediaUrl] = useState<string | null>(null);
  const [mediaType, setMediaType] = useState<'image' | 'video' | 'reel' | null>(null);
  
  // Poll State
  const [showPollCreator, setShowPollCreator] = useState(false);
  const [pollOptions, setPollOptions] = useState<string[]>(['', '']);

  const handlePost = () => {
    if (!content.trim() && !mediaUrl && !showPollCreator) return;
    
    // Determine post type
    let type: PostType = 'text';
    if (showPollCreator) type = 'poll';
    else if (mediaType === 'video') type = 'video';
    else if (mediaType === 'reel') type = 'reel';
    else if (mediaType === 'image') type = 'image';

    const finalOptions = showPollCreator ? pollOptions.filter(opt => opt.trim() !== '') : [];

    onCreatePost(content, mediaUrl || undefined, type, finalOptions);
    
    // Reset state
    setContent('');
    setMediaUrl(null);
    setMediaType(null);
    setShowPollCreator(false);
    setPollOptions(['', '']);
    setShowAiInput(false);
  };

  const handleAiGenerate = async () => {
    if (!aiPrompt.trim()) return;
    setIsAiLoading(true);
    try {
      const generated = await generatePostContent(aiPrompt);
      setContent(generated);
      setShowAiInput(false);
      setAiPrompt('');
    } finally {
      setIsAiLoading(false);
    }
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>, type: 'image' | 'video' | 'reel') => {
      const file = e.target.files?.[0];
      if (file) {
          const url = URL.createObjectURL(file);
          setMediaUrl(url);
          setMediaType(type);
          setShowPollCreator(false); // Disable poll if media added
      }
  };

  const handlePollOptionChange = (index: number, value: string) => {
      const newOptions = [...pollOptions];
      newOptions[index] = value;
      setPollOptions(newOptions);
  };

  const addPollOption = () => setPollOptions([...pollOptions, '']);
  const removePollOption = (index: number) => {
      const newOptions = pollOptions.filter((_, i) => i !== index);
      setPollOptions(newOptions);
  }

  const togglePoll = () => {
      setShowPollCreator(!showPollCreator);
      if (!showPollCreator) {
          setMediaUrl(null);
          setMediaType(null);
      }
  };

  const remainingChars = MAX_CHARACTERS - content.length;
  const isOverLimit = remainingChars < 0;

  return (
    <div className="bg-white p-4 shadow-sm md:rounded-lg mb-4">
      <div className="flex items-start mb-4">
        <img
          src={currentUser.avatar}
          alt={currentUser.name}
          className="w-10 h-10 rounded-full mr-3 object-cover border border-gray-200 mt-1"
        />
        <div className="flex-1">
            <textarea
                placeholder={`What's on your mind, ${currentUser.name.split(' ')[0]}?`}
                className="w-full bg-gray-100 rounded-2xl py-3 px-4 outline-none hover:bg-gray-200 focus:bg-gray-200 transition-colors cursor-text text-sm md:text-base resize-none"
                rows={showPollCreator || mediaUrl ? 2 : 1}
                value={content}
                onChange={(e) => setContent(e.target.value)}
            />
            {/* Character Counter */}
            <div className={`text-xs text-right mt-1 ${isOverLimit ? 'text-red-500 font-bold' : remainingChars < 50 ? 'text-amber-500' : 'text-gray-400'}`}>
                {content.length}/{MAX_CHARACTERS}
            </div>
        </div>
      </div>

      {/* Media Preview */}
      {mediaUrl && (
          <div className="mb-4 relative rounded-lg overflow-hidden border border-gray-200 bg-black">
               <button onClick={() => { setMediaUrl(null); setMediaType(null); }} className="absolute top-2 right-2 bg-black/50 text-white p-1 rounded-full hover:bg-black/70 z-10">
                   <X className="w-5 h-5" />
               </button>
               {mediaType === 'image' ? (
                   <img src={mediaUrl} alt="Preview" className="w-full max-h-96 object-contain" />
               ) : (
                   <video src={mediaUrl} controls className={`w-full ${mediaType === 'reel' ? 'max-h-[500px] aspect-[9/16]' : 'max-h-96'} object-contain`} />
               )}
               <div className="absolute bottom-2 left-2 bg-black/60 text-white px-2 py-1 rounded text-xs capitalize">
                   {mediaType}
               </div>
          </div>
      )}

      {/* Poll Creator */}
      {showPollCreator && (
          <div className="mb-4 bg-gray-50 p-4 rounded-lg border border-gray-200 animate-fadeIn">
               <div className="flex justify-between items-center mb-2">
                   <h4 className="text-sm font-bold text-gray-700">Create Poll</h4>
                   <button onClick={() => setShowPollCreator(false)} className="text-gray-400 hover:text-red-500">
                       <X className="w-4 h-4" />
                   </button>
               </div>
               <div className="space-y-2">
                   {pollOptions.map((opt, i) => (
                       <div key={i} className="flex gap-2">
                           <input
                                type="text"
                                placeholder={`Option ${i + 1}`}
                                value={opt}
                                onChange={(e) => handlePollOptionChange(i, e.target.value)}
                                className="flex-1 border border-gray-300 rounded px-3 py-2 text-sm focus:ring-2 focus:ring-blue-300 outline-none"
                           />
                           {pollOptions.length > 2 && (
                               <button onClick={() => removePollOption(i)} className="text-gray-400 hover:text-red-500">
                                   <Trash2 className="w-4 h-4" />
                               </button>
                           )}
                       </div>
                   ))}
               </div>
               <button onClick={addPollOption} className="mt-2 text-blue-600 text-sm font-semibold hover:underline flex items-center">
                   <Plus className="w-4 h-4 mr-1" /> Add Option
               </button>
          </div>
      )}

      {/* AI Input */}
      {showAiInput && (
        <div className="mb-4 bg-blue-50 p-3 rounded-lg border border-blue-100 animate-fadeIn">
            <div className="flex justify-between items-center mb-2">
                <span className="text-xs font-bold text-blue-700 uppercase tracking-wide flex items-center">
                    <Sparkles className="w-3 h-3 mr-1" />
                    AI Assistant
                </span>
                <button onClick={() => setShowAiInput(false)} className="text-gray-400 hover:text-gray-600">
                    <X className="w-4 h-4" />
                </button>
            </div>
            <div className="flex gap-2">
                <input
                    type="text"
                    value={aiPrompt}
                    onChange={(e) => setAiPrompt(e.target.value)}
                    placeholder="E.g., A funny joke about coding..."
                    className="flex-1 text-sm border border-blue-200 rounded px-3 py-2 outline-none focus:ring-2 focus:ring-blue-300"
                    onKeyDown={(e) => {
                        if (e.key === 'Enter') handleAiGenerate();
                    }}
                />
                <button
                    onClick={handleAiGenerate}
                    disabled={isAiLoading || !aiPrompt.trim()}
                    className="bg-blue-600 text-white px-4 py-2 rounded text-sm font-medium hover:bg-blue-700 disabled:opacity-50 flex items-center"
                >
                    {isAiLoading ? <Loader2 className="w-4 h-4 animate-spin" /> : 'Generate'}
                </button>
            </div>
        </div>
      )}

      {/* Action Buttons */}
      <div className="border-t border-gray-100 pt-3 flex flex-wrap justify-between items-center gap-2">
        <div className="flex gap-1 overflow-x-auto no-scrollbar">
             <label className="flex items-center px-3 py-2 rounded-lg hover:bg-gray-50 transition-colors text-gray-600 cursor-pointer">
                <input type="file" accept="image/*" className="hidden" onChange={(e) => handleFileUpload(e, 'image')} />
                <Image className="w-5 h-5 text-green-500 mr-2" />
                <span className="text-sm font-medium hidden sm:inline">Photo</span>
            </label>
             <label className="flex items-center px-3 py-2 rounded-lg hover:bg-gray-50 transition-colors text-gray-600 cursor-pointer">
                <input type="file" accept="video/*" className="hidden" onChange={(e) => handleFileUpload(e, 'video')} />
                <Video className="w-5 h-5 text-red-500 mr-2" />
                <span className="text-sm font-medium hidden sm:inline">Video</span>
            </label>
             <label className="flex items-center px-3 py-2 rounded-lg hover:bg-gray-50 transition-colors text-gray-600 cursor-pointer">
                <input type="file" accept="video/*" className="hidden" onChange={(e) => handleFileUpload(e, 'reel')} />
                <Video className="w-5 h-5 text-pink-500 mr-2" />
                <span className="text-sm font-medium hidden sm:inline">Reel</span>
            </label>
            <button onClick={togglePoll} className="flex items-center px-3 py-2 rounded-lg hover:bg-gray-50 transition-colors text-gray-600">
                <BarChart2 className="w-5 h-5 text-orange-500 mr-2" />
                <span className="text-sm font-medium hidden sm:inline">Poll</span>
            </button>
             <button
                onClick={() => setShowAiInput(!showAiInput)}
                className={`flex items-center px-3 py-2 rounded-lg hover:bg-purple-50 transition-colors ${showAiInput ? 'bg-purple-50 text-purple-700' : 'text-gray-600'}`}
            >
                <Sparkles className="w-5 h-5 text-purple-500 mr-2" />
                <span className="text-sm font-medium hidden sm:inline">Magic Write</span>
            </button>
        </div>

        {((content.trim() && !isOverLimit) || mediaUrl || (showPollCreator && pollOptions.filter(o=>o).length >= 2)) && (
             <button
                onClick={handlePost}
                className="bg-blue-600 text-white px-6 py-1.5 rounded-md font-semibold text-sm hover:bg-blue-700 transition-colors shadow-sm"
             >
                 Post
             </button>
        )}
      </div>
    </div>
  );
};
