import React from 'react';
import { Group } from '../types';
import { Search, Compass, PlusCircle, ArrowLeft } from 'lucide-react';
import { ShaVerseLogo } from './ShaVerseLogo';

interface GroupsProps {
  groups: Group[];
  onJoin: (groupId: string) => void;
  onBack: () => void;
}

export const Groups: React.FC<GroupsProps> = ({ groups, onJoin, onBack }) => {
  return (
    <div className="bg-gray-100 min-h-full pb-24">
      <div className="bg-white shadow-sm px-4 py-3 sticky top-0 z-30">
        <div className="flex justify-between items-center mb-3">
            <div className="flex items-center gap-2">
                <button onClick={onBack} className="md:hidden mr-1 text-gray-600 hover:bg-gray-100 p-1 rounded-full">
                    <ArrowLeft className="w-6 h-6" />
                </button>
                <ShaVerseLogo className="w-9 h-9" />
                <div className="flex flex-col">
                    <h1 className="text-xl font-bold text-gray-900 leading-none">Groups</h1>
                    <span className="text-[10px] text-gray-500 font-medium leading-none mt-0.5">Sha-Verse</span>
                </div>
            </div>
            <div className="bg-gray-100 p-2 rounded-full cursor-pointer hover:bg-gray-200">
                <Search className="w-5 h-5 text-gray-600" />
            </div>
        </div>
        
        <div className="flex gap-2 overflow-x-auto no-scrollbar pb-1">
            <button className="flex items-center px-4 py-2 bg-blue-50 text-blue-600 rounded-full font-semibold whitespace-nowrap text-sm">
                <Compass className="w-4 h-4 mr-2" />
                Discover
            </button>
            <button className="flex items-center px-4 py-2 bg-gray-100 text-gray-700 rounded-full font-semibold whitespace-nowrap hover:bg-gray-200 text-sm">
                <PlusCircle className="w-4 h-4 mr-2" />
                Your Groups
            </button>
            <button className="px-4 py-2 bg-gray-100 text-gray-700 rounded-full font-semibold whitespace-nowrap hover:bg-gray-200 text-sm">
                Events
            </button>
        </div>
      </div>

      <div className="max-w-2xl mx-auto p-4 space-y-4">
         <h2 className="font-bold text-lg text-gray-700">Suggested for you</h2>
         {groups.map(group => (
            <div key={group.id} className="bg-white rounded-xl shadow-sm border border-gray-200 overflow-hidden">
                <div className="relative h-40 md:h-56">
                    <img src={group.coverImage} alt={group.name} className="w-full h-full object-cover" />
                    <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent"></div>
                    <div className="absolute bottom-4 left-4 text-white max-w-[80%]">
                         <h3 className="font-bold text-lg md:text-xl drop-shadow-sm truncate">{group.name}</h3>
                         <p className="text-xs md:text-sm opacity-90">{group.members.toLocaleString()} members</p>
                    </div>
                </div>
                <div className="p-4">
                    <p className="text-gray-600 text-sm mb-4 line-clamp-2">{group.description}</p>
                    <div className="flex items-center gap-3">
                         <div className="flex -space-x-2">
                             {[1,2,3].map(i => (
                                 <img key={i} src={`https://picsum.photos/50/50?random=${i+100}`} className="w-8 h-8 rounded-full border-2 border-white" />
                             ))}
                         </div>
                         <div className="text-xs text-gray-500">
                             <strong>Friend Name</strong> and 15 friends joined
                         </div>
                    </div>
                    <button
                        onClick={() => onJoin(group.id)}
                        className={`w-full mt-4 py-2.5 rounded-lg font-semibold text-[15px] transition-colors ${
                            group.isJoined
                                ? 'bg-gray-100 text-gray-800 hover:bg-gray-200'
                                : 'bg-blue-100 text-blue-600 hover:bg-blue-200'
                        }`}
                    >
                        {group.isJoined ? 'Joined' : 'Join Group'}
                    </button>
                </div>
            </div>
         ))}
      </div>
    </div>
  );
};