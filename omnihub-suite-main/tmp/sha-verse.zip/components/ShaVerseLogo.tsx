import React from 'react';

export const ShaVerseLogo = ({ className = "w-10 h-10" }: { className?: string }) => (
  <svg viewBox="0 0 100 100" className={className} fill="none" xmlns="http://www.w3.org/2000/svg">
     {/* Hexagon shape */}
     <path d="M50 0L93.3 25V75L50 100L6.7 75V25L50 0Z" className="fill-gray-700"/>
     <path d="M50 5L89 27.5V72.5L50 95L11 72.5V27.5L50 5Z" className="fill-gray-500"/>
     {/* Inner Hexagon for depth */}
     <path d="M50 20L76 35V65L50 80L24 65V35L50 20Z" className="fill-gray-300"/>
     {/* 'S' Letter */}
     <text x="50" y="65" fontSize="45" fontWeight="bold" textAnchor="middle" fill="#1f2937" fontFamily="sans-serif">S</text>
  </svg>
);