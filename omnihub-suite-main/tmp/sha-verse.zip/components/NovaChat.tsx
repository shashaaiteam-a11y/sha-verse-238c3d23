import React, { useState, useRef, useEffect } from 'react';
import { ChatMessage } from '../types';
import { sendChatMessage } from '../services/geminiService';
import { 
    Send, Bot, User as UserIcon, Loader2, Sparkles, Trash2, ArrowLeft, 
    Menu, Plus, MessageSquare, LogOut, Settings, Copy, Check, RefreshCw, StopCircle, PanelLeftClose, PanelLeft
} from 'lucide-react';
import { ShaVerseLogo } from './ShaVerseLogo';

interface NovaChatProps {
    onBack: () => void;
}

// --- Helper: Simple Code Block Renderer ---
const CodeBlock: React.FC<{ language: string, code: string }> = ({ language, code }) => {
    const [copied, setCopied] = useState(false);

    const handleCopy = () => {
        navigator.clipboard.writeText(code);
        setCopied(true);
        setTimeout(() => setCopied(false), 2000);
    };

    return (
        <div className="my-4 rounded-md overflow-hidden bg-black border border-gray-700 font-mono text-sm">
            <div className="flex justify-between items-center bg-gray-800 px-4 py-1.5 text-xs text-gray-200">
                <span className="lowercase">{language || 'code'}</span>
                <button onClick={handleCopy} className="flex items-center gap-1 hover:text-white transition-colors">
                    {copied ? <Check className="w-3 h-3" /> : <Copy className="w-3 h-3" />}
                    {copied ? 'Copied!' : 'Copy code'}
                </button>
            </div>
            <div className="p-4 overflow-x-auto bg-black text-gray-100">
                <pre><code>{code}</code></pre>
            </div>
        </div>
    );
};

// --- Helper: Message Parser ---
const MessageContent = ({ text }: { text: string }) => {
    // Basic parser to split code blocks from text
    // Format: ```language code ```
    const parts = text.split(/(```[\s\S]*?```)/g);

    return (
        <div className="leading-7">
            {parts.map((part, index) => {
                if (part.startsWith('```') && part.endsWith('```')) {
                    const content = part.slice(3, -3);
                    const newLineIndex = content.indexOf('\n');
                    const language = content.slice(0, newLineIndex).trim();
                    const code = content.slice(newLineIndex + 1);
                    return <CodeBlock key={index} language={language} code={code} />;
                }
                // Handle basic bolding **text**
                const textParts = part.split(/(\*\*.*?\*\*)/g);
                return (
                    <span key={index}>
                        {textParts.map((t, i) => {
                            if (t.startsWith('**') && t.endsWith('**')) {
                                return <strong key={i}>{t.slice(2, -2)}</strong>;
                            }
                            return t;
                        })}
                    </span>
                );
            })}
        </div>
    );
};

export const NovaChat: React.FC<NovaChatProps> = ({ onBack }) => {
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [inputText, setInputText] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  // Default sidebar closed on mobile, open on desktop
  const [sidebarOpen, setSidebarOpen] = useState(window.innerWidth >= 768);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const textareaRef = useRef<HTMLTextAreaElement>(null);

  // Auto-resize textarea
  useEffect(() => {
    if (textareaRef.current) {
        textareaRef.current.style.height = 'auto';
        textareaRef.current.style.height = `${Math.min(textareaRef.current.scrollHeight, 200)}px`;
    }
  }, [inputText]);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages, isTyping]);

  const handleSend = async () => {
    if (!inputText.trim()) return;

    const userMsg: ChatMessage = {
      id: Date.now().toString(),
      role: 'user',
      text: inputText,
      timestamp: Date.now()
    };

    setMessages(prev => [...prev, userMsg]);
    setInputText('');
    setIsTyping(true);

    // Prepare history for API
    const history = messages.map(m => ({
      role: m.role,
      parts: [{ text: m.text }]
    }));

    try {
      const responseText = await sendChatMessage(history, userMsg.text);
      const botMsg: ChatMessage = {
        id: (Date.now() + 1).toString(),
        role: 'model',
        text: responseText,
        timestamp: Date.now()
      };
      setMessages(prev => [...prev, botMsg]);
    } catch (error) {
      console.error("Failed to get response", error);
      const errorMsg: ChatMessage = {
          id: Date.now().toString(),
          role: 'model',
          text: "I'm sorry, I encountered an error. Please try again.",
          timestamp: Date.now()
      };
      setMessages(prev => [...prev, errorMsg]);
    } finally {
      setIsTyping(false);
    }
  };

  const handleRegenerate = async () => {
      const lastUserMessage = [...messages].reverse().find(m => m.role === 'user');
      if (!lastUserMessage) return;

      // Remove last bot message if exists
      if (messages[messages.length - 1].role === 'model') {
          setMessages(prev => prev.slice(0, -1));
      }

      setIsTyping(true);
      const history = messages.slice(0, -2).map(m => ({ // remove last interaction
        role: m.role,
        parts: [{ text: m.text }]
      }));

      try {
        const responseText = await sendChatMessage(history, lastUserMessage.text);
        const botMsg: ChatMessage = {
          id: Date.now().toString(),
          role: 'model',
          text: responseText,
          timestamp: Date.now()
        };
        setMessages(prev => [...prev, botMsg]);
      } catch (error) {
          console.error(error);
      } finally {
        setIsTyping(false);
      }
  };

  const handleNewChat = () => {
      setMessages([]);
      setInputText('');
      setIsTyping(false);
      if (window.innerWidth < 768) setSidebarOpen(false);
  };

  const suggestions = [
      { title: "Explain quantum computing", subtitle: "in simple terms" },
      { title: "Got any creative ideas", subtitle: "for a 10 year old's birthday?" },
      { title: "How do I make an HTTP request", subtitle: "in Javascript?" },
      { title: "Write a python script", subtitle: "to automate daily reports" },
  ];

  return (
    <div className="flex h-full md:h-full bg-[#343541] text-gray-100 font-sans overflow-hidden relative">
      
      {/* --- Sidebar --- */}
      <div 
        className={`fixed md:relative top-0 bottom-0 left-0 bg-[#202123] z-50 flex flex-col border-r border-white/10 transition-all duration-300 ease-in-out ${
            sidebarOpen ? 'w-[260px] translate-x-0' : 'w-0 -translate-x-full md:w-0 md:translate-x-0 overflow-hidden'
        }`}
      >
        <div className="p-3 flex-1 overflow-y-auto custom-scrollbar w-[260px]">
             <button 
                onClick={handleNewChat}
                className="w-full flex items-center gap-3 px-3 py-3 rounded-md border border-white/20 hover:bg-white/10 transition-colors text-sm text-white mb-4"
            >
                 <Plus className="w-4 h-4" />
                 New chat
             </button>

             <div className="flex flex-col gap-2">
                 <div className="text-xs font-medium text-gray-500 px-3 py-2">Today</div>
                 <button className="flex items-center gap-3 px-3 py-3 rounded-md hover:bg-white/10 transition-colors text-sm text-gray-100 overflow-hidden">
                     <MessageSquare className="w-4 h-4 text-gray-400 flex-shrink-0" />
                     <span className="truncate">React Component Help</span>
                 </button>
                 <button className="flex items-center gap-3 px-3 py-3 rounded-md hover:bg-white/10 transition-colors text-sm text-gray-100 overflow-hidden">
                     <MessageSquare className="w-4 h-4 text-gray-400 flex-shrink-0" />
                     <span className="truncate">Quantum Physics Explanation</span>
                 </button>
                 
                 <div className="text-xs font-medium text-gray-500 px-3 py-2 mt-4">Yesterday</div>
                 <button className="flex items-center gap-3 px-3 py-3 rounded-md hover:bg-white/10 transition-colors text-sm text-gray-100 overflow-hidden">
                     <MessageSquare className="w-4 h-4 text-gray-400 flex-shrink-0" />
                     <span className="truncate">Dinner Recipes</span>
                 </button>
             </div>
        </div>

        {/* Sidebar Footer */}
        <div className="p-2 border-t border-white/20 w-[260px]">
            <button className="flex items-center gap-3 px-3 py-3 w-full rounded-md hover:bg-white/10 transition-colors text-sm text-gray-100">
                <UserIcon className="w-4 h-4" />
                Upgrade to Plus
            </button>
            <div className="flex items-center gap-3 px-3 py-3 w-full rounded-md hover:bg-white/10 transition-colors text-sm text-gray-100 cursor-pointer">
                <img src="https://picsum.photos/150/150?random=1" className="w-8 h-8 rounded-sm" alt="User" />
                <div className="flex-1 font-bold">Alex Developer</div>
                <Settings className="w-4 h-4 text-gray-400" />
            </div>
        </div>
      </div>

      {/* Overlay for mobile when sidebar is open */}
      {sidebarOpen && (
          <div 
            className="fixed inset-0 bg-black/50 z-40 md:hidden"
            onClick={() => setSidebarOpen(false)}
          ></div>
      )}

      {/* --- Main Chat Area --- */}
      <div className="flex-1 flex flex-col h-full relative w-full">
        {/* Mobile Header / Desktop Toggle */}
        <div className="sticky top-0 z-30 text-gray-200 bg-[#343541] border-b border-white/5 p-2 flex items-center justify-between">
            <div className="flex items-center gap-2">
                <button 
                    onClick={() => setSidebarOpen(!sidebarOpen)} 
                    className="p-2 hover:bg-gray-700 rounded-md transition-colors"
                >
                    {sidebarOpen ? <PanelLeftClose className="w-5 h-5" /> : <PanelLeft className="w-5 h-5" />}
                </button>
                <div className="md:hidden font-semibold">NovaChat</div>
            </div>
            <div className="flex gap-2">
                <button onClick={handleNewChat} className="md:hidden p-2 hover:bg-gray-700 rounded-md">
                    <Plus className="w-5 h-5" />
                </button>
                 <button onClick={onBack} className="md:hidden p-2 hover:bg-gray-700 rounded-md">
                    <ArrowLeft className="w-5 h-5" />
                </button>
            </div>
        </div>

        {/* Chat Content */}
        <div className="flex-1 overflow-y-auto custom-scrollbar scroll-smooth">
            {messages.length === 0 ? (
                <div className="h-full flex flex-col items-center justify-center p-8 text-center animate-fadeIn">
                    <div className="bg-white/10 p-4 rounded-full mb-6">
                        <Sparkles className="w-10 h-10 text-white" />
                    </div>
                    <h2 className="text-2xl font-bold mb-8">NovaChat</h2>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4 max-w-2xl w-full">
                        {suggestions.map((s, i) => (
                            <button 
                                key={i}
                                onClick={() => { setInputText(`${s.title} ${s.subtitle}`); textareaRef.current?.focus(); }}
                                className="border border-white/20 rounded-xl p-4 text-left hover:bg-[#40414f] transition-colors"
                            >
                                <div className="font-semibold text-sm">{s.title}</div>
                                <div className="text-xs text-gray-400">{s.subtitle}</div>
                            </button>
                        ))}
                    </div>
                </div>
            ) : (
                <div className="flex flex-col pb-32">
                    {messages.map((msg) => (
                        <div 
                            key={msg.id} 
                            className={`w-full border-b border-black/10 dark:border-gray-900/50 ${
                                msg.role === 'model' ? 'bg-[#444654]' : 'bg-[#343541]'
                            }`}
                        >
                            <div className="max-w-3xl mx-auto flex gap-4 p-4 md:p-6 text-base">
                                <div className="flex-shrink-0 flex flex-col relative items-end">
                                    {msg.role === 'model' ? (
                                        <div className="w-8 h-8 bg-[#19c37d] rounded-sm flex items-center justify-center">
                                            <Bot className="w-5 h-5 text-white" />
                                        </div>
                                    ) : (
                                        <img 
                                            src="https://picsum.photos/150/150?random=1" 
                                            className="w-8 h-8 rounded-sm" 
                                            alt="User" 
                                        />
                                    )}
                                </div>
                                <div className="relative flex-1 overflow-hidden">
                                    <div className="prose prose-invert max-w-none">
                                        <MessageContent text={msg.text} />
                                    </div>
                                </div>
                            </div>
                        </div>
                    ))}
                    
                    {isTyping && (
                         <div className="w-full bg-[#444654] border-b border-black/10 dark:border-gray-900/50">
                            <div className="max-w-3xl mx-auto flex gap-4 p-4 md:p-6">
                                <div className="w-8 h-8 bg-[#19c37d] rounded-sm flex items-center justify-center">
                                    <Bot className="w-5 h-5 text-white" />
                                </div>
                                <div className="flex items-center gap-1">
                                    <span className="w-2 h-2 bg-gray-400 rounded-full animate-bounce"></span>
                                    <span className="w-2 h-2 bg-gray-400 rounded-full animate-bounce delay-75"></span>
                                    <span className="w-2 h-2 bg-gray-400 rounded-full animate-bounce delay-150"></span>
                                </div>
                            </div>
                        </div>
                    )}
                    <div ref={messagesEndRef} className="h-4" />
                </div>
            )}
        </div>

        {/* Input Area */}
        <div className="absolute bottom-0 left-0 w-full bg-gradient-to-t from-[#343541] via-[#343541] to-transparent pt-10 pb-20 md:pb-6 px-4">
            <div className="max-w-3xl mx-auto">
                {messages.length > 0 && !isTyping && (
                    <div className="flex justify-center mb-3">
                        <button 
                            onClick={handleRegenerate}
                            className="flex items-center gap-2 bg-[#444654] border border-white/20 text-xs px-3 py-2 rounded hover:bg-[#505260] transition-colors"
                        >
                            <RefreshCw className="w-3 h-3" /> Regenerate response
                        </button>
                    </div>
                )}
                
                <div className="relative flex items-end w-full p-3 bg-[#40414f] border border-black/10 dark:border-gray-900/50 rounded-xl shadow-xs overflow-hidden ring-offset-2 focus-within:ring-2 ring-blue-500/50">
                    <textarea
                        ref={textareaRef}
                        value={inputText}
                        onChange={(e) => setInputText(e.target.value)}
                        onKeyDown={(e) => {
                            if (e.key === 'Enter' && !e.shiftKey) {
                                e.preventDefault();
                                handleSend();
                            }
                        }}
                        placeholder="Send a message..."
                        className="w-full max-h-[200px] py-[2px] pr-10 bg-transparent border-none outline-none text-white resize-none scroll-p-2 placeholder-gray-400 custom-scrollbar"
                        rows={1}
                        style={{ minHeight: '24px' }}
                    />
                    <button 
                        onClick={handleSend}
                        disabled={!inputText.trim() || isTyping}
                        className={`absolute right-3 bottom-2.5 p-1 rounded-md transition-colors ${
                            inputText.trim() ? 'bg-[#19c37d] text-white hover:bg-[#15a96d]' : 'bg-transparent text-gray-500 cursor-default'
                        }`}
                    >
                        {isTyping ? <StopCircle className="w-4 h-4 animate-pulse" /> : <Send className="w-4 h-4" />}
                    </button>
                </div>
                <div className="text-center mt-2 hidden md:block">
                    <span className="text-[10px] text-gray-400">
                        NovaChat may display inaccurate info, including about people, so double-check its responses.
                    </span>
                </div>
            </div>
        </div>
      </div>
    </div>
  );
};