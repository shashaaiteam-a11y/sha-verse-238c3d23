import React, { useState, useRef, useEffect } from 'react';
import { ChatThread, DirectMessage, User } from '../types';
import { MOCK_CHATS } from '../constants';
import { 
    Search, MoreVertical, Phone, Video, Search as SearchIcon, 
    Smile, Paperclip, Mic, Send, Check, CheckCheck, ArrowLeft, Image as ImageIcon,
    Clock, Plus
} from 'lucide-react';

interface MessagesProps {
    currentUser: User;
    onBack: () => void;
    initialContactId?: string | null;
}

export const Messages: React.FC<MessagesProps> = ({ currentUser, onBack, initialContactId }) => {
    const [chats, setChats] = useState<ChatThread[]>(MOCK_CHATS);
    const [selectedChatId, setSelectedChatId] = useState<string | null>(null);
    const [newMessage, setNewMessage] = useState('');
    const [searchQuery, setSearchQuery] = useState('');
    const messagesEndRef = useRef<HTMLDivElement>(null);

    // Initialize chat selection based on prop
    useEffect(() => {
        if (initialContactId) {
            // Check if chat already exists
            const existingChat = chats.find(c => c.contactId === initialContactId);
            
            if (existingChat) {
                setSelectedChatId(existingChat.id);
            } else {
                // Find contact details from friends list to create a new (temporary) chat thread
                const contact = currentUser.friends?.find(f => f.id === initialContactId);
                if (contact) {
                    const newChatId = `chat_new_${Date.now()}`;
                    const newChat: ChatThread = {
                        id: newChatId,
                        contactId: contact.id,
                        contactName: contact.name,
                        contactAvatar: contact.avatar,
                        lastMessage: '',
                        lastMessageTime: Date.now(),
                        unreadCount: 0,
                        isOnline: false,
                        messages: []
                    };
                    setChats(prev => [newChat, ...prev]);
                    setSelectedChatId(newChatId);
                }
            }
        }
    }, [initialContactId, currentUser.friends]);

    // Filter chats
    const filteredChats = chats.filter(chat => 
        chat.contactName.toLowerCase().includes(searchQuery.toLowerCase())
    );

    const activeChat = chats.find(c => c.id === selectedChatId);

    // Scroll to bottom when messages change
    useEffect(() => {
        if (activeChat) {
            messagesEndRef.current?.scrollIntoView({ behavior: 'auto' });
        }
    }, [activeChat?.messages, selectedChatId]);

    const handleSendMessage = (e?: React.FormEvent) => {
        e?.preventDefault();
        if (!newMessage.trim() || !selectedChatId) return;

        const message: DirectMessage = {
            id: `msg_${Date.now()}`,
            senderId: currentUser.id,
            text: newMessage,
            timestamp: Date.now(),
            status: 'sent'
        };

        setChats(prevChats => prevChats.map(chat => {
            if (chat.id === selectedChatId) {
                return {
                    ...chat,
                    messages: [...chat.messages, message],
                    lastMessage: newMessage,
                    lastMessageTime: Date.now()
                };
            }
            return chat;
        }).sort((a, b) => b.lastMessageTime - a.lastMessageTime)); // Move updated chat to top

        setNewMessage('');
    };

    const formatTime = (timestamp: number) => {
        const date = new Date(timestamp);
        return date.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
    };

    const formatDate = (timestamp: number) => {
        const date = new Date(timestamp);
        const now = new Date();
        const diff = now.getTime() - date.getTime();
        
        if (diff < 86400000 && now.getDate() === date.getDate()) {
            return date.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
        }
        if (diff < 86400000 * 2) return 'Yesterday';
        return date.toLocaleDateString();
    };

    const handleBack = () => {
        if (selectedChatId) {
            setSelectedChatId(null);
        } else {
            onBack();
        }
    };

    // UI Components
    const ChatList = () => (
        <div className={`flex flex-col h-full bg-white border-r border-gray-200 ${selectedChatId ? 'hidden md:flex' : 'flex'} w-full md:w-[350px] lg:w-[400px]`}>
            {/* Header */}
            <div className="bg-[#f0f2f5] px-4 py-2.5 flex justify-between items-center border-b border-gray-200 h-[60px] flex-shrink-0">
                <div className="flex items-center">
                    <button onClick={onBack} className="md:hidden mr-3 text-gray-600 hover:bg-gray-200 p-1 rounded-full">
                        <ArrowLeft className="w-6 h-6" />
                    </button>
                    <img src={currentUser.avatar} alt="Me" className="w-10 h-10 rounded-full object-cover cursor-pointer" />
                </div>
                <div className="flex items-center gap-4 text-gray-600">
                    <div className="w-6 h-6 rounded-full border-2 border-dashed border-gray-500 flex items-center justify-center cursor-pointer" title="Status">
                        <div className="w-4 h-4 rounded-full border border-gray-400"></div>
                    </div>
                    <Plus className="w-6 h-6 cursor-pointer" />
                    <MoreVertical className="w-6 h-6 cursor-pointer" />
                </div>
            </div>

            {/* Search */}
            <div className="px-3 py-2 border-b border-gray-100">
                <div className="bg-[#f0f2f5] rounded-lg flex items-center px-3 py-1.5">
                    <Search className="w-5 h-5 text-gray-500 mr-3" />
                    <input 
                        type="text" 
                        placeholder="Search or start new chat" 
                        className="bg-transparent border-none outline-none text-sm w-full placeholder-gray-500"
                        value={searchQuery}
                        onChange={(e) => setSearchQuery(e.target.value)}
                    />
                </div>
            </div>

            {/* List */}
            <div className="flex-1 overflow-y-auto custom-scrollbar">
                {filteredChats.map(chat => (
                    <div 
                        key={chat.id} 
                        onClick={() => setSelectedChatId(chat.id)}
                        className={`flex items-center px-3 py-3 cursor-pointer hover:bg-[#f5f6f6] transition-colors border-b border-gray-100 ${selectedChatId === chat.id ? 'bg-[#f0f2f5]' : ''}`}
                    >
                        <div className="relative flex-shrink-0 mr-3">
                            <img src={chat.contactAvatar} alt={chat.contactName} className="w-12 h-12 rounded-full object-cover" />
                            {chat.isOnline && <div className="absolute bottom-0 right-0 w-3 h-3 bg-green-500 rounded-full border-2 border-white"></div>}
                        </div>
                        <div className="flex-1 min-w-0">
                            <div className="flex justify-between items-baseline mb-0.5">
                                <h3 className="text-gray-900 font-medium truncate">{chat.contactName}</h3>
                                <span className={`text-xs ${chat.unreadCount > 0 ? 'text-green-500 font-bold' : 'text-gray-500'}`}>
                                    {formatDate(chat.lastMessageTime)}
                                </span>
                            </div>
                            <div className="flex justify-between items-center">
                                <p className="text-sm text-gray-600 truncate flex-1 pr-2">
                                    {chat.lastMessage}
                                </p>
                                {chat.unreadCount > 0 && (
                                    <span className="bg-[#25D366] text-white text-[10px] font-bold px-1.5 h-5 min-w-[20px] rounded-full flex items-center justify-center">
                                        {chat.unreadCount}
                                    </span>
                                )}
                            </div>
                        </div>
                    </div>
                ))}
            </div>
        </div>
    );

    const ChatWindow = () => {
        if (!selectedChatId || !activeChat) {
            return (
                <div className="hidden md:flex flex-1 flex-col items-center justify-center bg-[#f0f2f5] border-b-[6px] border-[#25D366]">
                    <div className="text-center">
                        <h1 className="text-3xl font-light text-gray-700 mb-4">WhatsApp Web</h1>
                        <p className="text-gray-500 text-sm">Send and receive messages without keeping your phone online.</p>
                        <p className="text-gray-500 text-sm mt-1">Use WhatsApp on up to 4 linked devices and 1 phone.</p>
                    </div>
                </div>
            );
        }

        return (
            <div className={`flex-1 flex flex-col h-full bg-[#efeae2] relative ${selectedChatId ? 'flex' : 'hidden'}`}>
                {/* Chat Header */}
                <div className="bg-[#f0f2f5] px-4 py-2.5 flex justify-between items-center border-b border-gray-200 h-[60px]">
                    <div className="flex items-center">
                        <button onClick={handleBack} className="md:hidden mr-2 text-gray-600">
                            <ArrowLeft className="w-6 h-6" />
                        </button>
                        <img src={activeChat.contactAvatar} alt="Contact" className="w-10 h-10 rounded-full object-cover mr-3 cursor-pointer" />
                        <div className="cursor-pointer">
                            <h3 className="text-gray-900 font-medium leading-tight">{activeChat.contactName}</h3>
                            <p className="text-xs text-gray-500">
                                {activeChat.isOnline ? 'online' : 'click here for contact info'}
                            </p>
                        </div>
                    </div>
                    <div className="flex items-center gap-5 text-gray-600">
                        <Video className="w-5 h-5 cursor-pointer hidden sm:block" />
                        <Phone className="w-5 h-5 cursor-pointer hidden sm:block" />
                        <div className="w-px h-6 bg-gray-300 mx-1 hidden sm:block"></div>
                        <SearchIcon className="w-5 h-5 cursor-pointer" />
                        <MoreVertical className="w-5 h-5 cursor-pointer" />
                    </div>
                </div>

                {/* Messages Area */}
                <div className="flex-1 overflow-y-auto p-4 md:px-16 custom-scrollbar bg-[url('https://user-images.githubusercontent.com/15075759/28719144-86dc0f70-73b1-11e7-911d-60d70fcded21.png')] bg-repeat">
                    {/* Encryption Notice */}
                    <div className="flex justify-center mb-6">
                        <div className="bg-[#ffeecd] text-gray-800 text-[11px] px-3 py-1.5 rounded-lg shadow-sm text-center max-w-[90%]">
                            Messages are end-to-end encrypted. No one outside of this chat, not even WhatsApp, can read or listen to them.
                        </div>
                    </div>

                    {activeChat.messages.map((msg) => {
                        const isMe = msg.senderId === currentUser.id;
                        return (
                            <div key={msg.id} className={`flex mb-2 ${isMe ? 'justify-end' : 'justify-start'}`}>
                                <div 
                                    className={`relative max-w-[85%] md:max-w-[65%] px-3 py-1.5 rounded-lg shadow-sm text-sm ${
                                        isMe ? 'bg-[#d9fdd3] rounded-tr-none' : 'bg-white rounded-tl-none'
                                    }`}
                                >
                                    {msg.isAudio ? (
                                        <div className="flex items-center gap-3 pr-8 py-1">
                                            <div className="w-8 h-8 rounded-full bg-gray-300 flex items-center justify-center text-gray-500">
                                                <div className="w-0 h-0 border-t-[6px] border-t-transparent border-l-[10px] border-l-gray-600 border-b-[6px] border-b-transparent ml-1"></div>
                                            </div>
                                            <div className="flex flex-col">
                                                <div className="h-1 bg-gray-300 w-32 rounded-full mb-1">
                                                    <div className="h-full bg-blue-500 w-1/3 rounded-full"></div>
                                                </div>
                                                <span className="text-xs text-gray-500">{msg.duration}</span>
                                            </div>
                                            <div className="absolute bottom-3 right-0 w-3 h-3 bg-blue-500 rounded-full border-2 border-[#d9fdd3]"></div>
                                        </div>
                                    ) : (
                                        <p className="text-gray-900 pb-1 leading-relaxed">{msg.text}</p>
                                    )}
                                    
                                    <div className={`flex items-center justify-end gap-1 select-none ${isMe ? '-mt-1' : '-mt-1'}`}>
                                        <span className="text-[10px] text-gray-500 min-w-[40px] text-right">
                                            {formatTime(msg.timestamp)}
                                        </span>
                                        {isMe && (
                                            msg.status === 'read' ? <CheckCheck className="w-3.5 h-3.5 text-[#53bdeb]" /> :
                                            msg.status === 'delivered' ? <CheckCheck className="w-3.5 h-3.5 text-gray-400" /> :
                                            <Check className="w-3.5 h-3.5 text-gray-400" />
                                        )}
                                    </div>

                                    {/* Tail SVG */}
                                    <span className="absolute top-0 w-2 h-2">
                                        {isMe ? (
                                            <svg viewBox="0 0 8 13" height="13" width="8" className="absolute -right-[8px] top-0 text-[#d9fdd3] fill-current"><path d="M5.188 1H0v11.193l6.467-8.625C7.526 2.156 6.958 1 5.188 1z"></path><path fill="none" d="M5.188 1H0v11.193l6.467-8.625C7.526 2.156 6.958 1 5.188 1z"></path></svg>
                                        ) : (
                                            <svg viewBox="0 0 8 13" height="13" width="8" className="absolute -left-[8px] top-0 text-white fill-current scale-x-[-1]"><path d="M5.188 1H0v11.193l6.467-8.625C7.526 2.156 6.958 1 5.188 1z"></path><path fill="none" d="M5.188 1H0v11.193l6.467-8.625C7.526 2.156 6.958 1 5.188 1z"></path></svg>
                                        )}
                                    </span>
                                </div>
                            </div>
                        );
                    })}
                    <div ref={messagesEndRef} />
                </div>

                {/* Input Area */}
                <form onSubmit={handleSendMessage} className="bg-[#f0f2f5] px-4 py-2 flex items-center gap-3 pb-safe">
                    <button type="button" className="text-gray-500 hover:text-gray-700 hidden sm:block">
                        <Smile className="w-6 h-6" />
                    </button>
                    <button type="button" className="text-gray-500 hover:text-gray-700">
                        <Paperclip className="w-6 h-6" />
                    </button>
                    <div className="flex-1 bg-white rounded-lg px-4 py-2.5 shadow-sm">
                        <input
                            type="text"
                            placeholder="Type a message"
                            className="w-full bg-transparent border-none outline-none text-sm text-gray-900 placeholder-gray-500"
                            value={newMessage}
                            onChange={(e) => setNewMessage(e.target.value)}
                        />
                    </div>
                    {newMessage.trim() ? (
                        <button type="submit" className="text-gray-500 hover:text-gray-700">
                            <Send className="w-6 h-6" />
                        </button>
                    ) : (
                        <button type="button" className="text-gray-500 hover:text-gray-700">
                            <Mic className="w-6 h-6" />
                        </button>
                    )}
                </form>
            </div>
        );
    };

    return (
        <div className="h-full w-full flex overflow-hidden bg-gray-100 absolute inset-0 z-40">
            {/* White background container that mimics the web wrapper on desktop, full screen on mobile */}
            <div className="w-full h-full md:h-[calc(100vh-40px)] md:w-[calc(100vw-40px)] md:m-auto md:max-w-[1600px] flex shadow-lg overflow-hidden relative">
                <div className="absolute top-0 w-full h-[127px] bg-[#00a884] -z-10 hidden md:block"></div>
                <ChatList />
                <ChatWindow />
            </div>
        </div>
    );
};