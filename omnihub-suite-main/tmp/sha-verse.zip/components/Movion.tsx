import React, { useState } from 'react';
import { Video, MonetizationStats } from '../types';
import { Play, DollarSign, TrendingUp, Users, Clock, ThumbsUp, Share2, ArrowLeft } from 'lucide-react';
import { MOCK_VIDEOS } from '../constants';
import { ShaVerseLogo } from './ShaVerseLogo';

interface MovionProps {
    onBack: () => void;
}

export const Movion: React.FC<MovionProps> = ({ onBack }) => {
  const [activeVideo, setActiveVideo] = useState<Video | null>(null);
  const [showStudio, setShowStudio] = useState(false);
  
  // Mock Stats for "My Channel"
  const stats: MonetizationStats = {
    revenue: 12450.50,
    views: 4500000,
    subscribers: 125000,
    watchTimeHours: 85000
  };

  const handleVideoClick = (video: Video) => {
    setActiveVideo(video);
    document.getElementById('main-scroll-container')?.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const VideoPlayer = ({ video }: { video: Video }) => (
    <div className="bg-black w-full aspect-video relative flex items-center justify-center group cursor-pointer mb-4">
      <img src={video.thumbnail} className="w-full h-full object-cover opacity-80" alt="Playing" />
      <div className="absolute inset-0 flex items-center justify-center">
         <div className="bg-red-600 rounded-full p-4 shadow-lg animate-pulse">
            <Play className="w-8 h-8 text-white fill-current ml-1" />
         </div>
      </div>
      <div className="absolute bottom-4 left-4 right-4 h-1 bg-gray-600 rounded-full overflow-hidden">
         <div className="w-1/3 h-full bg-red-600"></div>
      </div>
      <div className="absolute top-4 right-4 bg-black/50 text-white px-2 py-1 rounded text-xs">
          Playing: {video.title}
      </div>
    </div>
  );

  return (
    <div className="bg-gray-100 min-h-full pb-24">
      {/* Header */}
      <div className="bg-white shadow-sm px-4 py-3 sticky top-0 z-30 flex justify-between items-center">
         <div className="flex items-center gap-2">
            <button onClick={onBack} className="md:hidden mr-1 text-gray-600 hover:bg-gray-100 p-1 rounded-full">
                <ArrowLeft className="w-6 h-6" />
            </button>
            <ShaVerseLogo className="w-9 h-9" />
            <div className="flex flex-col">
                 <div className="flex items-center gap-1">
                    <div className="bg-red-600 p-0.5 rounded-sm">
                        <Play className="w-3 h-3 text-white fill-current" />
                    </div>
                    <h1 className="text-xl font-bold text-gray-900 tracking-tight leading-none">Movion</h1>
                 </div>
                 <span className="text-[10px] text-gray-500 font-medium leading-none mt-0.5">Sha-Verse</span>
            </div>
         </div>
         <button 
            onClick={() => setShowStudio(true)}
            className="flex items-center gap-1 bg-green-100 text-green-700 px-3 py-1.5 rounded-full font-semibold text-sm hover:bg-green-200 transition-colors"
         >
            <DollarSign className="w-4 h-4" />
            <span className="hidden sm:inline">Studio</span>
         </button>
      </div>

      {/* Monetization Modal */}
      {showStudio && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm animate-fadeIn">
           <div className="bg-white rounded-xl shadow-2xl w-full max-w-2xl overflow-hidden max-h-[80vh] overflow-y-auto">
               <div className="flex justify-between items-center p-6 border-b sticky top-0 bg-white">
                  <h2 className="text-2xl font-bold text-gray-800">Creator Studio</h2>
                  <button onClick={() => setShowStudio(false)} className="text-gray-500 hover:text-gray-800">Close</button>
               </div>
               <div className="p-6">
                   <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
                       <div className="bg-green-50 p-6 rounded-xl border border-green-100">
                           <div className="flex items-center gap-3 mb-2">
                               <div className="bg-green-500 p-2 rounded-lg text-white"><DollarSign className="w-6 h-6" /></div>
                               <span className="text-green-800 font-semibold">Estimated Revenue</span>
                           </div>
                           <h3 className="text-3xl font-bold text-gray-900">${stats.revenue.toLocaleString()}</h3>
                           <p className="text-green-600 text-sm mt-1">+12% from last month</p>
                       </div>
                       <div className="bg-blue-50 p-6 rounded-xl border border-blue-100">
                           <div className="flex items-center gap-3 mb-2">
                               <div className="bg-blue-500 p-2 rounded-lg text-white"><TrendingUp className="w-6 h-6" /></div>
                               <span className="text-blue-800 font-semibold">Total Views</span>
                           </div>
                           <h3 className="text-3xl font-bold text-gray-900">{stats.views.toLocaleString()}</h3>
                           <p className="text-blue-600 text-sm mt-1">Real-time analytics</p>
                       </div>
                       <div className="bg-purple-50 p-6 rounded-xl border border-purple-100">
                           <div className="flex items-center gap-3 mb-2">
                               <div className="bg-purple-500 p-2 rounded-lg text-white"><Users className="w-6 h-6" /></div>
                               <span className="text-purple-800 font-semibold">Subscribers</span>
                           </div>
                           <h3 className="text-3xl font-bold text-gray-900">{stats.subscribers.toLocaleString()}</h3>
                       </div>
                       <div className="bg-orange-50 p-6 rounded-xl border border-orange-100">
                           <div className="flex items-center gap-3 mb-2">
                               <div className="bg-orange-500 p-2 rounded-lg text-white"><Clock className="w-6 h-6" /></div>
                               <span className="text-orange-800 font-semibold">Watch Time (Hours)</span>
                           </div>
                           <h3 className="text-3xl font-bold text-gray-900">{stats.watchTimeHours.toLocaleString()}</h3>
                       </div>
                   </div>
                   <div className="bg-gray-50 p-4 rounded-lg text-center">
                       <p className="text-gray-600 text-sm">Monetization is active. Payments are processed on the 21st of each month.</p>
                   </div>
               </div>
           </div>
        </div>
      )}

      {/* Main Content */}
      <div className="max-w-4xl mx-auto p-0 md:p-4">
        {activeVideo && (
           <div className="mb-6 bg-white md:rounded-xl overflow-hidden shadow-sm">
               <VideoPlayer video={activeVideo} />
               <div className="p-4">
                   <h2 className="text-xl font-bold text-gray-900 mb-2">{activeVideo.title}</h2>
                   <div className="flex justify-between items-center mb-4">
                       <span className="text-gray-600 text-sm">{activeVideo.views.toLocaleString()} views • {activeVideo.uploadedAt}</span>
                       <div className="flex gap-4">
                           <button className="flex items-center gap-1 text-gray-700 font-semibold hover:bg-gray-100 px-3 py-1 rounded-full"><ThumbsUp className="w-5 h-5" /> Like</button>
                           <button className="flex items-center gap-1 text-gray-700 font-semibold hover:bg-gray-100 px-3 py-1 rounded-full"><Share2 className="w-5 h-5" /> Share</button>
                       </div>
                   </div>
                   <div className="flex items-center justify-between border-t border-b border-gray-100 py-3">
                       <div className="flex items-center gap-3">
                           <img src={activeVideo.channelAvatar} className="w-10 h-10 rounded-full" alt="Channel" />
                           <div>
                               <h3 className="font-bold text-gray-900 text-sm">{activeVideo.channelName}</h3>
                               <p className="text-xs text-gray-500">250K subscribers</p>
                           </div>
                       </div>
                       <button className="bg-black text-white px-4 py-2 rounded-full font-semibold text-sm hover:bg-gray-800">Subscribe</button>
                   </div>
               </div>
           </div>
        )}

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 px-4 md:px-0">
            {MOCK_VIDEOS.map(video => (
                <div key={video.id} onClick={() => handleVideoClick(video)} className="bg-white rounded-xl shadow-sm overflow-hidden cursor-pointer group hover:shadow-md transition-shadow">
                    <div className="relative aspect-video">
                        <img src={video.thumbnail} alt={video.title} className="w-full h-full object-cover" />
                        <div className="absolute bottom-2 right-2 bg-black/80 text-white text-xs px-1.5 py-0.5 rounded font-medium">
                            {video.duration}
                        </div>
                    </div>
                    <div className="p-3 flex gap-3">
                        <img src={video.channelAvatar} className="w-9 h-9 rounded-full mt-1" alt="Channel" />
                        <div>
                            <h3 className="font-semibold text-gray-900 leading-tight mb-1 line-clamp-2 group-hover:text-blue-600 transition-colors">{video.title}</h3>
                            <div className="text-xs text-gray-500">
                                <p>{video.channelName}</p>
                                <p>{video.views.toLocaleString()} views • {video.uploadedAt}</p>
                            </div>
                        </div>
                    </div>
                </div>
            ))}
        </div>
      </div>
    </div>
  );
};