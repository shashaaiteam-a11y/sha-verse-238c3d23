
import React, { useState, useRef } from 'react';
import { Post, Comment, User, ReactionType } from '../types';
import { 
    ThumbsUp, MessageCircle, Share2, Send, MoreHorizontal, Edit2, X, 
    Reply, BadgeCheck, Heart, Smile, Frown, AlertCircle, Trash2, Copy, Send as SendIcon, Rss, ArrowDown, PlusCircle
} from 'lucide-react';

interface PostCardProps {
  post: Post;
  currentUser: User;
  onLike: (postId: string, reaction: ReactionType) => void;
  onComment: (postId: string, text: string) => void;
  onVote?: (postId: string, optionId: string) => void;
  onEditPost: (postId: string, content: string) => void;
  onDeletePost: (postId: string) => void;
  onLikeComment: (postId: string, commentId: string) => void;
}

export const PostCard: React.FC<PostCardProps> = ({ post, currentUser, onLike, onComment, onVote, onEditPost, onDeletePost, onLikeComment }) => {
  const [commentText, setCommentText] = useState('');
  const [showComments, setShowComments] = useState(false);
  const [isEditing, setIsEditing] = useState(false);
  const [editContent, setEditContent] = useState(post.content);
  const [showMenu, setShowMenu] = useState(false);
  const [showShareMenu, setShowShareMenu] = useState(false);
  const [isDeleteModalOpen, setIsDeleteModalOpen] = useState(false);
  const [isSaveModalOpen, setIsSaveModalOpen] = useState(false);
  
  const commentInputRef = useRef<HTMLInputElement>(null);

  const handleCommentSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (commentText.trim()) {
      onComment(post.id, commentText);
      setCommentText('');
      setShowComments(true);
    }
  };

  const handleCopyLink = async () => {
      const shareUrl = `https://shaverse.app/post/${post.id}`;
      try {
          await navigator.clipboard.writeText(shareUrl);
          alert('Link copied to clipboard!');
      } catch (err) {
          console.error('Failed to copy', err);
      }
      setShowShareMenu(false);
  };

  const handleShareToFeed = () => {
      alert("Shared to your feed! (Simulated)");
      setShowShareMenu(false);
  };

  const handleShareToStory = () => {
      alert("Added to your story! (Simulated)");
      setShowShareMenu(false);
  };

  const handleShareToMessage = () => {
      alert("Sent in message! (Simulated)");
      setShowShareMenu(false);
  };

  const handleSaveClick = () => {
    if (editContent.trim() !== '') {
      setIsSaveModalOpen(true);
    }
  };

  const confirmSaveEdit = () => {
      onEditPost(post.id, editContent);
      setIsEditing(false);
      setShowMenu(false);
      setIsSaveModalOpen(false);
  };

  const handleDeleteClick = () => {
      setIsDeleteModalOpen(true);
      setShowMenu(false);
  };

  const confirmDelete = () => {
      onDeletePost(post.id);
      setIsDeleteModalOpen(false);
  };

  const handleReplyTo = (userName: string) => {
      setCommentText(`@${userName} `);
      setShowComments(true);
      setTimeout(() => commentInputRef.current?.focus(), 100);
  }

  const handleTimestampClick = (e: React.MouseEvent) => {
      e.preventDefault();
      setShowComments(true);
      setTimeout(() => {
          const commentsSection = document.getElementById(`comments-${post.id}`);
          if (commentsSection) {
              commentsSection.scrollIntoView({ behavior: 'smooth', block: 'start' });
          } else {
             // If no comments yet, scroll to the input area
             commentInputRef.current?.scrollIntoView({ behavior: 'smooth', block: 'center' });
             commentInputRef.current?.focus();
          }
      }, 100);
  };

  const formatTime = (timestamp: number) => {
    const diff = Date.now() - timestamp;
    const minutes = Math.floor(diff / 60000);
    const hours = Math.floor(diff / 3600000);
    const days = Math.floor(diff / 86400000);

    if (minutes < 1) return 'Just now';
    if (minutes < 60) return `${minutes}m`;
    if (hours < 24) return `${hours}h`;
    return `${days}d`;
  };

  const getReactionIcon = (type: ReactionType) => {
      switch (type) {
          case 'like': return <ThumbsUp className="w-5 h-5 text-blue-600 fill-current" />;
          case 'love': return <Heart className="w-5 h-5 text-red-500 fill-current" />;
          case 'haha': return <Smile className="w-5 h-5 text-yellow-500 fill-current" />;
          case 'wow': return <AlertCircle className="w-5 h-5 text-orange-500 fill-current" />;
          case 'sad': return <Frown className="w-5 h-5 text-yellow-600 fill-current" />;
          case 'angry': return <Frown className="w-5 h-5 text-red-600 fill-current" />;
          default: return <ThumbsUp className="w-5 h-5 text-gray-500" />;
      }
  };

  const getReactionTextColor = (type: ReactionType) => {
      switch (type) {
          case 'like': return 'text-blue-600';
          case 'love': return 'text-red-500';
          case 'haha': return 'text-yellow-500';
          case 'wow': return 'text-orange-500';
          case 'sad': return 'text-yellow-600';
          case 'angry': return 'text-red-600';
          default: return 'text-blue-600';
      }
  };

  const getTotalReactions = (): number => {
      if (!post.reactions) return 0;
      return (Object.values(post.reactions) as number[]).reduce((a: number, b: number) => a + b, 0);
  };

  const isOwner = currentUser.id === post.userId;
  // 15 minutes = 15 * 60 * 1000 ms
  const canEdit = isOwner && (Date.now() - post.timestamp < 15 * 60 * 1000);

  // --- Render Media Grid ---
  const renderMedia = () => {
      if (!post.mediaUrls || post.mediaUrls.length === 0) return null;

      const count = post.mediaUrls.length;
      
      if (count === 1) {
          if (post.type === 'video' || post.type === 'reel') {
               return (
                  <video 
                    src={post.mediaUrls[0]} 
                    controls 
                    className={`max-h-[500px] w-auto ${post.type === 'reel' ? 'aspect-[9/16]' : 'w-full'}`} 
                />
               );
          }
          return <img src={post.mediaUrls[0]} alt="Post" className="w-full h-auto object-contain max-h-[500px]" />;
      }

      // Grid Layout for multiple images
      return (
          <div className={`grid gap-1 ${count === 2 ? 'grid-cols-2' : 'grid-cols-2'}`}>
              {post.mediaUrls.slice(0, 4).map((url, index) => {
                  // Logic for 3 items (first one spans full height or width)
                  let className = "relative aspect-square overflow-hidden cursor-pointer";
                  if (count === 3 && index === 0) className += " row-span-2 h-full";
                  
                  return (
                      <div key={index} className={className}>
                          <img src={url} className="w-full h-full object-cover hover:opacity-90 transition-opacity" alt={`Gallery ${index}`} />
                          {count > 4 && index === 3 && (
                              <div className="absolute inset-0 bg-black/50 flex items-center justify-center text-white font-bold text-xl">
                                  +{count - 4}
                              </div>
                          )}
                      </div>
                  );
              })}
          </div>
      );
  };

  return (
    <div className="bg-white p-4 mb-4 shadow-sm md:rounded-lg relative">
      {/* Delete Confirmation Modal */}
      {isDeleteModalOpen && (
          <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 backdrop-blur-sm p-4 animate-fadeIn">
              <div className="bg-white rounded-lg p-6 max-w-sm w-full shadow-xl">
                  <h3 className="text-lg font-bold text-gray-900 mb-2">Delete Post?</h3>
                  <p className="text-gray-600 mb-6">Are you sure you want to delete this post? This action cannot be undone.</p>
                  <div className="flex justify-end gap-3">
                      <button 
                        onClick={() => setIsDeleteModalOpen(false)}
                        className="px-4 py-2 text-gray-600 font-semibold hover:bg-gray-100 rounded-lg"
                      >
                          Cancel
                      </button>
                      <button 
                        onClick={confirmDelete}
                        className="px-4 py-2 bg-red-600 text-white font-semibold hover:bg-red-700 rounded-lg"
                      >
                          Delete
                      </button>
                  </div>
              </div>
          </div>
      )}

      {/* Save Edit Confirmation Modal */}
      {isSaveModalOpen && (
          <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 backdrop-blur-sm p-4 animate-fadeIn">
              <div className="bg-white rounded-lg p-6 max-w-sm w-full shadow-xl">
                  <h3 className="text-lg font-bold text-gray-900 mb-2">Save Changes?</h3>
                  <p className="text-gray-600 mb-6">Are you sure you want to save changes to this post?</p>
                  <div className="flex justify-end gap-3">
                      <button 
                        onClick={() => setIsSaveModalOpen(false)}
                        className="px-4 py-2 text-gray-600 font-semibold hover:bg-gray-100 rounded-lg"
                      >
                          Cancel
                      </button>
                      <button 
                        onClick={confirmSaveEdit}
                        className="px-4 py-2 bg-blue-600 text-white font-semibold hover:bg-blue-700 rounded-lg"
                      >
                          Save
                      </button>
                  </div>
              </div>
          </div>
      )}

      {/* Header */}
      <div className="flex items-start justify-between mb-3 relative">
        <div className="flex items-center">
          <img
            src={post.userAvatar}
            alt={post.userName}
            className="w-10 h-10 rounded-full mr-3 object-cover border border-gray-200"
          />
          <div>
            <h3 className="font-semibold text-gray-900 text-sm flex items-center">
                {post.userName}
                {post.userIsVerified && (
                    <BadgeCheck className="w-4 h-4 text-blue-500 ml-1" fill="currentColor" color="white" />
                )}
            </h3>
            <div className="flex items-center text-gray-500 text-xs gap-1">
                <button onClick={handleTimestampClick} className="hover:underline hover:text-gray-700">
                    {formatTime(post.timestamp)}
                </button>
                <button 
                    onClick={handleTimestampClick}
                    className="ml-0.5 p-0.5 hover:bg-gray-100 rounded text-gray-400 hover:text-blue-500 transition-colors"
                    title="Jump to comments"
                >
                    <ArrowDown className="w-3 h-3" />
                </button>
                {post.isEdited && <span>• Edited</span>}
                {post.type === 'poll' && <span className="bg-orange-100 text-orange-700 px-1 rounded ml-1">Poll</span>}
                {post.type === 'reel' && <span className="bg-pink-100 text-pink-700 px-1 rounded ml-1">Reel</span>}
            </div>
          </div>
        </div>
        
        {isOwner && (
            <div>
                <button onClick={() => setShowMenu(!showMenu)} className="p-1 hover:bg-gray-100 rounded-full">
                    <MoreHorizontal className="w-5 h-5 text-gray-500" />
                </button>
                {showMenu && (
                    <div className="absolute right-0 top-8 bg-white shadow-lg border border-gray-100 rounded-lg p-1 z-10 w-40 animate-fadeIn">
                        {canEdit ? (
                            <button 
                                onClick={() => { setIsEditing(true); setShowMenu(false); }}
                                className="w-full text-left px-3 py-2 text-sm hover:bg-gray-50 flex items-center gap-2 rounded text-gray-700"
                            >
                                <Edit2 className="w-4 h-4" /> Edit Post
                            </button>
                        ) : (
                            <div className="px-3 py-2 text-xs text-gray-400 italic text-center border-b border-gray-100 mb-1">
                                Edit expired
                            </div>
                        )}
                        <button 
                            onClick={handleDeleteClick}
                            className="w-full text-left px-3 py-2 text-sm hover:bg-red-50 flex items-center gap-2 rounded text-red-600"
                        >
                            <Trash2 className="w-4 h-4" /> Delete Post
                        </button>
                    </div>
                )}
            </div>
        )}
      </div>

      {/* Content */}
      {isEditing ? (
          <div className="mb-4">
              <textarea 
                value={editContent}
                onChange={(e) => setEditContent(e.target.value)}
                className="w-full bg-gray-50 border border-gray-300 rounded-lg p-2 text-sm focus:ring-2 focus:ring-blue-500 outline-none"
                rows={3}
              />
              <div className="flex justify-end gap-2 mt-2">
                  <button onClick={() => setIsEditing(false)} className="px-3 py-1 text-sm text-gray-600 hover:bg-gray-100 rounded">Cancel</button>
                  <button onClick={handleSaveClick} className="px-3 py-1 text-sm bg-blue-600 text-white rounded hover:bg-blue-700">Save</button>
              </div>
          </div>
      ) : (
        <div className="mb-3 text-gray-800 whitespace-pre-wrap text-[15px] md:text-[16px] leading-relaxed font-normal">
            {post.content}
        </div>
      )}

      {/* Media Attachment */}
      {post.mediaUrls && post.mediaUrls.length > 0 && (
        <div className="mb-3 -mx-4 md:mx-0 bg-black flex justify-center md:rounded-lg overflow-hidden">
            <div className="w-full">{renderMedia()}</div>
        </div>
      )}

      {/* Poll Rendering */}
      {post.type === 'poll' && post.pollOptions && (
          <div className="mb-4 space-y-2">
              {post.pollOptions.map(option => {
                  const percentage = post.totalVotes ? Math.round((option.votes / post.totalVotes) * 100) : 0;
                  const isVoted = post.votedOptionId === option.id;
                  
                  return (
                      <div 
                        key={option.id} 
                        onClick={() => onVote && onVote(post.id, option.id)}
                        className={`relative border rounded-lg p-3 cursor-pointer transition-all overflow-hidden ${isVoted ? 'border-blue-500 bg-blue-50' : 'border-gray-200 hover:bg-gray-50'}`}
                      >
                          {/* Progress Bar Background */}
                          <div 
                            className="absolute top-0 left-0 bottom-0 bg-blue-100 transition-all duration-500 ease-out z-0"
                            style={{ width: `${percentage}%`, opacity: 0.5 }}
                          ></div>
                          
                          <div className="relative z-10 flex justify-between items-center">
                              <span className={`font-medium ${isVoted ? 'text-blue-700' : 'text-gray-800'}`}>{option.text}</span>
                              <span className="text-sm text-gray-500">{percentage}%</span>
                          </div>
                      </div>
                  );
              })}
              <div className="text-xs text-gray-500 text-right">{post.totalVotes} votes</div>
          </div>
      )}

      {/* Stats Row */}
      <div className="flex justify-between items-center text-gray-500 text-xs mb-3 px-1">
        <div className="flex items-center cursor-pointer hover:underline gap-1">
          {getTotalReactions() > 0 && (
              <div className="flex -space-x-1">
                 {/* Show top 3 distinct reaction icons present on the post */}
                 {post.reactions && (Object.entries(post.reactions) as [string, number][])
                    .filter(([_, count]) => count > 0)
                    .sort((a, b) => b[1] - a[1]) // Sort by count desc
                    .slice(0, 3)
                    .map(([type, count]) => (
                        <div key={type} className="bg-white rounded-full p-[1px] relative z-10" title={`${count} ${type}s`}>
                            {getReactionIcon(type as ReactionType)}
                        </div>
                    ))
                 }
              </div>
          )}
          <span>{getTotalReactions() > 0 ? getTotalReactions() : ''}</span>
        </div>
        <div>
          <span className="cursor-pointer hover:underline" onClick={() => setShowComments(!showComments)}>
            {post.comments.length} comments
          </span>
        </div>
      </div>

      <div className="border-t border-gray-100 mb-2"></div>

      {/* Action Buttons */}
      <div className="flex justify-between items-center mb-2 relative">
        {/* Like Button Container with Hover Reaction Bar */}
        <div className="flex-1 group relative">
             {/* Reaction Popover */}
             <div className="hidden group-hover:flex absolute bottom-full left-0 mb-2 bg-white shadow-xl border border-gray-200 rounded-full p-2 gap-2 animate-fadeIn z-20">
                 {(['like', 'love', 'haha', 'wow', 'sad', 'angry'] as ReactionType[]).map((type) => (
                     <button 
                        key={type} 
                        onClick={() => onLike(post.id, type)}
                        className="hover:scale-125 transition-transform p-1"
                        title={type}
                    >
                         {getReactionIcon(type)}
                     </button>
                 ))}
             </div>
             <button
                onClick={() => onLike(post.id, 'like')}
                className={`w-full flex items-center justify-center py-2 rounded hover:bg-gray-50 transition-colors ${
                    post.currentUserReaction ? getReactionTextColor(post.currentUserReaction) + ' font-semibold' : 'text-gray-600'
                }`}
            >
                {post.currentUserReaction ? getReactionIcon(post.currentUserReaction) : <ThumbsUp className="w-5 h-5 mr-2" />}
                <span className="text-sm ml-2 capitalize">{post.currentUserReaction || 'Like'}</span>
            </button>
        </div>

        <button
          onClick={() => {
              setShowComments(true);
              setTimeout(() => commentInputRef.current?.focus(), 100);
          }}
          className="flex-1 flex items-center justify-center py-2 rounded hover:bg-gray-50 text-gray-600 transition-colors"
        >
          <MessageCircle className="w-5 h-5 mr-2" />
          <span className="text-sm">Comment</span>
        </button>

        <div className="flex-1 relative">
            <button 
                onClick={() => setShowShareMenu(!showShareMenu)}
                className="w-full flex items-center justify-center py-2 rounded hover:bg-gray-50 text-gray-600 transition-colors"
            >
                <Share2 className="w-5 h-5 mr-2" />
                <span className="text-sm">Share</span>
            </button>
            {/* Share Menu Dropdown */}
            {showShareMenu && (
                <div className="absolute right-0 bottom-full mb-2 bg-white shadow-lg border border-gray-100 rounded-lg p-1 z-10 w-48 animate-fadeIn">
                    <button onClick={handleShareToFeed} className="w-full text-left px-3 py-2 text-sm hover:bg-gray-50 flex items-center gap-2 rounded text-gray-700">
                        <Rss className="w-4 h-4" /> Share to Feed
                    </button>
                    <button onClick={handleShareToStory} className="w-full text-left px-3 py-2 text-sm hover:bg-gray-50 flex items-center gap-2 rounded text-gray-700">
                        <PlusCircle className="w-4 h-4" /> Share to Story
                    </button>
                    <button onClick={handleShareToMessage} className="w-full text-left px-3 py-2 text-sm hover:bg-gray-50 flex items-center gap-2 rounded text-gray-700">
                        <SendIcon className="w-4 h-4" /> Send in Message
                    </button>
                    <button onClick={handleCopyLink} className="w-full text-left px-3 py-2 text-sm hover:bg-gray-50 flex items-center gap-2 rounded text-gray-700">
                        <Copy className="w-4 h-4" /> Copy Link
                    </button>
                </div>
            )}
        </div>
      </div>

      {/* Comment Section */}
      {showComments && (
        <div id={`comments-${post.id}`} className="mt-2">
          {post.comments.map((comment) => (
            <div key={comment.id} className="flex items-start mb-3 animate-fadeIn">
              <img
                src={comment.userAvatar}
                alt={comment.userName}
                className="w-8 h-8 rounded-full mr-2 object-cover"
              />
              <div className="flex-1 group">
                <div className="bg-gray-100 rounded-2xl px-3 py-2 inline-block">
                  <span className="font-semibold text-xs block text-gray-900">{comment.userName}</span>
                  <span className="text-sm text-gray-800">{comment.text}</span>
                </div>
                <div className="text-xs text-gray-500 mt-1 ml-2 flex gap-3">
                  <span>{formatTime(comment.timestamp)}</span>
                  <button 
                    onClick={() => onLikeComment(post.id, comment.id)} 
                    className={`font-semibold hover:underline ${comment.isLikedByCurrentUser ? 'text-blue-600' : ''}`}
                  >
                      Like {comment.likes > 0 && `(${comment.likes})`}
                  </button>
                  <button onClick={() => handleReplyTo(comment.userName)} className="font-semibold hover:underline">Reply</button>
                </div>
              </div>
            </div>
          ))}

          {/* Comment Input */}
          <form onSubmit={handleCommentSubmit} className="flex items-center mt-3 relative">
            <img
              src={currentUser.avatar}
              alt="You"
              className="w-8 h-8 rounded-full mr-2 object-cover"
            />
            <div className="flex-1 relative">
              <input
                ref={commentInputRef}
                type="text"
                placeholder="Write a comment..."
                className="w-full bg-gray-100 border-none rounded-full py-2 px-4 pr-10 focus:ring-2 focus:ring-blue-200 outline-none text-sm transition-all"
                value={commentText}
                onChange={(e) => setCommentText(e.target.value)}
              />
              <button
                type="submit"
                disabled={!commentText.trim()}
                className="absolute right-2 top-1/2 transform -translate-y-1/2 text-blue-600 disabled:text-gray-400 p-1"
              >
                <Send className="w-4 h-4" />
              </button>
            </div>
          </form>
        </div>
      )}
    </div>
  );
};
