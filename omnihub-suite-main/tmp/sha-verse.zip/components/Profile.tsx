
import React, { useState } from 'react';
import { User, Post, PostType, ReactionType } from '../types';
import { PostCard } from './PostCard';
import { CreatePost } from './CreatePost';
import { 
  Briefcase, GraduationCap, MapPin, Heart, Clock, 
  MoreHorizontal, Plus, PenSquare, MessageCircle, Camera, Search, ChevronDown, X, Upload, AlertCircle,
  Globe, Phone, Mail, Grid, Image as ImageIcon, Users, UserMinus, Gamepad, Coffee, Code, Music, CheckCircle, Loader2, ArrowLeft
} from 'lucide-react';
import { ShaVerseLogo } from './ShaVerseLogo';

interface ProfileProps {
  user: User;
  posts: Post[];
  currentUser: User;
  onLike: (postId: string, reaction: ReactionType) => void;
  onComment: (postId: string, text: string) => void;
  onCreatePost: (content: string, mediaUrl?: string, type?: PostType, pollOptions?: string[]) => void;
  onUpdateUser: (updatedFields: Partial<User>) => void;
  onVote: (postId: string, optionId: string) => void;
  onEditPost: (postId: string, content: string) => void;
  onDeletePost: (postId: string) => void;
  onLikeComment: (postId: string, commentId: string) => void;
  onBack: () => void;
  onMessage: (userId: string) => void;
}

type Tab = 'POSTS' | 'ABOUT' | 'FRIENDS' | 'PHOTOS';
type AboutSubTab = 'OVERVIEW' | 'WORK_EDU' | 'PLACES' | 'CONTACT';

const AVAILABLE_HOBBIES = [
    'Photography', 'Traveling', 'Cooking', 'Gaming', 'Reading', 'Music', 'Hiking', 'Coding', 'Art', 'Fitness', 'Coffee', 'Sci-Fi'
];

export const Profile: React.FC<ProfileProps> = ({ 
  user, posts, currentUser, onLike, onComment, onCreatePost, onUpdateUser, onVote, onEditPost, onDeletePost, onLikeComment, onBack, onMessage
}) => {
  const [activeTab, setActiveTab] = useState<Tab>('POSTS');
  const [activeAboutTab, setActiveAboutTab] = useState<AboutSubTab>('OVERVIEW');
  const [isCoverModalOpen, setCoverModalOpen] = useState(false);
  const [tempCoverUrl, setTempCoverUrl] = useState('');
  
  // Hobbies State
  const [isHobbiesModalOpen, setHobbiesModalOpen] = useState(false);
  const [selectedHobbies, setSelectedHobbies] = useState<string[]>(user.hobbies || []);

  // Edit Details State
  const [isEditDetailsModalOpen, setEditDetailsModalOpen] = useState(false);
  const [editFormData, setEditFormData] = useState<Partial<User>>({});
  
  // Confirmation Dialog State
  const [isConfirmSaveOpen, setConfirmSaveOpen] = useState(false);

  // Story Simulation
  const [isPostingStory, setIsPostingStory] = useState(false);

  // Friends Search
  const [friendSearchQuery, setFriendSearchQuery] = useState('');

  const isOwnProfile = user.id === currentUser.id;
  const userPosts = posts.filter(p => p.userId === user.id);

  // --- Story Handler ---
  const handleAddToStory = () => {
      setIsPostingStory(true);
      setTimeout(() => {
          setIsPostingStory(false);
          alert("Story posted successfully! (Simulation)");
      }, 1500);
  };

  // --- Cover Photo Handlers ---
  const handleCoverFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setTempCoverUrl(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleSaveCover = () => {
    if (tempCoverUrl) {
      onUpdateUser({ coverPhoto: tempCoverUrl });
      setCoverModalOpen(false);
      setTempCoverUrl('');
    }
  };

  const openCoverModal = () => {
    setTempCoverUrl(user.coverPhoto || '');
    setCoverModalOpen(true);
  };

  // --- Photo Upload (Gallery) ---
  const handleGalleryUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
      const file = e.target.files?.[0];
      if (file) {
          const reader = new FileReader();
          reader.onloadend = () => {
              const newPhoto = reader.result as string;
              onUpdateUser({ photos: [newPhoto, ...(user.photos || [])] });
          };
          reader.readAsDataURL(file);
      }
  };

  // --- Hobbies Handlers ---
  const toggleHobby = (hobby: string) => {
      if (selectedHobbies.includes(hobby)) {
          setSelectedHobbies(selectedHobbies.filter(h => h !== hobby));
      } else {
          setSelectedHobbies([...selectedHobbies, hobby]);
      }
  };

  const saveHobbies = () => {
      onUpdateUser({ hobbies: selectedHobbies });
      setHobbiesModalOpen(false);
  };

  // --- Edit Details Handlers ---
  const openEditDetailsModal = () => {
    setEditFormData({
      bio: user.bio || '',
      work: user.work || '',
      education: user.education || '',
      location: user.location || '',
      hometown: user.hometown || '',
      relationshipStatus: user.relationshipStatus || 'Single',
    });
    setEditDetailsModalOpen(true);
  };

  const handleDetailsChange = (field: keyof User, value: string) => {
    setEditFormData(prev => ({ ...prev, [field]: value }));
  };

  const handleSaveButtonClick = () => {
    setConfirmSaveOpen(true);
  };

  const handleConfirmSave = () => {
    onUpdateUser(editFormData);
    setEditDetailsModalOpen(false);
    setConfirmSaveOpen(false);
  };

  // --- Components for Sections ---

  const IntroCard = () => (
    <div className="bg-white p-4 rounded-lg shadow-sm border border-gray-100 mb-4">
      <h3 className="font-bold text-lg text-gray-900 mb-4">Intro</h3>
      <div className="space-y-3 text-sm text-gray-700">
        {user.bio && <p className="text-center text-gray-900 mb-4">{user.bio}</p>}
        <div className="h-px bg-gray-200 my-3"></div>
        {user.work && (
            <div className="flex items-center gap-2">
                <Briefcase className="w-5 h-5 text-gray-400" />
                <span>Works at <strong>{user.work.includes(' at ') ? user.work.split(' at ')[1] : user.work}</strong></span>
            </div>
        )}
        {user.education && (
            <div className="flex items-center gap-2">
                <GraduationCap className="w-5 h-5 text-gray-400" />
                <span>Studied at <strong>{user.education.includes(' at ') ? user.education.split(' at ')[1] : user.education}</strong></span>
            </div>
        )}
        {user.location && (
            <div className="flex items-center gap-2">
                <MapPin className="w-5 h-5 text-gray-400" />
                <span>Lives in <strong>{user.location}</strong></span>
            </div>
        )}
         {user.hometown && (
            <div className="flex items-center gap-2">
                <MapPin className="w-5 h-5 text-gray-400" />
                <span>From <strong>{user.hometown}</strong></span>
            </div>
        )}
        {user.relationshipStatus && (
            <div className="flex items-center gap-2">
                <Heart className="w-5 h-5 text-gray-400" />
                <span>{user.relationshipStatus}</span>
            </div>
        )}
        {user.joinedDate && (
             <div className="flex items-center gap-2">
                <Clock className="w-5 h-5 text-gray-400" />
                <span>Joined {user.joinedDate}</span>
            </div>
        )}
        
        {/* Hobbies Display */}
        {user.hobbies && user.hobbies.length > 0 && (
            <div className="mt-4">
                <div className="flex flex-wrap gap-2">
                    {user.hobbies.map(hobby => (
                        <span key={hobby} className="px-3 py-1 bg-gray-100 rounded-full text-xs font-semibold text-gray-600 border border-gray-200">
                            {hobby}
                        </span>
                    ))}
                </div>
            </div>
        )}

      </div>
      {isOwnProfile && (
        <>
            <button 
                onClick={openEditDetailsModal}
                className="w-full mt-4 bg-gray-100 text-gray-800 py-2 rounded-md font-semibold text-sm hover:bg-gray-200 transition-colors"
            >
                Edit Details
            </button>
            <button 
                onClick={() => { setSelectedHobbies(user.hobbies || []); setHobbiesModalOpen(true); }}
                className="w-full mt-2 bg-gray-100 text-gray-800 py-2 rounded-md font-semibold text-sm hover:bg-gray-200 transition-colors"
            >
                Add Hobbies
            </button>
        </>
      )}
    </div>
  );

  const PhotosWidget = () => (
    <div className="bg-white p-4 rounded-lg shadow-sm border border-gray-100 mb-4">
      <div className="flex justify-between items-center mb-3">
         <h3 className="font-bold text-lg text-gray-900">Photos</h3>
         <button onClick={() => setActiveTab('PHOTOS')} className="text-blue-600 text-sm hover:underline">See All Photos</button>
      </div>
      <div className="grid grid-cols-3 gap-1 rounded-lg overflow-hidden">
         {user.photos?.slice(0, 9).map((photo, i) => (
             <img key={i} src={photo} alt="User gallery" className="w-full h-24 object-cover cursor-pointer hover:opacity-90" onClick={() => setActiveTab('PHOTOS')} />
         ))}
      </div>
    </div>
  );

  const FriendsWidget = () => (
    <div className="bg-white p-4 rounded-lg shadow-sm border border-gray-100 mb-4">
      <div className="flex justify-between items-start mb-1">
         <div>
            <h3 className="font-bold text-lg text-gray-900">Friends</h3>
            <span className="text-sm text-gray-500">{user.friendsCount?.toLocaleString()} friends</span>
         </div>
         <button onClick={() => setActiveTab('FRIENDS')} className="text-blue-600 text-sm hover:underline">See All Friends</button>
      </div>
      <div className="grid grid-cols-3 gap-2 mt-3">
         {user.friends?.slice(0, 9).map((friend, i) => (
             <div key={i} className="flex flex-col cursor-pointer" onClick={() => setActiveTab('FRIENDS')}>
                 <img src={friend.avatar} alt={friend.name} className="w-full aspect-square object-cover rounded-lg mb-1" />
                 <span className="text-xs font-semibold text-gray-900 leading-tight">{friend.name}</span>
             </div>
         ))}
      </div>
    </div>
  );

  const AboutTabContent = () => (
      <div className="bg-white rounded-lg shadow-sm border border-gray-100 min-h-[400px] flex flex-col md:flex-row overflow-hidden">
          {/* Sidebar */}
          <div className="w-full md:w-1/3 border-b md:border-b-0 md:border-r border-gray-200 p-2">
              <h3 className="font-bold text-xl px-4 py-3 text-gray-900">About</h3>
              <nav className="space-y-1">
                  {[
                      { id: 'OVERVIEW', label: 'Overview' },
                      { id: 'WORK_EDU', label: 'Work and Education' },
                      { id: 'PLACES', label: 'Places Lived' },
                      { id: 'CONTACT', label: 'Contact and Basic Info' },
                  ].map((item) => (
                      <button 
                        key={item.id}
                        onClick={() => setActiveAboutTab(item.id as AboutSubTab)}
                        className={`w-full text-left px-4 py-2 rounded-md font-semibold text-sm transition-colors ${activeAboutTab === item.id ? 'bg-blue-50 text-blue-600' : 'text-gray-600 hover:bg-gray-100'}`}
                      >
                          {item.label}
                      </button>
                  ))}
              </nav>
          </div>
          
          {/* Content Area */}
          <div className="flex-1 p-6">
               {activeAboutTab === 'OVERVIEW' && (
                   <div className="space-y-6">
                       <div className="flex items-center gap-3">
                           <Briefcase className="w-6 h-6 text-gray-400" />
                           <div>
                               <p className="text-gray-900 text-[15px]">Works at <span className="font-semibold">{user.work || 'No workplace added'}</span></p>
                           </div>
                       </div>
                       <div className="flex items-center gap-3">
                           <GraduationCap className="w-6 h-6 text-gray-400" />
                           <div>
                               <p className="text-gray-900 text-[15px]">Studied at <span className="font-semibold">{user.education || 'No schools added'}</span></p>
                           </div>
                       </div>
                       <div className="flex items-center gap-3">
                           <MapPin className="w-6 h-6 text-gray-400" />
                           <div>
                               <p className="text-gray-900 text-[15px]">Lives in <span className="font-semibold">{user.location || 'No location added'}</span></p>
                           </div>
                       </div>
                        <div className="flex items-center gap-3">
                           <Heart className="w-6 h-6 text-gray-400" />
                           <div>
                               <p className="text-gray-900 text-[15px]"><span className="font-semibold">{user.relationshipStatus || 'Single'}</span></p>
                           </div>
                       </div>
                   </div>
               )}

                {activeAboutTab === 'WORK_EDU' && (
                    <div className="space-y-8">
                        <div>
                             <h4 className="font-bold text-gray-900 mb-3">Work</h4>
                             <div className="flex items-center gap-3">
                                <Briefcase className="w-8 h-8 text-gray-300" />
                                <div>
                                    <p className="text-gray-900 font-semibold">{user.work || 'Add a workplace'}</p>
                                    <p className="text-xs text-gray-500">Current</p>
                                </div>
                             </div>
                        </div>
                        <div>
                             <h4 className="font-bold text-gray-900 mb-3">University</h4>
                             <div className="flex items-center gap-3">
                                <GraduationCap className="w-8 h-8 text-gray-300" />
                                <div>
                                    <p className="text-gray-900 font-semibold">{user.education || 'Add a university'}</p>
                                </div>
                             </div>
                        </div>
                    </div>
                )}

                {activeAboutTab === 'PLACES' && (
                     <div className="space-y-6">
                        <div>
                             <h4 className="font-bold text-gray-900 mb-3">Places Lived</h4>
                             <div className="flex items-center gap-3 mb-4">
                                <MapPin className="w-8 h-8 text-gray-300" />
                                <div>
                                    <p className="text-gray-900 font-semibold">{user.location || 'Add current city'}</p>
                                    <p className="text-xs text-gray-500">Current City</p>
                                </div>
                             </div>
                              <div className="flex items-center gap-3">
                                <MapPin className="w-8 h-8 text-gray-300" />
                                <div>
                                    <p className="text-gray-900 font-semibold">{user.hometown || 'Add hometown'}</p>
                                    <p className="text-xs text-gray-500">Hometown</p>
                                </div>
                             </div>
                        </div>
                     </div>
                )}

                {activeAboutTab === 'CONTACT' && (
                     <div className="space-y-6">
                         <h4 className="font-bold text-gray-900">Contact Info</h4>
                         <div className="flex items-center gap-3">
                             <Phone className="w-5 h-5 text-gray-400" />
                             <span className="text-gray-900">555-0123</span>
                         </div>
                         <div className="flex items-center gap-3">
                             <Mail className="w-5 h-5 text-gray-400" />
                             <span className="text-gray-900">alex.dev@shaverse.app</span>
                         </div>
                         
                         <h4 className="font-bold text-gray-900 pt-4">Websites and Social Links</h4>
                         <div className="flex items-center gap-3">
                             <Globe className="w-5 h-5 text-gray-400" />
                             <a href="#" className="text-blue-600 hover:underline">www.alexdev.com</a>
                         </div>
                     </div>
                )}

                {isOwnProfile && (
                     <button onClick={openEditDetailsModal} className="mt-8 px-4 py-2 bg-gray-100 hover:bg-gray-200 rounded-md text-sm font-semibold transition-colors">
                         Edit Details
                     </button>
                )}
          </div>
      </div>
  );

  const FriendsTabContent = () => {
      const filteredFriends = user.friends?.filter(f => f.name.toLowerCase().includes(friendSearchQuery.toLowerCase())) || [];
      
      return (
        <div className="bg-white rounded-lg shadow-sm border border-gray-100 p-4">
             <div className="flex justify-between items-center mb-6">
                 <h2 className="font-bold text-xl text-gray-900">Friends</h2>
                 <div className="flex gap-2">
                     <div className="relative">
                         <Search className="absolute left-2.5 top-2.5 w-4 h-4 text-gray-500" />
                         <input 
                            type="text" 
                            placeholder="Search friends" 
                            value={friendSearchQuery}
                            onChange={(e) => setFriendSearchQuery(e.target.value)}
                            className="bg-gray-100 rounded-full py-2 pl-9 pr-4 text-sm outline-none focus:ring-1 focus:ring-blue-500"
                         />
                     </div>
                     <button className="text-blue-600 font-semibold text-sm px-3 hover:bg-blue-50 rounded-md">Friend Requests</button>
                     <button className="text-blue-600 font-semibold text-sm px-3 hover:bg-blue-50 rounded-md">Find Friends</button>
                 </div>
             </div>
             
             <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                 {filteredFriends.map(friend => (
                     <div key={friend.id} className="border border-gray-200 rounded-lg p-3 flex items-center justify-between">
                         <div className="flex items-center gap-3">
                             <img src={friend.avatar} alt={friend.name} className="w-20 h-20 rounded-lg object-cover" />
                             <div>
                                 <h3 className="font-semibold text-gray-900">{friend.name}</h3>
                                 <p className="text-xs text-gray-500">{friend.mutualFriends} mutual friends</p>
                             </div>
                         </div>
                         <div className="flex flex-col gap-2">
                             {/* Message Action */}
                             <button 
                                onClick={() => onMessage(friend.id)}
                                className="px-3 py-1.5 bg-blue-600 text-white rounded text-sm font-semibold hover:bg-blue-700"
                             >
                                 Message
                             </button>
                             <button 
                                onClick={() => alert(`Unfriended ${friend.name} (Simulation)`)}
                                className="px-3 py-1.5 bg-gray-200 text-gray-700 rounded text-sm font-semibold hover:bg-gray-300"
                             >
                                 Unfriend
                             </button>
                         </div>
                     </div>
                 ))}
                 {filteredFriends.length === 0 && (
                     <div className="col-span-full py-8 text-center text-gray-500">
                         No friends found matching "{friendSearchQuery}"
                     </div>
                 )}
             </div>
        </div>
      );
  }

  const PhotosTabContent = () => (
      <div className="bg-white rounded-lg shadow-sm border border-gray-100 p-4">
           <div className="flex justify-between items-center mb-6">
               <h2 className="font-bold text-xl text-gray-900">Photos</h2>
               <div className="flex gap-2">
                    <label className="text-blue-600 font-semibold text-sm px-4 py-2 hover:bg-blue-50 rounded-md cursor-pointer flex items-center">
                        <Plus className="w-4 h-4 mr-2" />
                        Add Photos
                        <input type="file" accept="image/*" className="hidden" onChange={handleGalleryUpload} />
                    </label>
               </div>
           </div>

           <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-5 gap-2">
               {user.photos?.map((photo, i) => (
                   <div key={i} className="aspect-square relative group overflow-hidden rounded-lg bg-gray-100 border border-gray-200">
                       <img src={photo} className="w-full h-full object-cover transition-transform duration-300 group-hover:scale-105" alt={`User photo ${i}`} />
                       <div className="absolute inset-0 bg-black/0 group-hover:bg-black/10 transition-colors"></div>
                   </div>
               ))}
           </div>
           {(!user.photos || user.photos.length === 0) && (
               <div className="py-12 text-center text-gray-500">
                   <ImageIcon className="w-12 h-12 mx-auto mb-2 text-gray-300" />
                   <p>No photos yet</p>
               </div>
           )}
      </div>
  );

  // --- Main Render ---

  return (
    <div className="bg-white md:bg-gray-100 min-h-full pb-24 relative">
      
      {/* Sticky Header for Profile Module Branding (Mobile) */}
      <div className="bg-white shadow-sm px-4 py-3 sticky top-0 z-30 flex justify-between items-center md:hidden">
         <div className="flex items-center gap-2">
            <button onClick={onBack} className="md:hidden mr-1 text-gray-600 hover:bg-gray-100 p-1 rounded-full">
                <ArrowLeft className="w-6 h-6" />
            </button>
            <ShaVerseLogo className="w-9 h-9" />
            <div className="flex flex-col">
                <h1 className="text-lg font-bold text-gray-900 leading-none">Profile</h1>
                <span className="text-[10px] text-gray-500 font-medium leading-none mt-0.5">Sha-Verse</span>
            </div>
         </div>
         <div className="bg-gray-100 p-2 rounded-full cursor-pointer hover:bg-gray-200">
             <Search className="w-5 h-5 text-gray-600" />
         </div>
      </div>

      {/* --- MODALS --- */}

      {/* Hobbies Modal */}
      {isHobbiesModalOpen && (
          <div className="fixed inset-0 z-[60] flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm animate-fadeIn">
              <div className="bg-white rounded-xl shadow-2xl w-full max-w-md overflow-hidden">
                  <div className="flex justify-between items-center p-4 border-b">
                      <h3 className="font-bold text-lg">Add Hobbies</h3>
                      <button onClick={() => setHobbiesModalOpen(false)} className="bg-gray-100 p-2 rounded-full hover:bg-gray-200">
                          <X className="w-5 h-5 text-gray-600" />
                      </button>
                  </div>
                  <div className="p-4 max-h-[60vh] overflow-y-auto">
                      <p className="text-gray-500 text-sm mb-4">What do you love to do? Choose from the list below.</p>
                      <div className="flex flex-wrap gap-2">
                          {AVAILABLE_HOBBIES.map(hobby => {
                              const isSelected = selectedHobbies.includes(hobby);
                              return (
                                  <button
                                    key={hobby}
                                    onClick={() => toggleHobby(hobby)}
                                    className={`px-4 py-2 rounded-full text-sm font-semibold border transition-all ${
                                        isSelected 
                                        ? 'bg-blue-100 border-blue-200 text-blue-700' 
                                        : 'bg-white border-gray-300 text-gray-700 hover:bg-gray-50'
                                    }`}
                                  >
                                      {hobby} {isSelected && <CheckCircle className="w-3 h-3 inline ml-1" />}
                                  </button>
                              )
                          })}
                      </div>
                  </div>
                  <div className="p-4 border-t bg-gray-50 flex justify-end gap-2">
                      <button onClick={() => setHobbiesModalOpen(false)} className="px-4 py-2 text-gray-600 font-semibold hover:bg-gray-200 rounded-lg">Cancel</button>
                      <button onClick={saveHobbies} className="px-6 py-2 bg-blue-600 text-white font-semibold rounded-lg hover:bg-blue-700">Save</button>
                  </div>
              </div>
          </div>
      )}

      {/* Edit Details Modal */}
      {isEditDetailsModalOpen && (
        <div className="fixed inset-0 z-[60] flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm animate-fadeIn">
          <div className="bg-white rounded-xl shadow-2xl w-full max-w-lg overflow-hidden max-h-[90vh] flex flex-col">
            <div className="flex justify-between items-center p-4 border-b">
              <h3 className="font-bold text-xl text-center flex-1">Edit Details</h3>
              <button 
                onClick={() => setEditDetailsModalOpen(false)}
                className="bg-gray-100 p-2 rounded-full hover:bg-gray-200 transition-colors"
              >
                <X className="w-5 h-5 text-gray-600" />
              </button>
            </div>
            
            <div className="p-4 overflow-y-auto">
                <div className="space-y-4">
                    <div>
                        <div className="flex justify-between items-center mb-1">
                             <h4 className="font-bold text-lg">Bio</h4>
                        </div>
                         <textarea
                            value={editFormData.bio || ''}
                            onChange={(e) => handleDetailsChange('bio', e.target.value)}
                            className="w-full border border-gray-300 rounded-lg p-2 text-sm text-center focus:ring-2 focus:ring-blue-500 outline-none"
                            placeholder="Describe yourself..."
                            rows={2}
                        />
                    </div>

                    <div className="border-t border-gray-200 pt-4">
                         <h4 className="font-bold text-lg mb-3">Customize your intro</h4>
                         
                         <div className="space-y-4">
                             <div className="flex items-center gap-3">
                                <Briefcase className="w-6 h-6 text-gray-400" />
                                <div className="flex-1">
                                    <label className="text-xs text-gray-500 font-semibold uppercase">Workplace</label>
                                    <input 
                                        type="text" 
                                        value={editFormData.work || ''}
                                        onChange={(e) => handleDetailsChange('work', e.target.value)}
                                        className="w-full border-b border-gray-300 py-1 focus:border-blue-500 outline-none text-sm"
                                        placeholder="Company, position, etc."
                                    />
                                </div>
                             </div>

                             <div className="flex items-center gap-3">
                                <GraduationCap className="w-6 h-6 text-gray-400" />
                                <div className="flex-1">
                                    <label className="text-xs text-gray-500 font-semibold uppercase">Education</label>
                                    <input 
                                        type="text" 
                                        value={editFormData.education || ''}
                                        onChange={(e) => handleDetailsChange('education', e.target.value)}
                                        className="w-full border-b border-gray-300 py-1 focus:border-blue-500 outline-none text-sm"
                                        placeholder="School, university, etc."
                                    />
                                </div>
                             </div>

                             <div className="flex items-center gap-3">
                                <MapPin className="w-6 h-6 text-gray-400" />
                                <div className="flex-1">
                                    <label className="text-xs text-gray-500 font-semibold uppercase">Current City</label>
                                    <input 
                                        type="text" 
                                        value={editFormData.location || ''}
                                        onChange={(e) => handleDetailsChange('location', e.target.value)}
                                        className="w-full border-b border-gray-300 py-1 focus:border-blue-500 outline-none text-sm"
                                        placeholder="Add current city"
                                    />
                                </div>
                             </div>

                              <div className="flex items-center gap-3">
                                <MapPin className="w-6 h-6 text-gray-400" />
                                <div className="flex-1">
                                    <label className="text-xs text-gray-500 font-semibold uppercase">Hometown</label>
                                    <input 
                                        type="text" 
                                        value={editFormData.hometown || ''}
                                        onChange={(e) => handleDetailsChange('hometown', e.target.value)}
                                        className="w-full border-b border-gray-300 py-1 focus:border-blue-500 outline-none text-sm"
                                        placeholder="Add hometown"
                                    />
                                </div>
                             </div>

                             <div className="flex items-center gap-3">
                                <Heart className="w-6 h-6 text-gray-400" />
                                <div className="flex-1">
                                    <label className="text-xs text-gray-500 font-semibold uppercase">Relationship Status</label>
                                    <select 
                                        value={editFormData.relationshipStatus || ''}
                                        onChange={(e) => handleDetailsChange('relationshipStatus', e.target.value)}
                                        className="w-full border-b border-gray-300 py-1 focus:border-blue-500 outline-none text-sm bg-transparent"
                                    >
                                        <option value="">Select Status</option>
                                        <option value="Single">Single</option>
                                        <option value="In a relationship">In a relationship</option>
                                        <option value="Engaged">Engaged</option>
                                        <option value="Married">Married</option>
                                        <option value="It's complicated">It's complicated</option>
                                    </select>
                                </div>
                             </div>
                         </div>
                    </div>
                </div>
            </div>

            <div className="p-4 border-t bg-gray-50 flex justify-end gap-2">
              <button 
                onClick={() => setEditDetailsModalOpen(false)}
                className="px-4 py-2 text-blue-600 font-semibold hover:bg-blue-50 rounded-lg"
              >
                Cancel
              </button>
              <button 
                onClick={handleSaveButtonClick}
                className="px-6 py-2 bg-blue-600 text-white font-semibold rounded-lg hover:bg-blue-700 transition-colors"
              >
                Save
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Confirmation Modal */}
      {isConfirmSaveOpen && (
        <div className="fixed inset-0 z-[70] flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm animate-fadeIn">
            <div className="bg-white rounded-xl shadow-2xl w-full max-w-sm overflow-hidden p-6 text-center">
                 <div className="mx-auto w-12 h-12 bg-blue-100 rounded-full flex items-center justify-center mb-4">
                    <AlertCircle className="w-6 h-6 text-blue-600" />
                 </div>
                 <h3 className="font-bold text-lg mb-2 text-gray-900">Save Changes?</h3>
                 <p className="text-gray-600 mb-6 text-sm">Are you sure you want to update your profile details? These changes will be visible to others.</p>
                 <div className="flex justify-center gap-3">
                     <button 
                        onClick={() => setConfirmSaveOpen(false)}
                        className="px-4 py-2 text-gray-700 font-semibold hover:bg-gray-100 rounded-lg transition-colors border border-gray-200"
                     >
                        Cancel
                     </button>
                     <button 
                        onClick={handleConfirmSave}
                        className="px-6 py-2 bg-blue-600 text-white font-semibold rounded-lg hover:bg-blue-700 transition-colors shadow-sm"
                     >
                        Confirm
                     </button>
                 </div>
            </div>
        </div>
      )}

      {/* Edit Cover Modal */}
      {isCoverModalOpen && (
        <div className="fixed inset-0 z-[60] flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm animate-fadeIn">
          <div className="bg-white rounded-xl shadow-2xl w-full max-w-lg overflow-hidden">
            <div className="flex justify-between items-center p-4 border-b">
              <h3 className="font-bold text-lg">Edit Cover Photo</h3>
              <button 
                onClick={() => setCoverModalOpen(false)}
                className="bg-gray-100 p-2 rounded-full hover:bg-gray-200 transition-colors"
              >
                <X className="w-5 h-5 text-gray-600" />
              </button>
            </div>
            
            <div className="p-4">
              <div className="mb-4 h-48 bg-gray-100 rounded-lg overflow-hidden border border-gray-300 relative">
                {tempCoverUrl ? (
                  <img src={tempCoverUrl} alt="Preview" className="w-full h-full object-cover" />
                ) : (
                  <div className="flex items-center justify-center h-full text-gray-400">
                    No image selected
                  </div>
                )}
              </div>

              <div className="space-y-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Upload Image</label>
                  <label className="flex items-center justify-center w-full p-4 border-2 border-dashed border-gray-300 rounded-lg cursor-pointer hover:bg-gray-50 transition-colors">
                    <input type="file" accept="image/*" onChange={handleCoverFileChange} className="hidden" />
                    <Upload className="w-5 h-5 text-gray-500 mr-2" />
                    <span className="text-sm text-gray-600">Click to upload from device</span>
                  </label>
                </div>
                
                <div className="text-center text-sm text-gray-500 font-medium">- OR -</div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Image URL</label>
                  <input 
                    type="text" 
                    value={tempCoverUrl}
                    onChange={(e) => setTempCoverUrl(e.target.value)}
                    placeholder="https://example.com/image.jpg"
                    className="w-full border border-gray-300 rounded-lg p-2.5 focus:ring-2 focus:ring-blue-500 outline-none"
                  />
                </div>
              </div>
            </div>

            <div className="p-4 border-t bg-gray-50 flex justify-end gap-2">
              <button 
                onClick={() => setCoverModalOpen(false)}
                className="px-4 py-2 text-blue-600 font-semibold hover:bg-blue-50 rounded-lg"
              >
                Cancel
              </button>
              <button 
                onClick={handleSaveCover}
                className="px-6 py-2 bg-blue-600 text-white font-semibold rounded-lg hover:bg-blue-700 transition-colors"
              >
                Save Changes
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Header Section */}
      <div className="bg-white shadow-sm mb-4">
        {/* Cover Photo */}
        <div className="relative w-full h-40 md:h-80 md:rounded-b-lg overflow-hidden bg-gray-300 group">
           {user.coverPhoto ? (
             <img src={user.coverPhoto} alt="Cover" className="w-full h-full object-cover" />
           ) : (
             <div className="w-full h-full bg-gradient-to-r from-gray-400 to-gray-600"></div>
           )}
           {isOwnProfile && (
             <button 
               onClick={openCoverModal}
               className="absolute bottom-4 right-4 bg-white text-gray-900 px-3 py-1.5 rounded-md font-semibold text-sm flex items-center shadow-md hover:bg-gray-50 transition-colors"
             >
                <Camera className="w-4 h-4 mr-2" />
                Edit Cover Photo
             </button>
           )}
        </div>

        <div className="max-w-6xl mx-auto px-4 pb-4">
           <div className="flex flex-col md:flex-row items-center md:items-end -mt-16 md:-mt-10 relative">
               {/* Avatar */}
               <div className="relative p-1 bg-white rounded-full">
                   <img src={user.avatar} alt={user.name} className="w-32 h-32 md:w-40 md:h-40 rounded-full object-cover border-4 border-white" />
                   {isOwnProfile && (
                      <div className="absolute bottom-2 right-2 bg-gray-200 p-1.5 rounded-full border-2 border-white cursor-pointer hover:bg-gray-300">
                          <Camera className="w-4 h-4 text-gray-800" />
                      </div>
                   )}
               </div>

               {/* Name & Headline */}
               <div className="mt-3 md:mt-0 md:ml-4 text-center md:text-left flex-1 mb-4 md:mb-2">
                  <h1 className="text-2xl md:text-3xl font-bold text-gray-900">{user.name}</h1>
                  <p className="font-semibold text-gray-500 text-sm md:text-base">{user.friendsCount?.toLocaleString()} friends</p>
                  <div className="flex justify-center md:justify-start -space-x-2 mt-1">
                      {user.friends?.slice(0, 8).map((f, i) => (
                          <img key={i} src={f.avatar} className="w-8 h-8 rounded-full border-2 border-white" alt="friend" />
                      ))}
                  </div>
               </div>

               {/* Action Buttons */}
               <div className="flex gap-2 mt-2 md:mt-0 md:mb-4 w-full md:w-auto px-4 md:px-0">
                  {isOwnProfile ? (
                      <>
                        <button 
                            onClick={handleAddToStory}
                            disabled={isPostingStory}
                            className="flex-1 md:flex-none bg-blue-600 text-white px-4 py-2 rounded-md font-semibold text-sm hover:bg-blue-700 transition-colors flex items-center justify-center disabled:opacity-70"
                        >
                            {isPostingStory ? <Loader2 className="w-4 h-4 mr-1.5 animate-spin" /> : <Plus className="w-4 h-4 mr-1.5" />}
                            {isPostingStory ? 'Posting...' : 'Add to Story'}
                        </button>
                        <button 
                            onClick={openEditDetailsModal}
                            className="flex-1 md:flex-none bg-gray-200 text-gray-800 px-4 py-2 rounded-md font-semibold text-sm hover:bg-gray-300 transition-colors flex items-center justify-center"
                        >
                            <PenSquare className="w-4 h-4 mr-1.5" />
                            Edit Profile
                        </button>
                        <button className="bg-gray-200 text-gray-800 px-3 py-2 rounded-md hover:bg-gray-300">
                            <ChevronDown className="w-4 h-4" />
                        </button>
                      </>
                  ) : (
                      <>
                        <button className="flex-1 md:flex-none bg-blue-600 text-white px-4 py-2 rounded-md font-semibold text-sm hover:bg-blue-700 transition-colors flex items-center justify-center">
                             <Plus className="w-4 h-4 mr-1.5" />
                             Add Friend
                        </button>
                        <button 
                            onClick={() => onMessage(user.id)}
                            className="flex-1 md:flex-none bg-gray-200 text-gray-800 px-4 py-2 rounded-md font-semibold text-sm hover:bg-gray-300 transition-colors flex items-center justify-center"
                        >
                            <MessageCircle className="w-4 h-4 mr-1.5" />
                            Message
                        </button>
                      </>
                  )}
               </div>
           </div>

           <div className="border-t border-gray-300 mt-6 pt-1">
               <div className="flex gap-1 overflow-x-auto no-scrollbar">
                   {['Posts', 'About', 'Friends', 'Photos'].map((tab) => {
                       const tabKey = tab.toUpperCase() as Tab;
                       const isActive = activeTab === tabKey;
                       return (
                           <button 
                                key={tab}
                                onClick={() => setActiveTab(tabKey)}
                                className={`px-4 py-3 font-semibold text-sm md:text-[15px] whitespace-nowrap border-b-[3px] transition-colors ${
                                    isActive 
                                    ? 'text-blue-600 border-blue-600' 
                                    : 'text-gray-600 border-transparent hover:bg-gray-50'
                                }`}
                           >
                               {tab}
                           </button>
                       )
                   })}
                   <button className="px-4 py-3 font-semibold text-sm md:text-[15px] text-gray-600 hover:bg-gray-50 flex items-center">
                       More <ChevronDown className="w-4 h-4 ml-1" />
                   </button>
               </div>
           </div>
        </div>
      </div>

      {/* Main Content Grid */}
      <div className="max-w-6xl mx-auto px-0 md:px-4">
          
          {/* View: POSTS (Standard Split Layout) */}
          {activeTab === 'POSTS' && (
              <div className="flex flex-col md:flex-row gap-4">
                  {/* Left Column (Desktop) */}
                  <div className="w-full md:w-5/12 lg:w-[400px] flex-shrink-0 space-y-4 px-4 md:px-0">
                      <IntroCard />
                      <PhotosWidget />
                      <FriendsWidget />
                  </div>

                  {/* Right Column (Feed) */}
                  <div className="flex-1 min-w-0 px-0 md:px-0">
                      {isOwnProfile && (
                        <div className="px-4 md:px-0">
                            <CreatePost currentUser={currentUser} onCreatePost={onCreatePost} />
                        </div>
                      )}
                      
                      {/* Filters/Manage Posts Bar (Visual only) */}
                      <div className="bg-white rounded-lg shadow-sm border border-gray-100 p-3 mb-4 mx-4 md:mx-0 flex justify-between items-center">
                          <h2 className="font-bold text-lg text-gray-900">Posts</h2>
                          <div className="flex gap-2">
                              <button className="bg-gray-100 px-3 py-1.5 rounded text-sm font-semibold hover:bg-gray-200">Filters</button>
                              <button className="bg-gray-100 px-3 py-1.5 rounded text-sm font-semibold hover:bg-gray-200">Manage Posts</button>
                          </div>
                      </div>

                      <div className="space-y-4 px-0 md:px-0">
                          {userPosts.length > 0 ? (
                              userPosts.map(post => (
                                <PostCard
                                    key={post.id}
                                    post={post}
                                    currentUser={currentUser}
                                    onLike={onLike}
                                    onComment={onComment}
                                    onVote={onVote}
                                    onEditPost={onEditPost}
                                    onDeletePost={onDeletePost}
                                    onLikeComment={onLikeComment}
                                />
                              ))
                          ) : (
                              <div className="bg-white p-8 rounded-lg shadow-sm text-center">
                                  <h3 className="text-gray-500 font-semibold">No posts to show</h3>
                              </div>
                          )}
                      </div>
                  </div>
              </div>
          )}

          {/* View: ABOUT */}
          {activeTab === 'ABOUT' && (
              <div className="px-4 md:px-0">
                  <AboutTabContent />
              </div>
          )}

          {/* View: FRIENDS */}
          {activeTab === 'FRIENDS' && (
              <div className="px-4 md:px-0">
                  <FriendsTabContent />
              </div>
          )}

           {/* View: PHOTOS */}
           {activeTab === 'PHOTOS' && (
              <div className="px-4 md:px-0">
                  <PhotosTabContent />
              </div>
          )}

      </div>
    </div>
  );
};
