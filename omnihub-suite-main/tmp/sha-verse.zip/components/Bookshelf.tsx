import React, { useState } from 'react';
import { Book, MonetizationStats } from '../types';
import { BookOpen, DollarSign, Star, Upload, ArrowLeft } from 'lucide-react';
import { MOCK_BOOKS } from '../constants';
import { ShaVerseLogo } from './ShaVerseLogo';

interface BookshelfProps {
    onBack: () => void;
}

export const Bookshelf: React.FC<BookshelfProps> = ({ onBack }) => {
  const [activeBook, setActiveBook] = useState<Book | null>(null);
  const [showStudio, setShowStudio] = useState(false);

   // Mock Stats
   const stats: MonetizationStats = {
    revenue: 5600.25,
    views: 89000, 
    subscribers: 4200,
    watchTimeHours: 1200
  };

  const Reader = ({ book, onClose }: { book: Book; onClose: () => void }) => (
      <div className="fixed inset-0 z-[100] bg-white flex flex-col animate-fadeIn">
          <div className="border-b border-gray-200 px-4 py-3 flex justify-between items-center shadow-sm sticky top-0 bg-white">
              <button onClick={onClose} className="flex items-center text-gray-600 hover:text-gray-900">
                  <ArrowLeft className="w-5 h-5 mr-1" /> Back
              </button>
              <h2 className="font-serif font-bold text-lg text-gray-900 truncate ml-2">{book.title}</h2>
              <div className="w-16"></div>
          </div>
          <div className="flex-1 overflow-y-auto p-6 md:p-12 bg-[#faf9f6]">
              <div className="max-w-2xl mx-auto">
                  <h1 className="text-3xl md:text-4xl font-serif font-bold text-gray-900 mb-2 text-center">{book.title}</h1>
                  <p className="text-center text-gray-500 font-serif italic mb-12">by {book.author}</p>
                  
                  <div className="prose prose-lg font-serif text-gray-800 leading-loose mx-auto">
                      {book.content.split('\n').map((para, i) => (
                          <p key={i} className="mb-6">{para}</p>
                      ))}
                      <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.</p>
                  </div>
              </div>
          </div>
      </div>
  );

  return (
    <div className="bg-gray-100 min-h-full pb-24">
      {/* Header */}
      <div className="bg-white shadow-sm px-4 py-3 sticky top-0 z-30 flex justify-between items-center">
         <div className="flex items-center gap-2">
            <button onClick={onBack} className="md:hidden mr-1 text-gray-600 hover:bg-gray-100 p-1 rounded-full">
                <ArrowLeft className="w-6 h-6" />
            </button>
            <ShaVerseLogo className="w-9 h-9" />
            <div className="flex flex-col">
                <div className="flex items-center gap-1">
                    <div className="bg-amber-700 p-0.5 rounded-sm">
                        <BookOpen className="w-3 h-3 text-white fill-current" />
                    </div>
                    <h1 className="text-xl font-bold text-gray-900 tracking-tight font-serif leading-none">Bookshelf</h1>
                </div>
                <span className="text-[10px] text-gray-500 font-medium leading-none mt-0.5">Sha-Verse</span>
            </div>
         </div>
         <div className="flex gap-2">
            <button className="flex items-center gap-1 bg-gray-100 text-gray-700 px-3 py-1.5 rounded-full font-semibold text-sm hover:bg-gray-200 transition-colors">
                <Upload className="w-4 h-4" />
                <span className="hidden sm:inline">Upload</span>
            </button>
            <button 
                onClick={() => setShowStudio(true)}
                className="flex items-center gap-1 bg-green-100 text-green-700 px-3 py-1.5 rounded-full font-semibold text-sm hover:bg-green-200 transition-colors"
            >
                <DollarSign className="w-4 h-4" />
                <span className="hidden sm:inline">Earn</span>
            </button>
         </div>
      </div>

       {/* Monetization Modal */}
       {showStudio && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm animate-fadeIn">
           <div className="bg-white rounded-xl shadow-2xl w-full max-w-2xl overflow-hidden max-h-[80vh] overflow-y-auto">
               <div className="flex justify-between items-center p-6 border-b sticky top-0 bg-white">
                  <h2 className="text-2xl font-bold text-gray-800 font-serif">Author Dashboard</h2>
                  <button onClick={() => setShowStudio(false)} className="text-gray-500 hover:text-gray-800">Close</button>
               </div>
               <div className="p-6">
                   <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
                       <div className="bg-green-50 p-6 rounded-xl border border-green-100">
                           <div className="flex items-center gap-3 mb-2">
                               <div className="bg-green-500 p-2 rounded-lg text-white"><DollarSign className="w-6 h-6" /></div>
                               <span className="text-green-800 font-semibold">Royalties</span>
                           </div>
                           <h3 className="text-3xl font-bold text-gray-900 font-serif">${stats.revenue.toLocaleString()}</h3>
                       </div>
                       <div className="bg-amber-50 p-6 rounded-xl border border-amber-100">
                           <div className="flex items-center gap-3 mb-2">
                               <div className="bg-amber-600 p-2 rounded-lg text-white"><BookOpen className="w-6 h-6" /></div>
                               <span className="text-amber-800 font-semibold">Total Reads</span>
                           </div>
                           <h3 className="text-3xl font-bold text-gray-900 font-serif">{stats.views.toLocaleString()}</h3>
                       </div>
                   </div>
                   <div className="bg-gray-50 p-4 rounded-lg">
                       <h4 className="font-bold mb-2">Monetization Rules</h4>
                       <ul className="list-disc list-inside text-sm text-gray-600 space-y-1">
                           <li>You earn $0.005 per page read.</li>
                           <li>Books must be original content.</li>
                           <li>Payouts are processed monthly via Stripe.</li>
                       </ul>
                   </div>
               </div>
           </div>
        </div>
      )}

      {/* Reader Mode */}
      {activeBook && <Reader book={activeBook} onClose={() => setActiveBook(null)} />}

      {/* Book Grid */}
      <div className="max-w-6xl mx-auto p-4">
          <h2 className="font-bold text-lg text-gray-700 mb-4">Trending Books</h2>
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-4 md:gap-6">
              {MOCK_BOOKS.map(book => (
                  <div key={book.id} onClick={() => setActiveBook(book)} className="flex flex-col cursor-pointer group bg-white p-2 rounded-lg shadow-sm">
                      <div className="relative aspect-[2/3] rounded-lg overflow-hidden shadow-md group-hover:shadow-xl transition-all duration-300 transform group-hover:-translate-y-1">
                          <img src={book.cover} alt={book.title} className="w-full h-full object-cover" />
                          <div className="absolute inset-0 bg-black/0 group-hover:bg-black/10 transition-colors"></div>
                      </div>
                      <div className="mt-3">
                          <h3 className="font-bold text-gray-900 leading-tight mb-1 group-hover:text-amber-700 transition-colors line-clamp-2 text-sm md:text-base">{book.title}</h3>
                          <p className="text-xs md:text-sm text-gray-600">{book.author}</p>
                          <div className="flex items-center gap-1 mt-1">
                              <Star className="w-3 h-3 text-yellow-400 fill-current" />
                              <span className="text-xs text-gray-500">{book.rating} • {book.reads.toLocaleString()} reads</span>
                          </div>
                      </div>
                  </div>
              ))}
          </div>
      </div>
    </div>
  );
};