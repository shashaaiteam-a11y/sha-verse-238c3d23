import React from 'react';
import { ViewState, User } from '../types';
import { Home, Users, UserCircle, MonitorPlay, Sparkles, BookOpen } from 'lucide-react';

interface DesktopSidebarProps {
  currentView: ViewState;
  onNavigate: (view: ViewState) => void;
  currentUser: User;
}

export const DesktopSidebar: React.FC<DesktopSidebarProps> = ({ currentView, onNavigate, currentUser }) => {
  const navItems = [
    { id: ViewState.HOME, icon: Home, label: 'Feed' },
    { id: ViewState.PROFILE, icon: UserCircle, label: 'Profile' },
    { id: ViewState.MOVION, icon: MonitorPlay, label: 'Movion' },
    { id: ViewState.NOVACHAT, icon: Sparkles, label: 'NovaChat' },
    { id: ViewState.BOOKSHELF, icon: BookOpen, label: 'Bookshelf' },
    { id: ViewState.GROUPS, icon: Users, label: 'Groups' },
  ];

  return (
    <div className="hidden md:flex flex-col w-64 h-full pt-4 px-4 overflow-y-auto no-scrollbar border-r border-gray-200 bg-gray-100 flex-shrink-0">
      <div
        className="flex items-center p-2 mb-4 rounded-lg hover:bg-gray-200 cursor-pointer transition-colors"
        onClick={() => onNavigate(ViewState.PROFILE)}
      >
        <img src={currentUser.avatar} alt="Me" className="w-9 h-9 rounded-full mr-3 object-cover border border-gray-300" />
        <span className="font-semibold text-gray-900">{currentUser.name}</span>
      </div>

      {navItems.map((item) => {
        const Icon = item.icon;
        const isActive = currentView === item.id;
        return (
          <button
            key={item.id}
            onClick={() => onNavigate(item.id)}
            className={`flex items-center p-3 mb-1 rounded-lg transition-all ${
              isActive ? 'bg-gray-200 text-gray-900 font-bold' : 'hover:bg-gray-200 text-gray-700'
            }`}
          >
            <Icon className={`w-7 h-7 mr-3 ${isActive ? 'fill-current' : ''}`} />
            <span className={`font-medium text-[15px] ${isActive ? 'font-bold' : ''}`}>{item.label}</span>
          </button>
        );
      })}

      <div className="border-t border-gray-300 my-4"></div>

      <h3 className="text-gray-500 font-semibold mb-2 px-2 text-sm">Your Shortcuts</h3>
      <div className="px-2 text-xs text-gray-400">
        <p className="mb-2 cursor-pointer hover:underline">Clone Development Group</p>
        <p className="mb-2 cursor-pointer hover:underline">React 19 Updates</p>
        <p className="cursor-pointer hover:underline">Gemini AI Fan Club</p>
      </div>
    </div>
  );
};