
import React from 'react';
import { ViewState } from '../types';
import { Home, Users, MonitorPlay, Sparkles, BookOpen, Menu } from 'lucide-react';

interface NavigationProps {
  currentView: ViewState;
  onNavigate: (view: ViewState) => void;
  onMenuClick?: () => void;
}

export const Navigation: React.FC<NavigationProps> = ({ currentView, onNavigate, onMenuClick }) => {
  const navItems = [
    { id: ViewState.HOME, icon: Home, label: 'Home' },
    { id: ViewState.MOVION, icon: MonitorPlay, label: 'Movion' },
    { id: ViewState.NOVACHAT, icon: Sparkles, label: 'NovaChat' },
    { id: ViewState.BOOKSHELF, icon: BookOpen, label: 'Books' },
    { id: ViewState.GROUPS, icon: Users, label: 'Groups' },
  ];

  return (
    <nav className="fixed bottom-0 left-0 right-0 bg-white border-t border-gray-300 pb-safe pt-1 z-50 md:hidden">
      <div className="flex justify-between items-center h-12 px-1">
        {navItems.map((item) => {
            const Icon = item.icon;
            const isActive = currentView === item.id;
            
            return (
                <button
                    key={item.id}
                    onClick={() => onNavigate(item.id)}
                    className="flex-1 flex flex-col items-center justify-center h-full relative group active:scale-95 transition-transform"
                >
                    <div className={`relative p-1 rounded-xl ${isActive ? 'text-blue-600' : 'text-gray-500'}`}>
                        <Icon className={`w-6 h-6 ${isActive ? 'fill-current' : ''}`} strokeWidth={isActive ? 2.5 : 2} />
                    </div>
                    <span className={`text-[10px] font-medium leading-none ${isActive ? 'text-blue-600' : 'text-gray-500'}`}>
                        {item.label}
                    </span>
                </button>
            );
        })}
        {/* Menu Item (Always present on mobile right) */}
         <button
            onClick={onMenuClick}
            className="flex-1 flex flex-col items-center justify-center h-full relative group active:scale-95 transition-transform"
        >
            <div className="relative p-1 rounded-xl text-gray-500">
                <Menu className="w-6 h-6" strokeWidth={2} />
            </div>
            <span className="text-[10px] font-medium leading-none text-gray-500">
                Menu
            </span>
        </button>
      </div>
      {/* Safe area spacer for iPhone X+ */}
      <div className="h-4 bg-white"></div>
    </nav>
  );
};
