import React, { useState, useEffect } from 'react';
import { Post, User, Group, ViewState, Comment, PostType, ReactionType } from './types';
import { INITIAL_POSTS, INITIAL_GROUPS, CURRENT_USER } from './constants';
import { Navigation } from './components/Navigation';
import { DesktopSidebar } from './components/DesktopSidebar';
import { Feed } from './components/Feed';
import { Groups } from './components/Groups';
import { Profile } from './components/Profile';
import { Movion } from './components/Movion';
import { NovaChat } from './components/NovaChat';
import { Bookshelf } from './components/Bookshelf';
import { Messages } from './components/Messages';
import { Search, Bell, MessageCircle, Menu, UserCircle, Users, Home, MonitorPlay, Sparkles, BookOpen, MoreHorizontal } from 'lucide-react';
import { ShaVerseLogo } from './components/ShaVerseLogo';

export default function App() {
  const [currentView, setCurrentView] = useState<ViewState>(ViewState.HOME);
  const [posts, setPosts] = useState<Post[]>(INITIAL_POSTS);
  const [groups, setGroups] = useState<Group[]>(INITIAL_GROUPS);
  const [currentUser, setCurrentUser] = useState<User>(CURRENT_USER);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [selectedContactId, setSelectedContactId] = useState<string | null>(null);

  // Fix for mobile browser 100vh issue
  useEffect(() => {
    const setVh = () => {
      const vh = window.innerHeight * 0.01;
      document.documentElement.style.setProperty('--vh', `${vh}px`);
    };
    setVh();
    window.addEventListener('resize', setVh);
    return () => window.removeEventListener('resize', setVh);
  }, []);

  // --- Actions ---

  const handleUpdateUser = (updatedFields: Partial<User>) => {
    setCurrentUser(prev => ({ ...prev, ...updatedFields }));
  };

  const handleCreatePost = (content: string, mediaUrl?: string, type: PostType = 'text', pollOptions: string[] = []) => {
    const newPost: Post = {
      id: `new_${Date.now()}`,
      userId: currentUser.id,
      userName: currentUser.name,
      userAvatar: currentUser.avatar,
      content,
      mediaUrls: mediaUrl ? [mediaUrl] : undefined, // Currently CreatePost sends one, but Post supports array
      type,
      reactions: { like: 0, love: 0, haha: 0, wow: 0, sad: 0, angry: 0 },
      comments: [],
      timestamp: Date.now(),
      currentUserReaction: undefined,
      pollOptions: type === 'poll' ? pollOptions.map((opt, i) => ({ id: `opt_${i}`, text: opt, votes: 0 })) : undefined,
      totalVotes: 0,
      userIsVerified: currentUser.isVerified
    };
    setPosts([newPost, ...posts]);
  };

  const handleEditPost = (postId: string, newContent: string) => {
    setPosts(posts.map(post => 
      post.id === postId ? { ...post, content: newContent, isEdited: true } : post
    ));
  };

  const handleDeletePost = (postId: string) => {
      setPosts(posts.filter(p => p.id !== postId));
  };

  const handleReaction = (postId: string, reactionType: ReactionType) => {
    setPosts(posts.map(post => {
      if (post.id === postId) {
          const currentReaction = post.currentUserReaction;
          const newReactions = { ...post.reactions };

          // If clicking the same reaction, remove it (toggle off)
          if (currentReaction === reactionType) {
             if (newReactions[reactionType] > 0) newReactions[reactionType]--;
             return { ...post, reactions: newReactions, currentUserReaction: undefined };
          }

          // If changing reaction, remove old one first
          if (currentReaction) {
              if (newReactions[currentReaction] > 0) newReactions[currentReaction]--;
          }

          // Add new reaction
          newReactions[reactionType]++;
          
          return {
              ...post,
              reactions: newReactions,
              currentUserReaction: reactionType
          };
      }
      return post;
    }));
  };

  const handleComment = (postId: string, text: string) => {
    const newComment: Comment = {
      id: `c_${Date.now()}`,
      userId: currentUser.id,
      userName: currentUser.name,
      userAvatar: currentUser.avatar,
      text,
      timestamp: Date.now(),
      likes: 0,
      isLikedByCurrentUser: false
    };

    setPosts(posts.map(post => {
      if (post.id === postId) {
        return {
          ...post,
          comments: [...post.comments, newComment]
        };
      }
      return post;
    }));
  };

  const handleLikeComment = (postId: string, commentId: string) => {
    setPosts(posts.map(post => {
      if (post.id === postId) {
        return {
          ...post,
          comments: post.comments.map(comment => {
            if (comment.id === commentId) {
              return {
                ...comment,
                likes: comment.isLikedByCurrentUser ? comment.likes - 1 : comment.likes + 1,
                isLikedByCurrentUser: !comment.isLikedByCurrentUser
              };
            }
            return comment;
          })
        };
      }
      return post;
    }));
  };

  const handleVote = (postId: string, optionId: string) => {
    setPosts(posts.map(post => {
      if (post.id === postId && post.type === 'poll' && post.pollOptions) {
        if (post.votedOptionId) return post; // Already voted

        const updatedOptions = post.pollOptions.map(opt => 
           opt.id === optionId ? { ...opt, votes: opt.votes + 1 } : opt
        );
        
        return {
          ...post,
          pollOptions: updatedOptions,
          totalVotes: (post.totalVotes || 0) + 1,
          votedOptionId: optionId
        };
      }
      return post;
    }));
  };

  const handleJoinGroup = (groupId: string) => {
    setGroups(groups.map(g => g.id === groupId ? { ...g, isJoined: !g.isJoined } : g));
  };

  const handleMessageUser = (userId: string) => {
      setSelectedContactId(userId);
      setCurrentView(ViewState.MESSAGES);
  };

  const handleNavigation = (view: ViewState) => {
      if (view !== ViewState.MESSAGES) {
          setSelectedContactId(null);
      }
      setCurrentView(view);
  };

  // --- Header Component (Desktop) ---
  const Header = () => (
      <header className="hidden md:flex flex-shrink-0 h-16 bg-white shadow-sm z-50 px-4 items-center justify-between border-b border-gray-200 sticky top-0">
         <div className="flex items-center gap-2">
             <div className="cursor-pointer" onClick={() => handleNavigation(ViewState.HOME)}>
                <ShaVerseLogo className="w-10 h-10" />
             </div>
             <div className="flex flex-col justify-center hidden lg:flex">
                <span className="font-bold text-xl text-gray-800 tracking-tight leading-none">Sha-Verse</span>
                <span className="text-[10px] text-gray-500 uppercase tracking-wider leading-none">Social Universe</span>
             </div>
             <div className="relative ml-4">
                 <Search className="absolute left-2.5 top-2.5 w-4 h-4 text-gray-500" />
                 <input type="text" placeholder="Search Sha-Verse" className="bg-gray-100 rounded-full py-2 pl-9 pr-4 text-[15px] w-[240px] outline-none focus:ring-1 focus:ring-gray-400 placeholder-gray-500" />
             </div>
         </div>
         
         <div className="flex gap-1 h-full items-center">
            {[
                { id: ViewState.HOME, icon: Home, label: 'Home' },
                { id: ViewState.MOVION, icon: MonitorPlay, label: 'Movion' },
                { id: ViewState.NOVACHAT, icon: Sparkles, label: 'NovaChat' },
                { id: ViewState.BOOKSHELF, icon: BookOpen, label: 'Bookshelf' },
                { id: ViewState.GROUPS, icon: Users, label: 'Groups' },
            ].map((item) => {
                const Icon = item.icon;
                const isActive = currentView === item.id;
                return (
                    <button 
                        key={item.id}
                        onClick={() => handleNavigation(item.id)}
                        className={`w-24 lg:w-28 h-full flex items-center justify-center relative group ${isActive ? 'text-blue-600' : 'text-gray-500 hover:bg-gray-100 rounded-lg my-1'}`}
                    >
                        <Icon className={`w-7 h-7 ${isActive ? 'fill-current' : ''}`} />
                        {isActive && <div className="absolute bottom-0 left-0 right-0 h-[3px] bg-blue-600"></div>}
                        {!isActive && <div className="hidden group-hover:block absolute -bottom-10 bg-black/80 text-white text-xs py-1 px-2 rounded z-50">{item.label}</div>}
                    </button>
                )
            })}
         </div>

         <div className="flex items-center gap-2">
             <div className="w-10 h-10 bg-gray-100 rounded-full flex items-center justify-center cursor-pointer hover:bg-gray-200 relative group">
                <Menu className="w-5 h-5 text-gray-900" />
             </div>
             <div 
                className={`w-10 h-10 rounded-full flex items-center justify-center cursor-pointer relative group ${currentView === ViewState.MESSAGES ? 'bg-blue-100 text-blue-600' : 'bg-gray-100 text-gray-900 hover:bg-gray-200'}`}
                onClick={() => handleNavigation(ViewState.MESSAGES)}
             >
                <MessageCircle className="w-5 h-5" />
             </div>
             <div className="w-10 h-10 bg-gray-100 rounded-full flex items-center justify-center cursor-pointer hover:bg-gray-200 relative group">
                <Bell className="w-5 h-5 text-gray-900" />
             </div>
             <div 
                className="w-10 h-10 rounded-full overflow-hidden cursor-pointer border border-gray-200 hover:opacity-90 relative group"
                onClick={() => handleNavigation(ViewState.PROFILE)}
            >
                <img src={currentUser.avatar} alt="Me" className="w-full h-full object-cover" />
             </div>
         </div>
      </header>
  );

  const MobileHeader = () => {
    if (currentView === ViewState.HOME) {
        return (
            <div className="md:hidden flex-shrink-0 flex justify-between items-center px-4 py-2 bg-white z-40 shadow-sm border-b border-gray-200 sticky top-0">
                <div className="flex items-center gap-2">
                    <ShaVerseLogo className="w-9 h-9" />
                    <div className="flex flex-col">
                        <h1 className="text-lg font-bold text-gray-900 leading-none">Home</h1>
                        <span className="text-[10px] text-gray-500 font-medium leading-none mt-0.5">Sha-Verse</span>
                    </div>
                </div>
                <div className="flex gap-2">
                    <div className="bg-gray-100 p-2 rounded-full"><Search className="w-5 h-5 text-gray-800" /></div>
                    <div 
                        className="bg-gray-100 p-2 rounded-full cursor-pointer"
                        onClick={() => handleNavigation(ViewState.MESSAGES)}
                    >
                        <MessageCircle className="w-5 h-5 text-gray-800" />
                    </div>
                </div>
            </div>
        );
    }
    return null;
  };

  const MobileMenu = () => {
      if (!isMobileMenuOpen) return null;
      return (
          <div className="fixed inset-0 z-[100] bg-gray-100 flex flex-col md:hidden animate-fadeIn">
              <div className="p-4 bg-white shadow-sm flex justify-between items-center">
                  <div className="flex items-center gap-2">
                      <ShaVerseLogo className="w-8 h-8" />
                      <div>
                        <h2 className="text-xl font-bold leading-none">Menu</h2>
                        <span className="text-[10px] text-gray-500">Sha-Verse</span>
                      </div>
                  </div>
                  <div className="bg-gray-100 p-2 rounded-full" onClick={() => setIsMobileMenuOpen(false)}>
                      <Search className="w-6 h-6" />
                  </div>
              </div>
              <div className="p-4 overflow-y-auto pb-safe">
                  <div className="flex items-center p-3 bg-white rounded-lg shadow-sm mb-4" onClick={() => { handleNavigation(ViewState.PROFILE); setIsMobileMenuOpen(false); }}>
                      <img src={currentUser.avatar} className="w-10 h-10 rounded-full mr-3" />
                      <div>
                          <p className="font-semibold text-gray-900">{currentUser.name}</p>
                          <p className="text-gray-500 text-sm">See your profile</p>
                      </div>
                  </div>
                  
                  <div className="grid grid-cols-2 gap-3">
                      <div className="bg-white p-4 rounded-lg shadow-sm flex flex-col items-center justify-center cursor-pointer" onClick={() => { handleNavigation(ViewState.GROUPS); setIsMobileMenuOpen(false); }}>
                          <Users className="w-8 h-8 text-blue-500 mb-2" />
                          <span className="font-semibold">Groups</span>
                      </div>
                      <div className="bg-white p-4 rounded-lg shadow-sm flex flex-col items-center justify-center cursor-pointer" onClick={() => { handleNavigation(ViewState.MOVION); setIsMobileMenuOpen(false); }}>
                          <MonitorPlay className="w-8 h-8 text-red-500 mb-2" />
                          <span className="font-semibold">Movion</span>
                      </div>
                      <div className="bg-white p-4 rounded-lg shadow-sm flex flex-col items-center justify-center cursor-pointer" onClick={() => { handleNavigation(ViewState.NOVACHAT); setIsMobileMenuOpen(false); }}>
                          <Sparkles className="w-8 h-8 text-purple-500 mb-2" />
                          <span className="font-semibold">NovaChat</span>
                      </div>
                      <div className="bg-white p-4 rounded-lg shadow-sm flex flex-col items-center justify-center cursor-pointer" onClick={() => { handleNavigation(ViewState.BOOKSHELF); setIsMobileMenuOpen(false); }}>
                          <BookOpen className="w-8 h-8 text-amber-600 mb-2" />
                          <span className="font-semibold">Bookshelf</span>
                      </div>
                      <div className="bg-white p-4 rounded-lg shadow-sm flex flex-col items-center justify-center cursor-pointer" onClick={() => { handleNavigation(ViewState.MESSAGES); setIsMobileMenuOpen(false); }}>
                          <MessageCircle className="w-8 h-8 text-green-600 mb-2" />
                          <span className="font-semibold">Messages</span>
                      </div>
                  </div>
                  
                  <button onClick={() => setIsMobileMenuOpen(false)} className="w-full mt-6 bg-gray-200 py-2 rounded-lg font-semibold text-gray-800">
                      Close Menu
                  </button>
              </div>
          </div>
      )
  }

  const RightSidebar = () => (
    <div className="hidden xl:flex flex-col w-80 h-full border-l border-gray-200 bg-white p-4 overflow-y-auto no-scrollbar pt-4 flex-shrink-0">
        <div className="mb-4">
            <h3 className="text-gray-500 font-semibold mb-2 text-[15px]">Sponsored</h3>
                <div className="flex items-center gap-3 mb-2 cursor-pointer hover:bg-gray-100 p-2 rounded-lg transition-colors">
                    <img src="https://picsum.photos/100/100?random=88" className="w-24 h-24 object-cover rounded-lg" alt="Ad" />
                    <div className="flex flex-col">
                        <span className="font-semibold text-gray-900 text-sm">HexaTech Gadgets</span>
                        <span className="text-gray-500 text-xs">shaverse.ads.com</span>
                    </div>
                </div>
        </div>
        <div className="border-t border-gray-300 my-2"></div>
        <div className="flex justify-between items-center mb-2 px-2">
            <h3 className="text-gray-500 font-semibold">Contacts</h3>
            <div className="flex gap-2 text-gray-500">
                <Search className="w-4 h-4" />
                <MoreHorizontal className="w-4 h-4" />
            </div>
        </div>
        {currentUser.friends?.map((friend, i) => (
            <div 
                key={i} 
                className="flex items-center p-2 rounded-lg hover:bg-gray-100 cursor-pointer transition-colors" 
                onClick={() => handleMessageUser(friend.id)}
            >
                <div className="relative">
                    <img src={friend.avatar} className="w-9 h-9 rounded-full object-cover mr-3" alt="Contact" />
                    <div className="absolute bottom-0 right-3 w-2.5 h-2.5 bg-green-500 rounded-full border-2 border-white"></div>
                </div>
                <span className="font-medium text-gray-900 text-[15px]">{friend.name}</span>
            </div>
        ))}
    </div>
  );

  return (
    <div className="h-screen w-full bg-gray-100 font-sans flex flex-col overflow-hidden text-gray-900" style={{ height: 'calc(var(--vh, 1vh) * 100)' }}>
      <Header />
      <MobileHeader />
      <MobileMenu />

      <div className="flex-1 flex overflow-hidden relative">
        <DesktopSidebar currentView={currentView} onNavigate={handleNavigation} currentUser={currentUser} />
        
        <main 
            id="main-scroll-container"
            className="flex-1 overflow-y-auto no-scrollbar relative scroll-smooth bg-gray-100"
        >
          {currentView === ViewState.HOME && (
              <Feed 
                currentUser={currentUser} 
                posts={posts} 
                onCreatePost={handleCreatePost}
                onLike={handleReaction}
                onComment={handleComment}
                onVote={handleVote}
                onEditPost={handleEditPost}
                onDeletePost={handleDeletePost}
                onLikeComment={handleLikeComment}
              />
          )}
          {currentView === ViewState.GROUPS && (
              <Groups groups={groups} onJoin={handleJoinGroup} onBack={() => handleNavigation(ViewState.HOME)} />
          )}
          {currentView === ViewState.PROFILE && (
              <Profile 
                user={currentUser} 
                posts={posts} 
                currentUser={currentUser}
                onLike={handleReaction}
                onComment={handleComment}
                onCreatePost={handleCreatePost}
                onUpdateUser={handleUpdateUser}
                onVote={handleVote}
                onEditPost={handleEditPost}
                onDeletePost={handleDeletePost}
                onLikeComment={handleLikeComment}
                onBack={() => handleNavigation(ViewState.HOME)}
                onMessage={handleMessageUser}
              />
          )}
          {currentView === ViewState.MOVION && <Movion onBack={() => handleNavigation(ViewState.HOME)} />}
          {currentView === ViewState.NOVACHAT && <NovaChat onBack={() => handleNavigation(ViewState.HOME)} />}
          {currentView === ViewState.BOOKSHELF && <Bookshelf onBack={() => handleNavigation(ViewState.HOME)} />}
          {currentView === ViewState.MESSAGES && (
              <Messages 
                currentUser={currentUser} 
                onBack={() => handleNavigation(ViewState.HOME)} 
                initialContactId={selectedContactId}
              />
          )}
        </main>
        
        {currentView === ViewState.HOME && <RightSidebar />}
      </div>

      {currentView !== ViewState.MESSAGES && (
          <Navigation 
            currentView={currentView} 
            onNavigate={handleNavigation} 
            onMenuClick={() => setIsMobileMenuOpen(true)}
          />
      )}
    </div>
  );
}