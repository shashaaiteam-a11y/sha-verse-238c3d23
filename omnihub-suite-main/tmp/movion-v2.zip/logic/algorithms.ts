
import { Video, VideoType, Channel, Subscription } from '../types';

/**
 * HOME FEED ALGORITHM
 * Score = (WatchTime * 0.4) + (Likes * 0.2) - (Dislikes * 0.1) + (Comments * 0.1) + (Freshness * 0.15) + (Category Match * 0.15)
 */
export const prioritizeVideos = (
  videos: Video[], 
  subscriptions: string[], 
  history: Video[], 
  searchQuery?: string,
  category?: string
): Video[] => {
  const userTopCategories = Array.from(new Set(history.map(v => v.category)));
  const now = Date.now();

  let results = [...videos].filter(v => v.type === VideoType.LONG);
  
  if (category && category !== 'All' && category !== 'New to you') {
    results = results.filter(v => v.category === category);
  }

  return results.sort((a, b) => {
    const calculateScore = (v: Video) => {
      const analytics = v.analytics || { 
        watchTimeSeconds: 0, likes: 0, dislikes: 0, commentsCount: 0, 
        uploadTimestampMs: now - 86400000 
      };

      // 1. WatchTime (Normalized) - assuming 10k seconds as 'max' weight
      const watchTimeScore = Math.min(analytics.watchTimeSeconds / 10000, 1) * 0.4;
      
      // 2. Likes (Normalized) - Positive Signal
      const likesScore = Math.min(analytics.likes / 5000, 1) * 0.2;

      // 3. Dislikes (Normalized) - Negative Signal
      const dislikesScore = Math.min((analytics.dislikes || 0) / 1000, 1) * 0.1;
      
      // 4. Comments (Normalized)
      const commentsScore = Math.min(analytics.commentsCount / 500, 1) * 0.1;
      
      // 5. Freshness (0.15) - 3 day decay window
      const hoursOld = (now - analytics.uploadTimestampMs) / (1000 * 60 * 60);
      const freshnessScore = Math.max(1 - (hoursOld / 72), 0) * 0.15; 
      
      // 6. Category Match (0.15)
      const categoryMatchScore = userTopCategories.includes(v.category) ? 0.15 : 0;

      // Subscription Boost
      const subBoost = subscriptions.includes(v.channelId) ? 1.2 : 1;

      return (watchTimeScore + likesScore - dislikesScore + commentsScore + freshnessScore + categoryMatchScore) * subBoost;
    };

    return calculateScore(b) - calculateScore(a);
  });
};

/**
 * SHORTS ALGORITHM (PULSE)
 * Score = (Retention % * 0.5) + (Replays * 0.3) + (Likes * 0.1) - (Dislikes * 0.1) + (Engagement Speed * 0.2)
 */
export const prioritizePulse = (videos: Video[]): Video[] => {
  const shorts = videos.filter(v => v.type === VideoType.SHORT);
  
  return shorts.sort((a, b) => {
    const calculatePulseScore = (v: Video) => {
      const analytics = v.analytics || { averageRetention: 0.5, replays: 0, engagementSpeed: 0.5, likes: 0, dislikes: 0 };
      
      const retentionScore = analytics.averageRetention * 0.5;
      const replayScore = Math.min(analytics.replays / 10, 1) * 0.3; // Cap at 10 replays for normalization
      const speedScore = analytics.engagementSpeed * 0.2;
      const likeFactor = Math.min(analytics.likes / 10000, 1) * 0.1;
      const dislikeFactor = Math.min((analytics.dislikes || 0) / 2000, 1) * 0.1;
      
      return retentionScore + replayScore + speedScore + likeFactor - dislikeFactor;
    };
    
    return calculatePulseScore(b) - calculatePulseScore(a);
  });
};

export const getTrendingFeed = (videos: Video[]): Video[] => {
  const now = Date.now();
  return [...videos].sort((a, b) => {
    const getTrendingScore = (v: Video) => {
      const analytics = v.analytics || { views: 1, likes: 0, uploadTimestampMs: now };
      const hoursSinceUpload = Math.max((now - analytics.uploadTimestampMs) / (1000 * 60 * 60), 1);
      const velocity = analytics.views / hoursSinceUpload;
      const decay = Math.pow(hoursSinceUpload + 2, 1.5);
      return velocity / decay;
    };
    return getTrendingScore(b) - getTrendingScore(a);
  });
};

/**
 * SUBSCRIPTION FEED ALGORITHM
 * 
 * Logic:
 * 1. Filter videos from subscribed channels.
 * 2. If 'smart' sort:
 *    Score = UploadTimeWeight + UserInteractionWeight + NotificationLevelWeight
 * 3. If 'recent' sort:
 *    Strict reverse chronological order.
 */
export const prioritizeSubscriptions = (
  videos: Video[],
  subscriptionsMap: Record<string, Subscription>,
  history: Video[],
  channelId?: string,
  sortMode: 'smart' | 'recent' = 'recent'
): Video[] => {
  let filtered = videos.filter(v => v.type === VideoType.LONG);
  
  // Filter by specific channel if provided, else filter by all subscribed channels
  if (channelId) {
    filtered = filtered.filter(v => v.channelId === channelId);
  } else {
    filtered = filtered.filter(v => subscriptionsMap[v.channelId]);
  }

  // RECENT SORT: Strict Chronological
  if (sortMode === 'recent') {
    return filtered.sort((a, b) => (b.analytics?.uploadTimestampMs || 0) - (a.analytics?.uploadTimestampMs || 0));
  }

  // SMART SORT: Ranking Logic
  const now = Date.now();
  
  // Pre-calculate affinity map from history (how many times user watched this channel)
  const channelAffinity: Record<string, number> = {};
  history.forEach(v => {
    channelAffinity[v.channelId] = (channelAffinity[v.channelId] || 0) + 1;
  });

  return filtered.sort((a, b) => {
    const getScore = (v: Video) => {
      // 1. Recency Score (Decays over hours)
      // Base: 100 points. Decays: 100 / (hours + 1)
      const msAgo = Math.max(0, now - (v.analytics?.uploadTimestampMs || now));
      const hoursAgo = msAgo / (1000 * 60 * 60);
      const recencyScore = 100 / (Math.max(hoursAgo, 0.1) + 1); 

      // 2. Notification Level Weight
      const sub = subscriptionsMap[v.channelId];
      let notifScore = 0;
      if (sub?.notificationLevel === 'ALL') notifScore = 40; // High bonus for 'All Notifications'
      else if (sub?.notificationLevel === 'PERSONALIZED') notifScore = 10;

      // 3. User Interaction History Weight
      const interactionCount = channelAffinity[v.channelId] || 0;
      // Cap affinity bonus at 30 points (approx 6 videos watched)
      const interactionScore = Math.min(interactionCount * 5, 30); 

      return recencyScore + notifScore + interactionScore;
    };

    return getScore(b) - getScore(a);
  });
};

export const getRelatedVideos = (currentVideo: Video, allVideos: Video[]): Video[] => {
  return prioritizeVideos(
    allVideos.filter(v => v.id !== currentVideo.id && v.type === VideoType.LONG),
    [currentVideo.channelId],
    [], undefined, 'All'
  );
};

export const searchContent = (
  query: string,
  videos: Video[],
  channels: Channel[],
  filterType: 'ALL' | 'VIDEOS' | 'SHORTS' | 'CHANNELS'
): (Video | Channel)[] => {
  const q = query.toLowerCase().trim();
  if (!q) return [];

  const matchedChannels = channels.filter(c => 
    c.name.toLowerCase().includes(q) || 
    c.handle.toLowerCase().includes(q)
  );

  const matchedVideos = videos.filter(v => 
    v.title.toLowerCase().includes(q) || 
    v.category.toLowerCase().includes(q)
  );

  let results: any[] = [];
  if (filterType === 'ALL') results = [...matchedChannels, ...matchedVideos];
  else if (filterType === 'VIDEOS') results = matchedVideos.filter(v => v.type === VideoType.LONG);
  else if (filterType === 'SHORTS') results = matchedVideos.filter(v => v.type === VideoType.SHORT);
  else if (filterType === 'CHANNELS') results = matchedChannels;

  return results;
};
